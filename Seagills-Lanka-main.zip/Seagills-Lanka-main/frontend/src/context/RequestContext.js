import React, { createContext, useContext, useState, useEffect } from 'react';

const RequestContext = createContext();

export const useRequest = () => {
  const context = useContext(RequestContext);
  if (!context) {
    throw new Error('useRequest must be used within a RequestProvider');
  }
  return context;
};

export const RequestProvider = ({ children }) => {
  const [requests, setRequests] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    setCurrentUser({
      id: 'coordinator_id_here',
      role: 'coordinator',
      name: 'John Coordinator'
    });
  }, []);

  const addRequest = (request) => {
    setRequests(prev => [request, ...prev]);
  };

  const updateRequest = (requestId, updates) => {
    setRequests(prev =>
      prev.map(req =>
        req._id === requestId ? { ...req, ...updates } : req
      )
    );
  };

  const addNotification = (notification) => {
    setNotifications(prev => [
      {
        id: Date.now(),
        timestamp: new Date(),
        read: false,
        ...notification
      },
      ...prev
    ]);
  };

  const markNotificationRead = (notificationId) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === notificationId ? { ...notif, read: true } : notif
      )
    );
  };

  const value = {
    requests,
    setRequests,
    currentUser,
    setCurrentUser,
    notifications,
    addRequest,
    updateRequest,
    addNotification,
    markNotificationRead
  };

  return (
    <RequestContext.Provider value={value}>
      {children}
    </RequestContext.Provider>
  );
};
