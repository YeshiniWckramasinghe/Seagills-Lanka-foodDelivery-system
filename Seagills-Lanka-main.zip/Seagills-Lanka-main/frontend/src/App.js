// frontend/src/App.js
import React from "react";
import { toast } from "react-toastify";

import { Routes, Route, Navigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import CustomerRequestForm from "./components/customer/CustomerRequestForm";
import AddDeliveryNote from "./components/customer/AddDeliveryNote";
import "./App.css";

// Pages / Components
import Home from "./Component/Home/Home";
import Login from "./Component/Login/Login";
import Register from "./Component/Register/Register";
import Products from "./Component/Products/Products";
import CoordinatorDashboard from "./pages/CoordinatorDashboard";
import DailyLoading from "./pages/DailyLoading";
import VerifyOrders from "./pages/VerifyOrders";
import AdminDashboard from "./pages/AdminDashboard";
import TruckAssignment from "./pages/TruckAssignment";
import TruckManagement from "./pages/TruckManagement";
import SetSchedules from "./pages/SetSchedules";
import EnRouteOrders from "./pages/EnRouteOrders";
import UpdatePayments from "./pages/UpdatePayments";
import ProductDetails from "./Component/Products/ProductDetails";
import { CartProvider } from "./Component/Preorder/CartContext";
import Cart from "./Component/Preorder/Cart";
import PreorderForm from "./Component/Preorder/PreorderForm";
import Layout from "./Component/Layout/Layout";
import Preorder from "./Component/Preorder/Preorder";
import Profile from "./Component/Profile/Profile";
import RecordIncident from "./pages/RecordIncident";
import CoordinatorDashboard_Enroute from "./components/coordinator/CoordinatorDashboard_Enroute";
import AcceptRejectRequests from "./components/coordinator/AcceptRejectRequests";
import CoordinatorNotifications from "./components/coordinator/CoordinatorNotifications";
import RequestStatusCheck from "./components/customer/RequestStatusCheck";
import AdminReports from "./components/admin/AdminReports";
import PaymentIntegration from "./components/pos/PaymentIntegration";
import RouteManagement from "./pages/RouteManagement"; // <-- import it
import CloseTrip from "./pages/CloseTrip";
import Admin_Reports from "./pages/Admin_Reports";
import DailyTruckReport from "./pages/DailyTruckReport";
import TruckRouteSchedule from "./pages/TruckRouteSchedule";
import CategoryDefaultStockManagement from "./pages/CategoryDefaultStockManagement";
import TripReport from "./pages/TripReport";
import AboutUs from "./Component/About/AboutUs";
import PreorderReport from "./components/admin/PreorderReport";

// Maps
import DriverMap from "./components/DriverMap";
import AdminMap from "./components/AdminMap";

import Inventory from "./pages/inventory";
import Stock from "./pages/stock";
import Suppliers from "./pages/supplier";
import InventoryPage from "./pages/inventorypage";

// ------------------------
// Protected Route Component
// ------------------------
const ProtectedRoute = ({ children, allowedRoles }) => {
  const token = localStorage.getItem("token");
  const userStr = localStorage.getItem("user");

  if (!token || !userStr) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles) {
    const user = JSON.parse(userStr);
    if (!allowedRoles.includes(user.role)) {
      return <Navigate to="/login" replace />;
    }
  }

  return children;
};

// ------------------------
// Role-based Route
// ------------------------
const RoleRoute = ({ children, role }) => {
  const userStr = localStorage.getItem("user");
  if (!userStr) return <Navigate to="/login" replace />;

  const user = JSON.parse(userStr);
  if (user.role !== role) return <Navigate to="/" replace />;

  return children;
};

// ------------------------
// App Component
// ------------------------
function App() {
  return (
    // <CartProvider> is the outermost wrapper
    <CartProvider>
      <Routes>
        <Route
          path="/"
          element={
            <Layout>
              <Home />
            </Layout>
          }
        />
        <Route
          path="/login"
          element={
            <Layout>
              <Login />
            </Layout>
          }
        />
        <Route
          path="/register"
          element={
            <Layout>
              <Register />
            </Layout>
          }
        />
        <Route
          path="/products"
          element={
            <Layout>
              <Products />
            </Layout>
          }
        />
        <Route
          path="/products/:id"
          element={
            <Layout>
              <ProductDetails />
            </Layout>
          }
        />
        <Route
          path="/preorder-form"
          element={
            <Layout>
              <PreorderForm />
            </Layout>
          }
        />
        <Route
          path="/preorder"
          element={
            <Layout>
              <Preorder />
            </Layout>
          }
        />
        <Route
          path="/cart"
          element={
            <Layout>
              <Cart />
            </Layout>
          }
        />
        <Route
          path="/about"
          element={
            <Layout>
              <AboutUs />
            </Layout>
          }
        />
        <Route
          path="/profile"
          element={
            <Layout>
              <Profile />
            </Layout>
          }
        />

        {/* Admin Routes - Protected */}
        <Route
          path="/admin-dashboard"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/assign-truck"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <TruckAssignment />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/schedules"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <SetSchedules />
            </ProtectedRoute>
          }
        />
        <Route
          path="/stock-dashboard"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <Inventory />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/inventory"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <Inventory />
            </ProtectedRoute>
          }
        />
        {/*-------- Inventory Management -------- */}

        <Route
          path="/admin/inventory/inventorypage"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <InventoryPage />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/inventory/supplier"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <Suppliers />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/inventory/stock"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <Stock />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/category-default-stock"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <CategoryDefaultStockManagement />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/reports"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <Admin_Reports />
            </ProtectedRoute>
          }
        />
        
        <Route
          path="/admin/preorder-report"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <PreorderReport />
            </ProtectedRoute>
          }
        />
        {/* Coordinator Routes - UNPROTECTED */}
<Route
  path="/coordinator/requests"
  element={<AcceptRejectRequests />}
/>

<Route
  path="/coordinator/notifications"
  element={<CoordinatorNotifications />}
/>

<Route
  path="/coordinator/dashboard_enroute"
  element={<CoordinatorDashboard_Enroute />}
/>

{/* Customer Routes - UNPROTECTED */}
<Route
  path="/customer/add-note/:orderId"
  element={
    <Layout>
      <AddDeliveryNote />
    </Layout>
  }
/>

<Route
  path="/customer/request-status"
  element={
    <Layout>
      <RequestStatusCheck />
    </Layout>
  }
/>

{/* POS/Payment Routes - UNPROTECTED */}
<Route
  path="/pos/payment/:orderId"
  element={<PaymentIntegration />}
/>

{/* Admin Reports - UNPROTECTED */}
<Route
  path="/admin-reports/all"
  element={<AdminReports />}
/>

<Route
  path="/admin/truck-routes"
  element={
    <ProtectedRoute allowedRoles={["Admin"]}>
      <TruckRouteSchedule />
    </ProtectedRoute>
  }
/>
        {/* Delivery Coordinator Routes - Protected */}
        <Route
          path="/coordinator-dashboard"
          element={
            <ProtectedRoute allowedRoles={["DeliveryCoordinator"]}>
              <CoordinatorDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/record-incident"
          element={
            <ProtectedRoute allowedRoles={["DeliveryCoordinator"]}>
              <RecordIncident />
            </ProtectedRoute>
          }
        />
        <Route
          path="/close-trip"
          element={
            <ProtectedRoute allowedRoles={["DeliveryCoordinator"]}>
              <CloseTrip />
            </ProtectedRoute>
          }
        />
        <Route
          path="/trip-report/:tripSummaryId"
          element={
            <ProtectedRoute allowedRoles={["DeliveryCoordinator"]}>
              <TripReport />
            </ProtectedRoute>
          }
        />
        <Route
          path="/daily-loading"
          element={
            <ProtectedRoute allowedRoles={["DeliveryCoordinator"]}>
              <DailyLoading />
            </ProtectedRoute>
          }
        />
        <Route
          path="/verify-orders"
          element={
            <ProtectedRoute allowedRoles={["DeliveryCoordinator"]}>
              <VerifyOrders />
            </ProtectedRoute>
          }
        />
        <Route
          path="/en-route-orders"
          element={
            <ProtectedRoute allowedRoles={["DeliveryCoordinator"]}>
              <EnRouteOrders />
            </ProtectedRoute>
          }
        />
        <Route
          path="/update-payments"
          element={
            <ProtectedRoute allowedRoles={["DeliveryCoordinator"]}>
              <UpdatePayments />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/trucks"
          element={
            <ProtectedRoute allowedRoles={["Admin"]}>
              <TruckManagement />
            </ProtectedRoute>
          }
        />

<Route
  path="/admin/routes"
  element={
    <ProtectedRoute allowedRoles={["Admin"]}>
      <RouteManagement />
    </ProtectedRoute>
  }
/>
<Route
  path="/customer/request"
  element={
    <Layout>
      <CustomerRequestForm />
    </Layout>
  }
/>

<Route
  path="/admin-map"
  element={
    <ProtectedRoute allowedRoles={["Admin"]}>
      <AdminMap />
    </ProtectedRoute>
  }
/>
<Route
  path="/driver-map/:driverID"
  element={
    <ProtectedRoute allowedRoles={["TruckDriver"]}>
      <DriverMap />
    </ProtectedRoute>
  }
/>
<Route path="/admin-reports/daily-truck" element={<DailyTruckReport />} />

        {/* Redirect unknown paths to Home */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </CartProvider>
  );
}

export default App;
