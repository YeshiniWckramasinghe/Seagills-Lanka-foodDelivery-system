import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Header = () => {
  const location = useLocation();

  return (
    <header style={headerStyles}>
      <div style={containerStyles}>
        <Link to="/" style={logoStyles}>
          Seagills Lanka
        </Link>
        
        <nav style={navStyles}>
          <Link 
            to="/customer/request" 
            style={{
              ...linkStyles,
              ...(location.pathname.includes('/customer') ? activeLinkStyles : {})
            }}
          >
            Customer
          </Link>
          <Link 
            to="/coordinator/dashboard" 
            style={{
              ...linkStyles,
              ...(location.pathname.includes('/coordinator') ? activeLinkStyles : {})
            }}
          >
            Coordinator
          </Link>
          <Link 
            to="/admin/reports" 
            style={{
              ...linkStyles,
              ...(location.pathname.includes('/admin') ? activeLinkStyles : {})
            }}
          >
            Admin
          </Link>
        </nav>
      </div>
    </header>
  );
};

const headerStyles = {
  background: 'linear-gradient(135deg, #007bff, #0056b3)',
  color: 'white',
  padding: '1rem 0',
  boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
};

const containerStyles = {
  maxWidth: '1200px',
  margin: '0 auto',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '0 20px'
};

const logoStyles = {
  fontSize: '1.5rem',
  fontWeight: 'bold',
  color: 'white',
  textDecoration: 'none'
};

const navStyles = {
  display: 'flex',
  gap: '2rem'
};

const linkStyles = {
  color: 'rgba(255,255,255,0.8)',
  textDecoration: 'none',
  padding: '0.5rem 1rem',
  borderRadius: '5px',
  transition: 'all 0.3s'
};

const activeLinkStyles = {
  color: 'white',
  backgroundColor: 'rgba(255,255,255,0.1)'
};

export default Header;
