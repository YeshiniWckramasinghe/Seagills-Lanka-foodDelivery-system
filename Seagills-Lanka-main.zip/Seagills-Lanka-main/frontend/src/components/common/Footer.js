import React from 'react';

const Footer = () => {
  return (
    <footer style={footerStyles}>
      <div style={containerStyles}>
        <p>&copy; 2024 Seagills Lanka. All rights reserved.</p>
        <p>Enroute Order Management System</p>
      </div>
    </footer>
  );
};

const footerStyles = {
  background: '#333',
  color: 'white',
  padding: '2rem 0',
  marginTop: 'auto',
  textAlign: 'center'
};

const containerStyles = {
  maxWidth: '1200px',
  margin: '0 auto',
  padding: '0 20px'
};

export default Footer;
