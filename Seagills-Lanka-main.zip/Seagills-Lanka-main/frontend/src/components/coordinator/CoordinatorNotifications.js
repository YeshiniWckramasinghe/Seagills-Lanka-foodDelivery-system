// components/coordinator/CoordinatorNotifications.js
// SPRINT 2 - User Story 4: Coordinator is instantly notified of stop requests

import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import '../../styles/CoordinatorNotifications.css';

const CoordinatorNotifications = () => {
  const navigate = useNavigate();
  const [coordinatorId] = useState('676ce9e5f3b3a2ef5264be8'); // From authentication
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [lastNotificationCount, setLastNotificationCount] = useState(0);

  useEffect(() => {
    fetchNotifications();
    
    // Set up polling for real-time notifications every 15 seconds
    const interval = setInterval(() => {
      fetchNotifications(true);
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const fetchNotifications = async (isPolling = false) => {
    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/coordinator/${coordinatorId}/notifications`);
      const result = await response.json();
      
      if (result.success) {
        const newNotifications = createNotifications(result.data);
        setNotifications(newNotifications);
        
        // Check for new notifications and play sound
        if (isPolling && soundEnabled && result.data.notificationCount > lastNotificationCount) {
          playNotificationSound();
          toast.info(`${result.data.notificationCount - lastNotificationCount} new request(s) received!`);
        }
        
        setLastNotificationCount(result.data.notificationCount || 0);
      }
    } catch (error) {
      console.error('Error fetching notifications:', error);
      if (!isPolling) {
        toast.error('Failed to load notifications');
      }
    } finally {
      setLoading(false);
    }
  };

  const createNotifications = (data) => {
    const notifications = [];
    
    // Add pending requests as notifications
    if (data.newPendingRequests) {
      data.newPendingRequests.forEach(request => {
        notifications.push({
          id: `pending-${request._id}`,
          type: 'new_request',
          title: 'New Stop Request',
          message: `Request from ${request.customerLocation}`,
          timestamp: new Date(request.createdAt),
          orderId: request._id,
          priority: 'high',
          read: false,
          data: request
        });
      });
    }
    
    // Add status updates for assigned requests
    if (data.myAssignedRequests) {
      data.myAssignedRequests
        .filter(request => request.status === 'accepted')
        .forEach(request => {
          notifications.push({
            id: `assigned-${request._id}`,
            type: 'assignment_reminder',
            title: 'Active Delivery',
            message: `Delivery to ${request.customerLocation}`,
            timestamp: new Date(request.acceptedAt),
            orderId: request._id,
            priority: 'medium',
            read: true,
            data: request
          });
        });
    }
    
    return notifications.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  };

  const playNotificationSound = () => {
    if (soundEnabled) {
      // Create audio notification
      const audio = new Audio();
      audio.src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmAZBzqO0fPTeSwGJXTI7+eoVhQLRp3g8r5gGgU7kPP0z3wuBSF8zPTZh';
      audio.play().catch(() => {}); // Ignore errors if audio fails
    }
  };

  const markAsRead = (notificationId) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === notificationId ? { ...notif, read: true } : notif
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notif => ({ ...notif, read: true }))
    );
    toast.success('All notifications marked as read');
  };

  const handleNotificationClick = (notification) => {
    markAsRead(notification.id);
    
    if (notification.type === 'new_request') {
      // Navigate to manage requests page
      navigate('/coordinator/manage-requests');
    } else if (notification.type === 'assignment_reminder') {
      // Navigate to specific order details
      navigate(`/coordinator/order/${notification.orderId}`);
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return '#dc3545';
      case 'medium': return '#ffc107';
      case 'low': return '#28a745';
      default: return '#6c757d';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'new_request': return '🔔';
      case 'assignment_reminder': return '📦';
      case 'urgent': return '🚨';
      default: return '📋';
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading notifications...</p>
      </div>
    );
  }

  return (
    <div className="notifications-container">
      <div className="notifications-header">
        <div className="header-left">
          <h1>Notifications</h1>
          <span className="notification-count">
            {unreadCount > 0 ? `${unreadCount} unread` : 'All caught up!'}
          </span>
        </div>
        
        <div className="header-actions">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`sound-toggle ${soundEnabled ? 'enabled' : 'disabled'}`}
          >
            {soundEnabled ? '🔊' : '🔇'} Sound {soundEnabled ? 'On' : 'Off'}
          </button>
          
          <button
            onClick={fetchNotifications}
            className="refresh-btn"
          >
            🔄 Refresh
          </button>
          
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="mark-all-read"
            >
              Mark All Read
            </button>
          )}
        </div>
      </div>

      <div className="notifications-stats">
        <div className="stat-item">
          <span className="stat-number">{notifications.length}</span>
          <span className="stat-label">Total Notifications</span>
        </div>
        <div className="stat-item">
          <span className="stat-number">{unreadCount}</span>
          <span className="stat-label">Unread</span>
        </div>
        <div className="stat-item">
          <span className="stat-number">
            {notifications.filter(n => n.type === 'new_request').length}
          </span>
          <span className="stat-label">New Requests</span>
        </div>
      </div>

      <div className="notifications-list">
        {notifications.length === 0 ? (
          <div className="empty-notifications">
            <h3>No notifications</h3>
            <p>You're all caught up! New notifications will appear here.</p>
          </div>
        ) : (
          notifications.map(notification => (
            <div
              key={notification.id}
              className={`notification-item ${!notification.read ? 'unread' : 'read'}`}
              onClick={() => handleNotificationClick(notification)}
            >
              <div className="notification-icon">
                {getTypeIcon(notification.type)}
              </div>
              
              <div className="notification-content">
                <div className="notification-header">
                  <h4>{notification.title}</h4>
                  <div 
                    className="priority-indicator"
                    style={{ backgroundColor: getPriorityColor(notification.priority) }}
                  ></div>
                </div>
                
                <p className="notification-message">{notification.message}</p>
                
                <div className="notification-details">
                  {notification.data && (
                    <>
                      {notification.data.contactNum && (
                        <span className="detail">📞 {notification.data.contactNum}</span>
                      )}
                      {notification.data.note && (
                        <span className="detail">📝 {notification.data.note}</span>
                      )}
                    </>
                  )}
                </div>
                
                <div className="notification-meta">
                  <span className="timestamp">
                    {new Date(notification.timestamp).toLocaleString()}
                  </span>
                  <span className={`notification-type ${notification.type}`}>
                    {notification.type.replace('_', ' ')}
                  </span>
                </div>
              </div>

              {!notification.read && (
                <div className="unread-indicator"></div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Real-time Status */}
      <div className="realtime-status">
        <div className="status-indicator">
          <span className="status-dot active"></span>
          <span>Live Updates Active</span>
        </div>
        <span className="last-update">
          Last updated: {new Date().toLocaleTimeString()}
        </span>
      </div>
    </div>
  );
};

export default CoordinatorNotifications;
