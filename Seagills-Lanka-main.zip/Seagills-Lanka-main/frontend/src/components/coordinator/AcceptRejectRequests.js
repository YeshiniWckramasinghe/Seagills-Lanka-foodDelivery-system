// components/coordinator/AcceptRejectRequests.js
// Separate component for managing accept/reject functionality

import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import '../../styles/AcceptRejectRequests.css';

const AcceptRejectRequests = () => {
  const [coordinatorId] = useState('676ce9e5f3b3a2ef5264be8'); // From authentication
  const [pendingRequests, setPendingRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processingRequest, setProcessingRequest] = useState(null);

  useEffect(() => {
    fetchPendingRequests();
  }, []);

  const fetchPendingRequests = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/coordinator/${coordinatorId}/notifications`);
      const result = await response.json();
      
      if (result.success) {
        setPendingRequests(result.data.newPendingRequests || []);
      } else {
        toast.error('Failed to load requests');
      }
    } catch (error) {
      console.error('Error fetching requests:', error);
      toast.error('Network error');
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptRequest = async (orderId, estimatedArrival, notes) => {
    setProcessingRequest(orderId);

    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}/accept`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          coordinatorId,
          estimatedArrival,
          notes
        })
      });

      const result = await response.json();

      if (result.success) {
        toast.success('Request accepted successfully!');
        fetchPendingRequests(); // Refresh the list
      } else {
        toast.error(result.message || 'Failed to accept request');
      }
    } catch (error) {
      console.error('Error accepting request:', error);
      toast.error('Network error');
    } finally {
      setProcessingRequest(null);
    }
  };

  const handleRejectRequest = async (orderId, rejectionReason) => {
    setProcessingRequest(orderId);

    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}/reject`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          coordinatorId,
          rejectionReason
        })
      });

      const result = await response.json();

      if (result.success) {
        toast.success('Request rejected');
        fetchPendingRequests(); // Refresh the list
      } else {
        toast.error(result.message || 'Failed to reject request');
      }
    } catch (error) {
      console.error('Error rejecting request:', error);
      toast.error('Network error');
    } finally {
      setProcessingRequest(null);
    }
  };

  const RequestCard = ({ request }) => {
    const [showAcceptForm, setShowAcceptForm] = useState(false);
    const [showRejectForm, setShowRejectForm] = useState(false);
    const [acceptData, setAcceptData] = useState({
      estimatedArrival: '',
      notes: ''
    });
    const [rejectionReason, setRejectionReason] = useState('');

    const handleAcceptSubmit = (e) => {
      e.preventDefault();
      
      const estimatedTime = acceptData.estimatedArrival || 
        new Date(Date.now() + 30 * 60000).toISOString(); // Default 30 minutes
      
      handleAcceptRequest(request._id, estimatedTime, acceptData.notes);
      setShowAcceptForm(false);
    };

    const handleRejectSubmit = (e) => {
      e.preventDefault();
      
      if (rejectionReason.trim().length < 10) {
        toast.error('Please provide a detailed rejection reason');
        return;
      }
      
      handleRejectRequest(request._id, rejectionReason);
      setShowRejectForm(false);
    };

    return (
      <div className="request-management-card">
        <div className="request-header">
          <h4>Request #{request._id.slice(-6)}</h4>
          <span className="request-time">
            {new Date(request.createdAt).toLocaleString()}
          </span>
        </div>

        <div className="request-details">
          <div className="detail-row">
            <strong>Location:</strong>
            <span>{request.customerLocation}</span>
          </div>
          <div className="detail-row">
            <strong>Contact:</strong>
            <span>{request.contactNum}</span>
          </div>
          {request.note && (
            <div className="detail-row">
              <strong>Special Instructions:</strong>
              <span>{request.note}</span>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        {!showAcceptForm && !showRejectForm && (
          <div className="action-buttons">
            <button
              onClick={() => setShowAcceptForm(true)}
              disabled={processingRequest === request._id}
              className="btn-accept-primary"
            >
              Accept Request
            </button>
            <button
              onClick={() => setShowRejectForm(true)}
              disabled={processingRequest === request._id}
              className="btn-reject-primary"
            >
              Reject Request
            </button>
          </div>
        )}

        {/* Accept Form */}
        {showAcceptForm && (
          <form onSubmit={handleAcceptSubmit} className="accept-form">
            <h5>Accept Request</h5>
            
            <div className="form-group">
              <label>Estimated Arrival Time (Optional):</label>
              <input
                type="datetime-local"
                value={acceptData.estimatedArrival}
                onChange={(e) => setAcceptData(prev => ({
                  ...prev,
                  estimatedArrival: e.target.value
                }))}
                min={new Date().toISOString().slice(0, 16)}
              />
            </div>

            <div className="form-group">
              <label>Notes for Customer (Optional):</label>
              <textarea
                value={acceptData.notes}
                onChange={(e) => setAcceptData(prev => ({
                  ...prev,
                  notes: e.target.value
                }))}
                placeholder="e.g., 'Will arrive in 30 minutes', 'Please wait at the entrance'"
                maxLength={200}
                rows={3}
              />
            </div>

            <div className="form-actions">
              <button
                type="button"
                onClick={() => setShowAcceptForm(false)}
                className="btn-cancel"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={processingRequest === request._id}
                className="btn-confirm-accept"
              >
                {processingRequest === request._id ? 'Processing...' : 'Confirm Accept'}
              </button>
            </div>
          </form>
        )}

        {/* Reject Form */}
        {showRejectForm && (
          <form onSubmit={handleRejectSubmit} className="reject-form">
            <h5>Reject Request</h5>
            
            <div className="form-group">
              <label>Reason for Rejection:</label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Please provide a detailed reason (minimum 10 characters)"
                required
                minLength={10}
                maxLength={500}
                rows={4}
              />
              <small>{rejectionReason.length}/500 characters</small>
            </div>

            <div className="common-reasons">
              <p>Common reasons:</p>
              <div className="reason-buttons">
                <button
                  type="button"
                  onClick={() => setRejectionReason('Out of stock for requested items')}
                  className="reason-btn"
                >
                  Out of Stock
                </button>
                <button
                  type="button"
                  onClick={() => setRejectionReason('Location is outside our delivery area')}
                  className="reason-btn"
                >
                  Outside Area
                </button>
                <button
                  type="button"
                  onClick={() => setRejectionReason('Truck is at full capacity')}
                  className="reason-btn"
                >
                  Full Capacity
                </button>
                <button
                  type="button"
                  onClick={() => setRejectionReason('Unable to locate the specified address')}
                  className="reason-btn"
                >
                  Address Issue
                </button>
              </div>
            </div>

            <div className="form-actions">
              <button
                type="button"
                onClick={() => setShowRejectForm(false)}
                className="btn-cancel"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={processingRequest === request._id || rejectionReason.trim().length < 10}
                className="btn-confirm-reject"
              >
                {processingRequest === request._id ? 'Processing...' : 'Confirm Reject'}
              </button>
            </div>
          </form>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading pending requests...</p>
      </div>
    );
  }

  return (
    <div className="accept-reject-container">
      <div className="page-header">
        <h1>Manage Requests</h1>
        <p>Accept or reject pending delivery requests</p>
        <button onClick={fetchPendingRequests} className="btn-refresh">
          Refresh ({pendingRequests.length} pending)
        </button>
      </div>

      {pendingRequests.length === 0 ? (
        <div className="empty-state">
          <h3>No pending requests</h3>
          <p>All requests have been processed or no new requests are available.</p>
          <button onClick={fetchPendingRequests} className="btn-refresh">
            Check Again
          </button>
        </div>
      ) : (
        <div className="requests-container">
          <div className="requests-stats">
            <div className="stat">
              <span className="stat-number">{pendingRequests.length}</span>
              <span className="stat-label">Pending Requests</span>
            </div>
          </div>

          <div className="requests-grid">
            {pendingRequests.map(request => (
              <RequestCard key={request._id} request={request} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AcceptRejectRequests;
