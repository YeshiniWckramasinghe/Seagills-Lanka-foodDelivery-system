// components/coordinator/CoordinatorDashboard.js
// SPRINT 2 - User Stories 3,4,5: Coordinator management and notifications

import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import '../../styles/CoordinatorDashboard.css';


const CoordinatorDashboard = () => {
  const [coordinatorId] = useState('676ce9e5f3b3a2ef5264be8'); // This would come from authentication
  const [pendingRequests, setPendingRequests] = useState([]);
  const [myRequests, setMyRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [notificationCount, setNotificationCount] = useState(0);
  const [activeTab, setActiveTab] = useState('pending');

  useEffect(() => {
    fetchNotifications();
    // Set up polling for real-time notifications
    const interval = setInterval(fetchNotifications, 30000); // Poll every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchNotifications = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/coordinator/${coordinatorId}/notifications`);
      const result = await response.json();
      
      if (result.success) {
        setPendingRequests(result.data.newPendingRequests || []);
        setMyRequests(result.data.myAssignedRequests || []);
        setNotificationCount(result.data.notificationCount || 0);
      } else {
        toast.error('Failed to load notifications');
      }
    } catch (error) {
      console.error('Error fetching notifications:', error);
      toast.error('Network error');
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptRequest = async (orderId) => {
    const estimatedArrival = new Date(Date.now() + 30 * 60000).toISOString(); // 30 minutes from now
    const notes = 'Request accepted. Will arrive soon.';

    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}/accept`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          coordinatorId,
          estimatedArrival,
          notes
        })
      });

      const result = await response.json();

      if (result.success) {
        toast.success('Request accepted successfully!');
        fetchNotifications(); // Refresh data
      } else {
        toast.error(result.message || 'Failed to accept request');
      }
    } catch (error) {
      console.error('Error accepting request:', error);
      toast.error('Network error');
    }
  };

  const handleRejectRequest = async (orderId, reason) => {
    if (!reason || reason.trim().length < 10) {
      toast.error('Please provide a detailed rejection reason');
      return;
    }

    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}/reject`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          coordinatorId,
          rejectionReason: reason.trim()
        })
      });

      const result = await response.json();

      if (result.success) {
        toast.success('Request rejected');
        fetchNotifications(); // Refresh data
      } else {
        toast.error(result.message || 'Failed to reject request');
      }
    } catch (error) {
      console.error('Error rejecting request:', error);
      toast.error('Network error');
    }
  };

  const RequestCard = ({ request, showActions = true }) => {
    const [rejectionReason, setRejectionReason] = useState('');
    const [showRejectForm, setShowRejectForm] = useState(false);

    return (
      <div className="request-card">
        <div className="request-header">
          <h4>Request #{request._id.slice(-6)}</h4>
          <span className={`status ${request.status || 'pending'}`}>
            {request.status || 'Pending'}
          </span>
        </div>
        
        <div className="request-details">
          <p><strong>Location:</strong> {request.customerLocation}</p>
          <p><strong>Contact:</strong> {request.contactNum}</p>
          <p><strong>Time:</strong> {new Date(request.createdAt).toLocaleString()}</p>
          {request.note && (
            <p><strong>Note:</strong> {request.note}</p>
          )}
        </div>

        {showActions && request.status === 'pending' && (
          <div className="request-actions">
            <button
              onClick={() => handleAcceptRequest(request._id)}
              className="btn-accept"
            >
              Accept
            </button>
            <button
              onClick={() => setShowRejectForm(!showRejectForm)}
              className="btn-reject"
            >
              Reject
            </button>
          </div>
        )}

        {showRejectForm && (
          <div className="reject-form">
            <textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Please provide a reason for rejection (minimum 10 characters)"
              minLength={10}
              maxLength={500}
              rows={3}
            />
            <div className="reject-actions">
              <button
                onClick={() => setShowRejectForm(false)}
                className="btn-cancel"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  handleRejectRequest(request._id, rejectionReason);
                  setShowRejectForm(false);
                  setRejectionReason('');
                }}
                disabled={rejectionReason.trim().length < 10}
                className="btn-confirm-reject"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading coordinator dashboard...</p>
      </div>
    );
  }

  return (
    <div className="coordinator-dashboard">
      <div className="dashboard-header">
        <h1>Coordinator Dashboard</h1>
        <div className="notification-badge">
          {notificationCount > 0 && (
            <span className="badge">{notificationCount} New Requests</span>
          )}
        </div>
      </div>

      <div className="dashboard-stats">
        <div className="stat-card">
          <h3>{pendingRequests.length}</h3>
          <p>Pending Requests</p>
        </div>
        <div className="stat-card">
          <h3>{myRequests.length}</h3>
          <p>My Active Requests</p>
        </div>
        <div className="stat-card">
          <h3>{myRequests.filter(r => r.status === 'accepted').length}</h3>
          <p>Accepted Today</p>
        </div>
      </div>

      <div className="dashboard-tabs">
        <button
          className={activeTab === 'pending' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('pending')}
        >
          New Requests ({pendingRequests.length})
        </button>
        <button
          className={activeTab === 'my-requests' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('my-requests')}
        >
          My Requests ({myRequests.length})
        </button>
      </div>

      <div className="dashboard-content">
        {activeTab === 'pending' && (
          <div className="requests-section">
            <h2>New Pending Requests</h2>
            {pendingRequests.length === 0 ? (
              <div className="empty-state">
                <p>No pending requests at the moment</p>
                <button onClick={fetchNotifications} className="btn-refresh">
                  Refresh
                </button>
              </div>
            ) : (
              <div className="requests-grid">
                {pendingRequests.map(request => (
                  <RequestCard key={request._id} request={request} showActions={true} />
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'my-requests' && (
          <div className="requests-section">
            <h2>My Assigned Requests</h2>
            {myRequests.length === 0 ? (
              <div className="empty-state">
                <p>No assigned requests</p>
              </div>
            ) : (
              <div className="requests-grid">
                {myRequests.map(request => (
                  <RequestCard key={request._id} request={request} showActions={false} />
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="quick-actions">
        <button
          onClick={fetchNotifications}
          className="btn-refresh"
        >
          🔄 Refresh
        </button>
        <button
          onClick={() => toast.info('Sound notifications enabled')}
          className="btn-sound"
        >
          🔔 Sound: On
        </button>
      </div>
    </div>
  );
};

export default CoordinatorDashboard;
