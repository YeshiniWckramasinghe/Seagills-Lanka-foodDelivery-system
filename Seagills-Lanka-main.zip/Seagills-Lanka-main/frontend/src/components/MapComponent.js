import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";

// Custom truck icon
const truckIcon = new L.Icon({
  iconUrl: '/images/truck.png',
  iconSize: [40, 40],
  iconAnchor: [20, 40],
  popupAnchor: [0, -40],
});

const MapComponent = ({ driverId }) => {
  const [truck, setTruck] = useState(null);
  const defaultPosition = [6.9271, 79.8612]; // Colombo

  const fetchTruck = async () => {
    try {
      const res = await fetch(`http://localhost:5000/api/assigned-trucks/driver/${driverId}`);
      const data = await res.json();
      if (data.success && data.truck) {
        setTruck(data.truck);
      } else {
        setTruck(null);
      }
    } catch (err) {
      console.error("Error fetching truck:", err);
      setTruck(null);
    }
  };

  useEffect(() => {
    fetchTruck(); // initial fetch
    const interval = setInterval(fetchTruck, 5000); // real-time
    return () => clearInterval(interval);
  }, [driverId]);

  const position = truck?.currentLocation
    ? [truck.currentLocation.coordinates[1], truck.currentLocation.coordinates[0]]
    : defaultPosition;

  return (
    <MapContainer center={position} zoom={13} style={{ height: "500px", width: "100%" }}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; OpenStreetMap contributors'
      />
      {truck && truck.currentLocation && (
        <Marker
          position={[truck.currentLocation.coordinates[1], truck.currentLocation.coordinates[0]]}
          icon={truckIcon}
        >
          <Popup>Truck: {truck.plateNo || "Unnamed Truck"}</Popup>
        </Marker>
      )}
      {!truck && <div style={{ position: "absolute", top: 10, left: 10, zIndex: 1000, background: "white", padding: "5px 10px" }}>No assignments today</div>}
    </MapContainer>
  );
};

export default MapComponent;
