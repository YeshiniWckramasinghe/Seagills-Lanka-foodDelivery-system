// components/pos/PaymentIntegration.js
// SPRINT 3 - User Story 6: Coordinator uses existing POS system for better payment service

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import '../../styles/PaymentIntegration.css';

const PaymentIntegration = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [orderDetails, setOrderDetails] = useState(null);
  const [bill, setBill] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generatingBill, setGeneratingBill] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('cash');

  useEffect(() => {
    fetchOrderDetails();
  }, [orderId]);

  const fetchOrderDetails = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}`);
      const result = await response.json();
      
      if (result.success) {
        setOrderDetails(result.data);
      } else {
        toast.error('Order not found');
        navigate('/coordinator/dashboard');
      }
    } catch (error) {
      console.error('Error fetching order:', error);
      toast.error('Failed to load order details');
    } finally {
      setLoading(false);
    }
  };

  const generateBill = async () => {
    setGeneratingBill(true);
    
    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}/generate-bill`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          deliveryConfirmed: true
        })
      });

      const result = await response.json();
      
      if (result.success) {
        setBill(result.data);
        toast.success('Bill generated successfully!');
      } else {
        toast.error(result.message || 'Failed to generate bill');
      }
    } catch (error) {
      console.error('Error generating bill:', error);
      toast.error('Network error');
    } finally {
      setGeneratingBill(false);
    }
  };

  const processPOSPayment = async () => {
    // Integration with existing POS system
    toast.info('Connecting to POS system...');
    
    try {
      // Simulate POS system integration
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // In real implementation, this would call your existing POS API
      const posResponse = {
        success: true,
        transactionId: `TXN-${Date.now()}`,
        amount: bill.totalAmount,
        method: paymentMethod,
        timestamp: new Date().toISOString()
      };

      if (posResponse.success) {
        toast.success('Payment processed successfully through POS system!');
        // Redirect to success page or dashboard
        navigate('/coordinator/dashboard');
      }
    } catch (error) {
      toast.error('POS system error. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading order details...</p>
      </div>
    );
  }

  return (
    <div className="payment-integration-container">
      <div className="payment-card">
        <h2>Payment Processing</h2>
        <p className="subtitle">Process payment through existing POS system</p>

        {/* Order Summary */}
        {orderDetails && (
          <div className="order-summary">
            <h3>Order Summary</h3>
            <div className="order-info">
              <p><strong>Order ID:</strong> {orderDetails.order._id}</p>
              <p><strong>Customer:</strong> {orderDetails.order.contactNum}</p>
              <p><strong>Location:</strong> {orderDetails.order.customerLocation}</p>
              <p><strong>Status:</strong> {orderDetails.order.status}</p>
            </div>

            {orderDetails.products && orderDetails.products.length > 0 && (
              <div className="products-section">
                <h4>Products Ordered:</h4>
                <div className="products-list">
                  {orderDetails.products.map((item, index) => (
                    <div key={index} className="product-item">
                      <span>{item.productID.productName}</span>
                      <span>Qty: {item.quantity}</span>
                      <span>₹{item.productID.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Bill Generation */}
        {!bill && (
          <div className="bill-generation">
            <h3>Generate Bill</h3>
            <p>Confirm delivery completion to generate final bill</p>
            <button
              onClick={generateBill}
              disabled={generatingBill}
              className="btn-generate-bill"
            >
              {generatingBill ? 'Generating...' : 'Confirm Delivery & Generate Bill'}
            </button>
          </div>
        )}

        {/* Bill Display */}
        {bill && (
          <div className="bill-display">
            <h3>Generated Bill</h3>
            <div className="bill-details">
              <div className="bill-header">
                <h4>Seagills Lanka - Delivery Bill</h4>
                <p>Bill No: {bill.billNumber}</p>
                <p>Date: {new Date(bill.deliveryDate).toLocaleString()}</p>
              </div>

              <div className="bill-items">
                <h5>Items:</h5>
                {bill.items.map((item, index) => (
                  <div key={index} className="bill-item">
                    <span>{item.productName}</span>
                    <span>{item.quantity} x ₹{item.unitPrice}</span>
                    <span>₹{item.total}</span>
                  </div>
                ))}
                
                <div className="bill-item delivery-fee">
                  <span>Delivery Fee</span>
                  <span></span>
                  <span>₹{bill.deliveryFee}</span>
                </div>
                
                <div className="bill-total">
                  <strong>Total Amount: ₹{bill.totalAmount}</strong>
                </div>
              </div>
            </div>

            {/* Payment Method Selection */}
            <div className="payment-method">
              <h4>Payment Method</h4>
              <div className="payment-options">
                <label>
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="cash"
                    checked={paymentMethod === 'cash'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  />
                  Cash Payment
                </label>
                <label>
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="card"
                    checked={paymentMethod === 'card'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  />
                  Card Payment
                </label>
                <label>
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="digital"
                    checked={paymentMethod === 'digital'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  />
                  Digital Wallet
                </label>
              </div>
            </div>

            {/* POS Integration */}
            <div className="pos-integration">
              <h4>POS System Integration</h4>
              <div className="pos-info">
                <p>This will process the payment through your existing POS system</p>
                <ul>
                  <li>Amount will be recorded in daily sales</li>
                  <li>Receipt will be generated automatically</li>
                  <li>Transaction will sync with inventory</li>
                  <li>Customer receipt can be printed or sent digitally</li>
                </ul>
              </div>

              <button
                onClick={processPOSPayment}
                className="btn-process-payment"
              >
                Process Payment via POS System
              </button>
            </div>
          </div>
        )}

        {/* Integration Status */}
        <div className="integration-status">
          <h4>POS System Status</h4>
          <div className="status-indicators">
            <div className="status-item">
              <span className="status-dot connected"></span>
              <span>POS System: Connected</span>
            </div>
            <div className="status-item">
              <span className="status-dot connected"></span>
              <span>Printer: Ready</span>
            </div>
            <div className="status-item">
              <span className="status-dot connected"></span>
              <span>Network: Stable</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentIntegration;
