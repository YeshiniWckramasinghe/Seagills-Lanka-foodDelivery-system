import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function TestLogin() {
  const [driverID, setDriverID] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!driverID) return alert("Please enter a Driver ID");
    navigate(`/driver-map/${driverID}`);
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Driver Login (Test Mode)</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Driver ID:
          <input
            type="text"
            value={driverID}
            onChange={(e) => setDriverID(e.target.value)}
            style={{ marginLeft: "0.5rem" }}
          />
        </label>
        <button type="submit" style={{ marginLeft: "1rem" }}>Go to Map</button>
      </form>
      <p>Enter the driver ID from MongoDB assigned-trucks collection.</p>
    </div>
  );
}