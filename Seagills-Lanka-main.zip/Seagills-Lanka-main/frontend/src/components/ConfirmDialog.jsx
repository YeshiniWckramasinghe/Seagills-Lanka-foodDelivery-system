import React from "react";

export default function ConfirmDialog({ open, onClose, onConfirm, message }) {
  if (!open) return null;
  return (
    <div style={overlay}>
      <div style={dialog}>
        <p>{message}</p>
        <div style={{ display: "flex", gap: "12px", marginTop: "12px" }}>
          <button onClick={onConfirm} style={{ background: "#d33", color: "#fff" }}>Delete</button>
          <button onClick={onClose} style={{ background: "#eee" }}>Cancel</button>
        </div>
      </div>
    </div>
  );
}

const overlay = {
  position: "fixed",
  inset: 0,
  background: "rgba(0,0,0,0.4)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 1000,
};

const dialog = {
  background: "#fff",
  padding: "24px",
  borderRadius: "16px",
  width: "300px",
  textAlign: "center",
};
