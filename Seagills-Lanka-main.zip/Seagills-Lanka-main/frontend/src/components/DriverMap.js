// frontend/src/components/DriverMap.jsx
import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import { useParams } from "react-router-dom";
import io from "socket.io-client";
import "leaflet/dist/leaflet.css";

// Icons
const truckIcon = L.icon({
  iconUrl: "/images/truck.png",
  iconSize: [45, 45],
  iconAnchor: [22, 22],
});
const branchIcon = L.icon({
  iconUrl: "/images/branch.png",
  iconSize: [40, 40],
  iconAnchor: [20, 40],
});

// Fit map to markers
function FitBounds({ markers }) {
  const map = useMap();
  useEffect(() => {
    if (markers.length > 0) {
      const bounds = L.latLngBounds(markers);
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [markers, map]);
  return null;
}

export default function DriverMap() {
  const { driverID } = useParams();
  const [truck, setTruck] = useState(null);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch branches
  const fetchBranches = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/branches");
      const data = await res.json();
      setBranches(data.branches || data);
    } catch (err) {
      console.error("Error fetching branches:", err);
    }
  };

  // Fetch driver's assigned truck
  const fetchAssignment = async () => {
    try {
      console.log("Fetching assignment for driverID:", driverID);
      console.log("Current date:", new Date().toISOString());
      
      const res = await fetch(
        `http://localhost:5000/api/assigned-trucks/driver/${driverID}`
      );
      
      console.log("Response status:", res.status);
      
      const data = await res.json();
      console.log("Response data:", data);
      
      // If 404, let's try fetching all assignments to debug
      if (res.status === 404) {
        console.log("404 received, fetching all assignments for debugging...");
        try {
          const allRes = await fetch(`http://localhost:5000/api/assigned-trucks`);
          const allData = await allRes.json();
          console.log("All assignments:", allData);
          
          // Find this driver's assignments manually
          const driverAssignments = allData.assignments?.filter(
            a => a.driverID?._id === driverID
          );
          console.log("This driver's assignments:", driverAssignments);
          
          // Check if there's an assignment for today (date part only, ignore timezone)
          const today = new Date();
          const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
          console.log("Today's date string:", todayStr);
          
          const todayAssignment = driverAssignments?.find(a => {
            const assignmentDate = new Date(a.date);
            const assignmentDateStr = `${assignmentDate.getUTCFullYear()}-${String(assignmentDate.getUTCMonth() + 1).padStart(2, '0')}-${String(assignmentDate.getUTCDate()).padStart(2, '0')}`;
            console.log("Assignment date string:", assignmentDateStr, "for date:", a.date);
            return assignmentDateStr === todayStr;
          });
          
          if (todayAssignment?.truckID) {
            console.log("Found today's assignment manually:", todayAssignment);
            setTruck(todayAssignment.truckID);
            return;
          }
        } catch (debugErr) {
          console.error("Debug fetch error:", debugErr);
        }
      }
      
      if (data.success && data.truck) {
        console.log("Truck assigned:", data.truck);
        setTruck(data.truck);
      } else {
        console.log("No truck assigned");
        setTruck(null);
      }
    } catch (err) {
      console.error("Error fetching assignment:", err);
      setTruck(null);
    } finally {
      setLoading(false);
    }
  };

  // Socket connection for live updates
  useEffect(() => {
    if (!truck?._id) return; // Don't connect socket if no truck assigned

    const socket = io("http://localhost:5000");

    socket.emit("joinDriverRoom", driverID);

    // Listen for truck updates
    socket.on("update-truck-location", ({ truckID, lat, lon, status }) => {
      if (truckID === truck._id) {
        setTruck((prev) => ({
          ...prev,
          currentLocation: { coordinates: [lon, lat] },
          status: status,
        }));
      }
    });

    // Send driver device location if assigned
    const sendLocationInterval = setInterval(() => {
      if (truck?.status === "assigned" && navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            console.log("Sending location:", pos.coords.latitude, pos.coords.longitude);
            socket.emit("send-location", {
              truckID: truck._id,
              lat: pos.coords.latitude,
              lon: pos.coords.longitude,
            });
          },
          (err) => console.error("Geolocation error:", err),
          { enableHighAccuracy: true }
        );
      }
    }, 5000);

    return () => {
      clearInterval(sendLocationInterval);
      socket.disconnect();
    };
  }, [driverID, truck?._id, truck?.status]);

  // Initial fetch
  useEffect(() => {
    fetchBranches();
    fetchAssignment();
  }, [driverID]);

  const markers = [
    ...branches
      .filter((b) => b.location?.coordinates)
      .map((b) => [b.location.coordinates[1], b.location.coordinates[0]]),
    ...(truck?.currentLocation?.coordinates
      ? [[truck.currentLocation.coordinates[1], truck.currentLocation.coordinates[0]]]
      : []),
  ];

  const defaultCenter = [6.9271, 79.8612]; // Colombo fallback

  return (
    <div style={{ position: "fixed", top: 0, left: 0, width: "100%", height: "100%", zIndex: 0 }}>
      <MapContainer center={defaultCenter} zoom={12} style={{ height: "100%", width: "100%" }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

        {/* Branch markers */}
        {branches.map((b) => {
          const coords = b.location?.coordinates;
          if (!coords) return null;
          const [lon, lat] = coords;
          return (
            <Marker key={b._id} position={[lat, lon]} icon={branchIcon}>
              <Popup>
                <b>Branch:</b> {b.branchName || b.name}
              </Popup>
            </Marker>
          );
        })}

        {/* Truck marker */}
        {truck?.currentLocation?.coordinates && (
          <Marker
            position={[truck.currentLocation.coordinates[1], truck.currentLocation.coordinates[0]]}
            icon={truckIcon}
          >
            <Popup>
              <b>Plate No:</b> {truck.plateNo || truck.truckNumber || "N/A"}<br/>
              <b>Colour:</b> {truck.colour || "N/A"}<br/>
              <b>Status:</b> {truck.status || "idle"}
            </Popup>
          </Marker>
        )}

        <FitBounds markers={markers} />
      </MapContainer>

      {/* No assigned truck banner */}
      {!loading && !truck && (
        <div
          style={{
            position: "absolute",
            top: "20px",
            left: "50%",
            transform: "translateX(-50%)",
            width: "90%",
            maxWidth: "600px",
            zIndex: 1000,
            background: "white",
            color: "#333",
            textAlign: "center",
            padding: "14px 20px",
            borderRadius: "16px",
            fontSize: "1.1rem",
            fontWeight: "600",
            boxShadow: "0 6px 20px rgba(0,0,0,0.15)",
            backdropFilter: "blur(10px)",
            fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
          }}
        >
          No assigned truck today
        </div>
      )}
    </div>
  );
}