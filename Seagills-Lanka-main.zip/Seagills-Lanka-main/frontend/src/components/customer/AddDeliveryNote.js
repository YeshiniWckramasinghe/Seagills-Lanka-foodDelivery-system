// components/customer/AddDeliveryNote.js
// SPRINT 1 - User Story 2: Customer adds short note with request

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import '../../styles/AddDeliveryNote.css';

const AddDeliveryNote = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);
  const [orderDetails, setOrderDetails] = useState(null);
  const [loadingOrder, setLoadingOrder] = useState(true);

  // Fetch order details on component mount
  useEffect(() => {
    fetchOrderDetails();
  }, [orderId]);

  const fetchOrderDetails = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}`);
      const result = await response.json();
      
      if (result.success) {
        setOrderDetails(result.data.order);
        setNote(result.data.order.note || '');
      } else {
        toast.error('Order not found');
        navigate('/customer/request');
      }
    } catch (error) {
      console.error('Error fetching order:', error);
      toast.error('Failed to load order details');
    } finally {
      setLoadingOrder(false);
    }
  };

  const handleNoteChange = (e) => {
    setNote(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!note.trim()) {
      toast.error('Please enter a delivery note');
      return;
    }

    if (note.trim().length > 500) {
      toast.error('Note must be less than 500 characters');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}/note`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ note: note.trim() })
      });

      const result = await response.json();

      if (result.success) {
        toast.success('Delivery instructions updated successfully!');
        // Navigate to status page
        navigate(`/customer/status/${orderId}`);
      } else {
        toast.error(result.message || 'Failed to update note');
      }
    } catch (error) {
      console.error('Error updating note:', error);
      toast.error('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (loadingOrder) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading order details...</p>
      </div>
    );
  }

  return (
    <div className="add-note-container">
      <div className="add-note-card">
        <h2>Add Delivery Instructions</h2>
        <p className="subtitle">Provide special instructions for your delivery</p>

        {/* Order Summary */}
        {orderDetails && (
          <div className="order-summary">
            <h3>Order Details</h3>
            <div className="order-info">
              <p><strong>Order ID:</strong> {orderDetails._id}</p>
              <p><strong>Location:</strong> {orderDetails.customerLocation}</p>
              <p><strong>Contact:</strong> {orderDetails.contactNum}</p>
              <p><strong>Status:</strong> 
                <span className={`status ${orderDetails.status || 'pending'}`}>
                  {orderDetails.status || 'Pending'}
                </span>
              </p>
              <p><strong>Requested:</strong> {new Date(orderDetails.createdAt).toLocaleString()}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="note-form">
          <div className="form-group">
            <label htmlFor="deliveryNote">
              Special Delivery Instructions <span className="required">*</span>
            </label>
            <textarea
              id="deliveryNote"
              value={note}
              onChange={handleNoteChange}
              placeholder="Enter special delivery instructions (e.g., 'Please call when you arrive', 'Apartment 5B', 'Use back entrance', etc.)"
              required
              minLength={1}
              maxLength={500}
              rows={6}
            />
            <small className="char-count">{note.length}/500 characters</small>
          </div>

          {/* Examples */}
          <div className="examples-section">
            <h4>Example Instructions:</h4>
            <ul>
              <li>"Please call when you arrive - I'm on the 3rd floor"</li>
              <li>"Use the back entrance, apartment 5B"</li>
              <li>"I'm at the office building reception"</li>
              <li>"Please wait at the main gate"</li>
              <li>"Ring the doorbell twice"</li>
            </ul>
          </div>

          <div className="form-actions">
            <button
              type="button"
              onClick={() => navigate(`/customer/status/${orderId}`)}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !note.trim()}
              className="btn-submit"
            >
              {loading ? 'Updating...' : 'Update Instructions'}
            </button>
          </div>
        </form>

        {/* Information Panel */}
        <div className="info-panel">
          <h4>Important Notes:</h4>
          <ul>
            <li>You can update delivery instructions anytime before delivery</li>
            <li>Clear instructions help coordinators find you quickly</li>
            <li>Include contact preferences and location details</li>
            <li>Maximum 500 characters allowed</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AddDeliveryNote;
