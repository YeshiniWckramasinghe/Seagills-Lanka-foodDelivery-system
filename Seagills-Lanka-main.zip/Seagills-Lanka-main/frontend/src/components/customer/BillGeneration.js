// components/customer/BillGeneration.js
// SPRINT 3 - User Story 7: Customer receives bill after delivery

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import '../styles/BillGeneration.css';

const BillGeneration = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [orderDetails, setOrderDetails] = useState(null);
  const [bill, setBill] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    fetchOrderDetails();
  }, [orderId]);

  const fetchOrderDetails = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}`);
      const result = await response.json();
      
      if (result.success) {
        setOrderDetails(result.data);
        
        // Check if bill is already generated
        if (result.data.order.billGenerated) {
          // Fetch existing bill or generate display from order data
          generateBillDisplay(result.data);
        }
      } else {
        toast.error('Order not found');
        navigate('/customer/request');
      }
    } catch (error) {
      console.error('Error fetching order:', error);
      toast.error('Failed to load order details');
    } finally {
      setLoading(false);
    }
  };

  const generateBillDisplay = (orderData) => {
    // Generate bill from order data
    const order = orderData.order;
    const products = orderData.products || [];
    
    let subtotal = 0;
    const billItems = products.map(item => {
      const itemTotal = item.quantity * (item.productID.price || 0);
      subtotal += itemTotal;
      return {
        productName: item.productID.productName || 'Product',
        quantity: item.quantity,
        unitPrice: item.productID.price || 0,
        total: itemTotal
      };
    });

    const deliveryFee = 200; // Standard delivery fee
    const total = subtotal + deliveryFee;

    setBill({
      orderId: order._id,
      billNumber: `BILL-${order._id.slice(-8)}`,
      customerLocation: order.customerLocation,
      contactNum: order.contactNum,
      deliveryDate: order.deliveredAt || new Date(),
      items: billItems,
      subtotal: subtotal,
      deliveryFee: deliveryFee,
      totalAmount: total,
      paymentStatus: order.paymentStatus || 'pending'
    });
  };

  const requestBill = async () => {
    if (orderDetails.order.status !== 'delivered') {
      toast.error('Bill can only be generated after delivery is completed');
      return;
    }

    setGenerating(true);
    
    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}/generate-bill`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          deliveryConfirmed: true
        })
      });

      const result = await response.json();
      
      if (result.success) {
        setBill(result.data);
        toast.success('Bill generated successfully!');
      } else {
        toast.error(result.message || 'Failed to generate bill');
      }
    } catch (error) {
      console.error('Error generating bill:', error);
      toast.error('Failed to generate bill');
    } finally {
      setGenerating(false);
    }
  };

  const downloadBill = () => {
    if (!bill) return;
    
    // Create printable bill content
    const billContent = `
      SEAGILLS LANKA
      Delivery Bill
      
      Bill No: ${bill.billNumber}
      Order ID: ${bill.orderId}
      Date: ${new Date(bill.deliveryDate).toLocaleDateString()}
      
      Customer Details:
      Location: ${bill.customerLocation}
      Contact: ${bill.contactNum}
      
      Items:
      ${bill.items.map(item => 
        `${item.productName} - ${item.quantity} x Rs.${item.unitPrice} = Rs.${item.total}`
      ).join('\n')}
      
      Subtotal: Rs.${bill.subtotal}
      Delivery Fee: Rs.${bill.deliveryFee}
      Total Amount: Rs.${bill.totalAmount}
      
      Payment Status: ${bill.paymentStatus}
      
      Thank you for choosing Seagills Lanka!
    `;
    
    const blob = new Blob([billContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bill-${bill.billNumber}.txt`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast.success('Bill downloaded successfully');
  };

  const printBill = () => {
    if (!bill) return;
    
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Bill - ${bill.billNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            .header { text-align: center; margin-bottom: 30px; }
            .company-name { font-size: 24px; font-weight: bold; }
            .bill-title { font-size: 18px; margin-top: 10px; }
            .bill-info { margin: 20px 0; }
            .items-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            .items-table th, .items-table td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
            .total-section { margin-top: 20px; text-align: right; }
            .total-row { margin: 5px 0; }
            .grand-total { font-weight: bold; font-size: 18px; }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="company-name">SEAGILLS LANKA</div>
            <div class="bill-title">Delivery Bill</div>
          </div>
          
          <div class="bill-info">
            <p><strong>Bill No:</strong> ${bill.billNumber}</p>
            <p><strong>Order ID:</strong> ${bill.orderId}</p>
            <p><strong>Date:</strong> ${new Date(bill.deliveryDate).toLocaleDateString()}</p>
            <p><strong>Customer Location:</strong> ${bill.customerLocation}</p>
            <p><strong>Contact:</strong> ${bill.contactNum}</p>
          </div>
          
          <table class="items-table">
            <thead>
              <tr>
                <th>Item</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              ${bill.items.map(item => `
                <tr>
                  <td>${item.productName}</td>
                  <td>${item.quantity}</td>
                  <td>Rs.${item.unitPrice}</td>
                  <td>Rs.${item.total}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          
          <div class="total-section">
            <div class="total-row">Subtotal: Rs.${bill.subtotal}</div>
            <div class="total-row">Delivery Fee: Rs.${bill.deliveryFee}</div>
            <div class="total-row grand-total">Total Amount: Rs.${bill.totalAmount}</div>
            <div class="total-row">Payment Status: ${bill.paymentStatus}</div>
          </div>
          
          <div style="text-align: center; margin-top: 40px;">
            <p>Thank you for choosing Seagills Lanka!</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading order details...</p>
      </div>
    );
  }

  return (
    <div className="bill-generation-container">
      <div className="bill-header">
        <h1>Order Bill</h1>
        <button
          onClick={() => navigate('/customer/request')}
          className="btn-back"
        >
          Back to Orders
        </button>
      </div>

      {/* Order Summary */}
      {orderDetails && (
        <div className="order-summary-section">
          <h3>Order Summary</h3>
          <div className="order-info">
            <p><strong>Order ID:</strong> {orderDetails.order._id}</p>
            <p><strong>Status:</strong> 
              <span className={`status ${orderDetails.order.status}`}>
                {orderDetails.order.status}
              </span>
            </p>
            <p><strong>Location:</strong> {orderDetails.order.customerLocation}</p>
            <p><strong>Contact:</strong> {orderDetails.order.contactNum}</p>
            <p><strong>Order Date:</strong> {new Date(orderDetails.order.createdAt).toLocaleString()}</p>
            {orderDetails.order.deliveredAt && (
              <p><strong>Delivered:</strong> {new Date(orderDetails.order.deliveredAt).toLocaleString()}</p>
            )}
          </div>
        </div>
      )}

      {/* Bill Generation Section */}
      {!bill && orderDetails.order.status === 'delivered' && (
        <div className="generate-bill-section">
          <h3>Generate Bill</h3>
          <p>Your order has been delivered successfully. Click below to generate your bill.</p>
          <button
            onClick={requestBill}
            disabled={generating}
            className="btn-generate"
          >
            {generating ? 'Generating Bill...' : 'Generate Bill'}
          </button>
        </div>
      )}

      {/* Bill Not Ready */}
      {!bill && orderDetails.order.status !== 'delivered' && (
        <div className="bill-not-ready">
          <h3>Bill Not Available</h3>
          <p>Your bill will be available after the order is delivered.</p>
          <p>Current status: <strong>{orderDetails.order.status}</strong></p>
          <button
            onClick={() => navigate(`/customer/status/${orderId}`)}
            className="btn-check-status"
          >
            Check Order Status
          </button>
        </div>
      )}

      {/* Bill Display */}
      {bill && (
        <div className="bill-display">
          <div className="bill-header-section">
            <div className="company-header">
              <h2>SEAGILLS LANKA</h2>
              <p>Delivery Bill</p>
            </div>
            <div className="bill-actions">
              <button onClick={printBill} className="btn-print">
                Print Bill
              </button>
              <button onClick={downloadBill} className="btn-download">
                Download
              </button>
            </div>
          </div>

          <div className="bill-content">
            <div className="bill-details">
              <div className="detail-row">
                <span>Bill Number:</span>
                <span>{bill.billNumber}</span>
              </div>
              <div className="detail-row">
                <span>Order ID:</span>
                <span>{bill.orderId}</span>
              </div>
              <div className="detail-row">
                <span>Date:</span>
                <span>{new Date(bill.deliveryDate).toLocaleDateString()}</span>
              </div>
              <div className="detail-row">
                <span>Customer Location:</span>
                <span>{bill.customerLocation}</span>
              </div>
              <div className="detail-row">
                <span>Contact Number:</span>
                <span>{bill.contactNum}</span>
              </div>
            </div>

            {bill.items.length > 0 && (
              <div className="items-section">
                <h4>Items Ordered:</h4>
                <div className="items-table">
                  <div className="table-header">
                    <span>Item</span>
                    <span>Qty</span>
                    <span>Unit Price</span>
                    <span>Total</span>
                  </div>
                  {bill.items.map((item, index) => (
                    <div key={index} className="table-row">
                      <span>{item.productName}</span>
                      <span>{item.quantity}</span>
                      <span>Rs.{item.unitPrice}</span>
                      <span>Rs.{item.total}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="totals-section">
              <div className="total-row">
                <span>Subtotal:</span>
                <span>Rs.{bill.subtotal}</span>
              </div>
              <div className="total-row">
                <span>Delivery Fee:</span>
                <span>Rs.{bill.deliveryFee}</span>
              </div>
              <div className="total-row grand-total">
                <span>Total Amount:</span>
                <span>Rs.{bill.totalAmount}</span>
              </div>
              <div className="total-row">
                <span>Payment Status:</span>
                <span className={`payment-status ${bill.paymentStatus}`}>
                  {bill.paymentStatus}
                </span>
              </div>
            </div>

            <div className="thank-you">
              <p>Thank you for choosing Seagills Lanka!</p>
              <p>We hope to serve you again soon.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BillGeneration;
