// components/customer/CustomerRequestForm.js
// SPRINT 1 - User Story 1: Customer sends on-route stop request

import React, { useState } from 'react';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
// Correct import path
import '../../styles/CustomerRequestForm.css';

const CustomerRequestForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    customerLocation: '',
    contactNum: '',
    note: '',
    products: []
  });
  const [loading, setLoading] = useState(false);
  const [productForm, setProductForm] = useState({
    productID: '',
    quantity: 1
  });

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle product form changes
  const handleProductChange = (e) => {
    const { name, value } = e.target;
    setProductForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Add product to request
  const addProduct = () => {
    if (!productForm.productID || productForm.quantity <= 0) {
      toast.error('Please enter valid product details');
      return;
    }

    const newProduct = {
      productID: productForm.productID,
      quantity: parseInt(productForm.quantity)
    };

    setFormData(prev => ({
      ...prev,
      products: [...prev.products, newProduct]
    }));

    // Reset product form
    setProductForm({ productID: '', quantity: 1 });
    toast.success('Product added to request');
  };

  // Remove product from request
  const removeProduct = (index) => {
    setFormData(prev => ({
      ...prev,
      products: prev.products.filter((_, i) => i !== index)
    }));
    toast.info('Product removed');
  };

  // Submit the request
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('http://localhost:5000/api/enroute-orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      });

      const result = await response.json();

      if (result.success) {
        toast.success('Stop request submitted successfully!');
        // Redirect to status page or add note page
        navigate(`/customer/status/${result.data.order._id}`);
      } else {
        toast.error(result.message || 'Failed to submit request');
      }
    } catch (error) {
      console.error('Error submitting request:', error);
      toast.error('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="customer-request-container">
      <div className="request-card">
        <h2>On-Route Stop Request</h2>
        <p className="subtitle">Request food delivery to your location</p>

        <form onSubmit={handleSubmit} className="request-form">
          {/* Customer Location */}
          <div className="form-group">
            <label htmlFor="customerLocation">
              Delivery Location <span className="required">*</span>
            </label>
            <textarea
              id="customerLocation"
              name="customerLocation"
              value={formData.customerLocation}
              onChange={handleInputChange}
              placeholder="Enter your complete address (minimum 5 characters)"
              required
              minLength={5}
              maxLength={200}
              rows={3}
            />
          </div>

          {/* Contact Number */}
          <div className="form-group">
            <label htmlFor="contactNum">
              Contact Number <span className="required">*</span>
            </label>
            <input
              type="tel"
              id="contactNum"
              name="contactNum"
              value={formData.contactNum}
              onChange={handleInputChange}
              placeholder="0712345678"
              required
              pattern="^0[0-9]{8,9}$"
              title="Please enter a valid Sri Lankan phone number"
            />
          </div>

          {/* Delivery Note */}
          <div className="form-group">
            <label htmlFor="note">
              Special Delivery Instructions (Optional)
            </label>
            <textarea
              id="note"
              name="note"
              value={formData.note}
              onChange={handleInputChange}
              placeholder="Any special instructions for delivery (e.g., call when you arrive, apartment number, etc.)"
              maxLength={500}
              rows={3}
            />
            <small className="char-count">{formData.note.length}/500 characters</small>
          </div>

          {/* Products Section */}
          <div className="form-group">
            <label>Products (Optional)</label>
            
            {/* Add Product Form */}
            <div className="product-form">
              <div className="product-inputs">
                <input
                  type="text"
                  name="productID"
                  value={productForm.productID}
                  onChange={handleProductChange}
                  placeholder="Product Name"
                />
                <input
                  type="number"
                  name="quantity"
                  value={productForm.quantity}
                  onChange={handleProductChange}
                  min="1"
                  max="1000"
                  placeholder="Quantity"
                />
                <button
                  type="button"
                  onClick={addProduct}
                  className="btn-add-product"
                >
                  Add
                </button>
              </div>
            </div>

            {/* Display Added Products */}
            {formData.products.length > 0 && (
              <div className="products-list">
                <h4>Added Products:</h4>
                {formData.products.map((product, index) => (
                  <div key={index} className="product-item">
                    <span>Product ID: {product.productID}</span>
                    <span>Quantity: {product.quantity}</span>
                    <button
                      type="button"
                      onClick={() => removeProduct(index)}
                      className="btn-remove"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Submit Button */}
          <div className="form-actions">
            <button
              type="submit"
              disabled={loading}
              className="btn-submit"
            >
              {loading ? 'Submitting...' : 'Submit Stop Request'}
            </button>
          </div>
        </form>

        {/* Information Panel */}
        <div className="info-panel">
          <h4>What happens next?</h4>
          <ul>
            <li>Your request will be sent to available delivery coordinators</li>
            <li>You'll receive a confirmation with your request ID</li>
            <li>A coordinator will accept or reject your request</li>
            <li>You can track your request status and add notes if needed</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default CustomerRequestForm;


