// components/customer/RequestStatusCheck.js
// SPRINT 2 - User Story 5: Customer knows if request is accepted or rejected

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import '../../styles/RequestStatusCheck.css';

const RequestStatusCheck = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [statusData, setStatusData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchRequestStatus();
    // Set up polling for real-time status updates
    const interval = setInterval(fetchRequestStatus, 30000); // Poll every 30 seconds
    return () => clearInterval(interval);
  }, [orderId]);

  const fetchRequestStatus = async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);

    try {
      const response = await fetch(`http://localhost:5000/api/enroute-orders/${orderId}/status`);
      const result = await response.json();
      
      if (result.success) {
        setStatusData(result.data);
        if (isRefresh) {
          toast.success('Status updated');
        }
      } else {
        toast.error('Request not found');
        navigate('/customer/request');
      }
    } catch (error) {
      console.error('Error fetching status:', error);
      toast.error('Failed to load status');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return '#ffa500';
      case 'accepted': return '#28a745';
      case 'rejected': return '#dc3545';
      case 'delivered': return '#6f42c1';
      default: return '#6c757d';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending': return '🕐';
      case 'accepted': return '✅';
      case 'rejected': return '❌';
      case 'delivered': return '📦';
      default: return '❓';
    }
  };

  const handleAddNote = () => {
    navigate(`/customer/add-note/${orderId}`);
  };

  const handleCallCoordinator = () => {
    if (statusData.coordinator && statusData.coordinator.contact) {
      window.location.href = `tel:${statusData.coordinator.contact}`;
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading request status...</p>
      </div>
    );
  }

  return (
    <div className="status-check-container">
      <div className="status-card">
        <div className="status-header">
          <h2>Request Status</h2>
          <button
            onClick={() => fetchRequestStatus(true)}
            disabled={refreshing}
            className="btn-refresh"
          >
            {refreshing ? 'Refreshing...' : 'Refresh'}
          </button>
        </div>

        {/* Request Details */}
        <div className="request-info">
          <h3>Order #{statusData.orderId.slice(-8)}</h3>
          <div className="info-grid">
            <div className="info-item">
              <label>Location:</label>
              <span>{statusData.customerLocation}</span>
            </div>
            <div className="info-item">
              <label>Contact:</label>
              <span>{statusData.contactNum}</span>
            </div>
            <div className="info-item">
              <label>Requested:</label>
              <span>{new Date(statusData.requestDate).toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Status Display */}
        <div className="status-display">
          <div 
            className="status-badge"
            style={{ backgroundColor: getStatusColor(statusData.status) }}
          >
            <span className="status-icon">{getStatusIcon(statusData.status)}</span>
            <span className="status-text">{statusData.status.toUpperCase()}</span>
          </div>
        </div>

        {/* Status-specific Information */}
        {statusData.status === 'pending' && (
          <div className="status-details pending">
            <h4>Your request is being processed</h4>
            <p>We're looking for an available delivery coordinator in your area. You'll be notified as soon as someone accepts your request.</p>
            
            <div className="pending-actions">
              <button onClick={handleAddNote} className="btn-secondary">
                Add/Update Delivery Instructions
              </button>
            </div>
          </div>
        )}

        {statusData.status === 'accepted' && (
          <div className="status-details accepted">
            <h4>Great news! Your request has been accepted</h4>
            
            <div className="coordinator-info">
              <h5>Delivery Coordinator</h5>
              <p><strong>Name:</strong> {statusData.coordinator.name}</p>
              <p><strong>Contact:</strong> {statusData.coordinator.contact}</p>
              
              {statusData.estimatedArrival && (
                <p><strong>Estimated Arrival:</strong> {new Date(statusData.estimatedArrival).toLocaleString()}</p>
              )}
              
              {statusData.notes && (
                <p><strong>Coordinator Notes:</strong> {statusData.notes}</p>
              )}
            </div>

            <div className="accepted-actions">
              <button onClick={handleCallCoordinator} className="btn-call">
                Call Coordinator
              </button>
              <button onClick={handleAddNote} className="btn-secondary">
                Update Instructions
              </button>
            </div>
          </div>
        )}

        {statusData.status === 'rejected' && (
          <div className="status-details rejected">
            <h4>Sorry, your request couldn't be processed</h4>
            <p><strong>Reason:</strong> {statusData.rejectionReason}</p>
            <p><strong>Rejected at:</strong> {new Date(statusData.rejectedAt).toLocaleString()}</p>
            
            <div className="rejected-actions">
              <button 
                onClick={() => navigate('/customer/request')}
                className="btn-primary"
              >
                Submit New Request
              </button>
            </div>

            <div className="alternatives">
              <h5>What you can do:</h5>
              <ul>
                <li>Try submitting a new request with a different location</li>
                <li>Contact our support team for assistance</li>
                <li>Check back later when more coordinators might be available</li>
              </ul>
            </div>
          </div>
        )}

        {statusData.status === 'delivered' && (
          <div className="status-details delivered">
            <h4>Order Delivered Successfully!</h4>
            <p>Thank you for using our service.</p>
            
            <div className="delivered-actions">
              <button 
                onClick={() => navigate(`/customer/bill/${orderId}`)}
                className="btn-primary"
              >
                View Bill
              </button>
              <button 
                onClick={() => navigate('/customer/request')}
                className="btn-secondary"
              >
                New Request
              </button>
            </div>
          </div>
        )}

        {/* Timeline */}
        <div className="status-timeline">
          <h4>Request Timeline</h4>
          <div className="timeline">
            <div className="timeline-item completed">
              <div className="timeline-dot"></div>
              <div className="timeline-content">
                <h5>Request Submitted</h5>
                <p>{new Date(statusData.requestDate).toLocaleString()}</p>
              </div>
            </div>

            {statusData.acceptedAt && (
              <div className="timeline-item completed">
                <div className="timeline-dot"></div>
                <div className="timeline-content">
                  <h5>Request Accepted</h5>
                  <p>{new Date(statusData.acceptedAt).toLocaleString()}</p>
                </div>
              </div>
            )}

            {statusData.rejectedAt && (
              <div className="timeline-item rejected">
                <div className="timeline-dot"></div>
                <div className="timeline-content">
                  <h5>Request Rejected</h5>
                  <p>{new Date(statusData.rejectedAt).toLocaleString()}</p>
                </div>
              </div>
            )}

            {statusData.status === 'pending' && (
              <div className="timeline-item pending">
                <div className="timeline-dot"></div>
                <div className="timeline-content">
                  <h5>Awaiting Coordinator</h5>
                  <p>Looking for available coordinator...</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Help Section */}
        <div className="help-section">
          <h4>Need Help?</h4>
          <div className="help-options">
            <button className="help-btn">Contact Support</button>
            <button className="help-btn">FAQ</button>
            <button className="help-btn">Track Another Order</button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default RequestStatusCheck; 