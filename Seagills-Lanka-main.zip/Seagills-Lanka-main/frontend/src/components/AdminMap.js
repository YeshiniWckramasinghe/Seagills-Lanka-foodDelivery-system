import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import io from "socket.io-client";
import "leaflet/dist/leaflet.css";

const truckIcon = L.icon({
  iconUrl: "/images/truck.png",
  iconSize: [45, 45],
  iconAnchor: [22, 22],
});

const branchIcon = L.icon({
  iconUrl: "/images/branch.png",
  iconSize: [40, 40],
  iconAnchor: [20, 40],
});

function FitBounds({ markers }) {
  const map = useMap();
  useEffect(() => {
    if (markers.length > 0) {
      const bounds = L.latLngBounds(markers);
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [markers, map]);
  return null;
}

function RoutePolylineComponent({ routeLayer, map }) {
  useEffect(() => {
    if (routeLayer) {
      setTimeout(() => {
        if (map && routeLayer.getBounds) {
          map.flyToBounds(routeLayer.getBounds(), { padding: [60, 60], maxZoom: 15 });
        }
      }, 100);
    }
  }, [routeLayer, map]);
  return null;
}

export default function AdminMap() {
  const [trucks, setTrucks] = useState([]);
  const [branches, setBranches] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [routePopup, setRoutePopup] = useState(null);
  const [routeLayer, setRouteLayer] = useState(null);
  const [mapInstance, setMapInstance] = useState(null);
  
  // Filter states
  const [filterType, setFilterType] = useState("all");
  const [selectedTruck, setSelectedTruck] = useState("");
  const [selectedBranch, setSelectedBranch] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [truckRes, branchRes, assignmentRes] = await Promise.all([
          fetch("http://localhost:5000/api/trucks"),
          fetch("http://localhost:5000/api/branches"),
          fetch("http://localhost:5000/api/assigned-trucks"),
        ]);

        const truckData = await truckRes.json();
        const branchData = await branchRes.json();
        const assignmentData = await assignmentRes.json();

        setTrucks(truckData);
        setBranches(branchData);
        setAssignments(assignmentData.assignments || []);
      } catch (err) {
        console.error("Error fetching data:", err);
      }
    };

    fetchData();

    const socket = io("http://localhost:5000");
    socket.on("update-truck-location", ({ truckID, lat, lon }) => {
      setTrucks((prev) =>
        prev.map((t) =>
          t._id === truckID
            ? { ...t, currentLocation: { coordinates: [lon, lat] } }
            : t
        )
      );
    });

    return () => socket.disconnect();
  }, []);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const isAssignedToday = (truckID) => {
    return assignments.some(
      (a) =>
        a.truckID._id === truckID &&
        new Date(a.date).setHours(0, 0, 0, 0) === today.getTime()
    );
  };

  const getTruckBranch = (truckID) => {
    // Find the truck and get its branchID directly from the truck model
    const truck = trucks.find((t) => t._id === truckID);
    if (!truck || !truck.branchID) return null;
    return typeof truck.branchID === 'object' ? truck.branchID._id : truck.branchID;
  };

  const getBranchTrucks = (branchID) => {
    // Get all trucks that belong to this branch (from truck.branchID field)
    return trucks
      .filter((t) => {
        if (!t.branchID) return false;
        const truckBranchID = typeof t.branchID === 'object' ? t.branchID._id : t.branchID;
        return truckBranchID === branchID;
      })
      .map((t) => t._id);
  };

  // Filter logic
  const getFilteredTrucks = () => {
    if (filterType === "all") return trucks;
    if (filterType === "truck" && selectedTruck) {
      return trucks.filter((t) => t._id === selectedTruck);
    }
    if (filterType === "branch" && selectedBranch) {
      const branchTruckIDs = getBranchTrucks(selectedBranch);
      return trucks.filter((t) => branchTruckIDs.includes(t._id));
    }
    return trucks;
  };

  const getFilteredBranches = () => {
    if (filterType === "all") return branches;
    if (filterType === "truck" && selectedTruck) {
      const branchID = getTruckBranch(selectedTruck);
      return branches.filter((b) => b._id === branchID);
    }
    if (filterType === "branch" && selectedBranch) {
      return branches.filter((b) => b._id === selectedBranch);
    }
    return branches;
  };

  const filteredTrucks = getFilteredTrucks();
  const filteredBranches = getFilteredBranches();

  const handleBranchClick = (branch) => {
    fetch(`http://localhost:5000/api/routes?branchID=${branch._id}`)
      .then((res) => res.json())
      .then((routes) => {
        setRoutePopup({ branch, routes });
      })
      .catch((err) => console.error("Error fetching routes:", err));
  };

  const handleRouteSelect = (route) => {
    if (routeLayer) {
      mapInstance.removeLayer(routeLayer);
      setRouteLayer(null);
    }

    const start = `${route.start.location.coordinates[0]},${route.start.location.coordinates[1]}`;
    const end = `${route.end.location.coordinates[0]},${route.end.location.coordinates[1]}`;

    fetch(`http://localhost:5000/api/route?start=${start}&end=${end}`)
      .then((r) => r.json())
      .then((data) => {
        const feat = data.features?.[0];
        if (!feat) return;

        const coords = feat.geometry.coordinates.map((c) => [c[1], c[0]]);
        const polyline = L.polyline(coords, { color: "red", weight: 5 }).addTo(
          mapInstance
        );
        setRouteLayer(polyline);
      })
      .catch((err) => console.error("Error fetching route:", err));
  };

  const closeRoutePopup = () => {
    setRoutePopup(null);
    if (routeLayer) {
      mapInstance.removeLayer(routeLayer);
      setRouteLayer(null);
    }
  };

  const handleFilterTypeChange = (type) => {
    setFilterType(type);
    setSelectedTruck("");
    setSelectedBranch("");
    closeRoutePopup();
  };

  const markers = [
    ...filteredTrucks
      .filter((t) => t.currentLocation?.coordinates)
      .map((t) => [
        t.currentLocation.coordinates[1],
        t.currentLocation.coordinates[0],
      ]),
    ...filteredBranches
      .filter((b) => b.location?.coordinates)
      .map((b) => [b.location.coordinates[1], b.location.coordinates[0]]),
  ];

  const defaultCenter = [6.9271, 79.8612];

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        zIndex: 0,
        margin: 0,
        padding: 0,
        boxSizing: "border-box",
      }}
    >
      {/* Filter Bar - Horizontal at top */}
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          background: "#fff",
          padding: "12px 20px",
          zIndex: 9999,
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
          fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
          display: "flex",
          alignItems: "center",
          gap: "12px",
          flexWrap: "wrap",
        }}
      >
        <span
          style={{
            fontSize: "15px",
            fontWeight: 600,
            color: "#333",
          }}
        >
          Filter:
        </span>

        {/* Filter Type Buttons */}
        <div style={{ display: "flex", gap: "6px" }}>
          <button
            onClick={() => handleFilterTypeChange("all")}
            style={{
              padding: "10px 12px",
              border: "none",
              borderRadius: "8px",
              background: filterType === "all" ? "#e6e6e6" : "#f8f8f8",
              color: "#333",
              cursor: "pointer",
              fontSize: "14px",
              transition: "background 0.2s, box-shadow 0.2s",
              boxShadow: filterType === "all" ? "inset 0 0 0 1px #ccc" : "none",
            }}
            onMouseEnter={(e) => {
              if (filterType !== "all") {
                e.target.style.background = "#e6e6e6";
                e.target.style.boxShadow = "inset 0 0 0 1px #ccc";
              }
            }}
            onMouseLeave={(e) => {
              if (filterType !== "all") {
                e.target.style.background = "#f8f8f8";
                e.target.style.boxShadow = "none";
              }
            }}
          >
            Show All
          </button>
          <button
            onClick={() => handleFilterTypeChange("truck")}
            style={{
              padding: "10px 12px",
              border: "none",
              borderRadius: "8px",
              background: filterType === "truck" ? "#e6e6e6" : "#f8f8f8",
              color: "#333",
              cursor: "pointer",
              fontSize: "14px",
              transition: "background 0.2s, box-shadow 0.2s",
              boxShadow: filterType === "truck" ? "inset 0 0 0 1px #ccc" : "none",
            }}
            onMouseEnter={(e) => {
              if (filterType !== "truck") {
                e.target.style.background = "#e6e6e6";
                e.target.style.boxShadow = "inset 0 0 0 1px #ccc";
              }
            }}
            onMouseLeave={(e) => {
              if (filterType !== "truck") {
                e.target.style.background = "#f8f8f8";
                e.target.style.boxShadow = "none";
              }
            }}
          >
            By Truck
          </button>
          <button
            onClick={() => handleFilterTypeChange("branch")}
            style={{
              padding: "10px 12px",
              border: "none",
              borderRadius: "8px",
              background: filterType === "branch" ? "#e6e6e6" : "#f8f8f8",
              color: "#333",
              cursor: "pointer",
              fontSize: "14px",
              transition: "background 0.2s, box-shadow 0.2s",
              boxShadow: filterType === "branch" ? "inset 0 0 0 1px #ccc" : "none",
            }}
            onMouseEnter={(e) => {
              if (filterType !== "branch") {
                e.target.style.background = "#e6e6e6";
                e.target.style.boxShadow = "inset 0 0 0 1px #ccc";
              }
            }}
            onMouseLeave={(e) => {
              if (filterType !== "branch") {
                e.target.style.background = "#f8f8f8";
                e.target.style.boxShadow = "none";
              }
            }}
          >
            By Branch
          </button>
        </div>

        {/* Truck Selector */}
        {filterType === "truck" && (
          <select
            value={selectedTruck}
            onChange={(e) => setSelectedTruck(e.target.value)}
            style={{
              padding: "10px 12px",
              border: "1px solid #ddd",
              borderRadius: "8px",
              fontSize: "14px",
              background: "#f8f8f8",
              color: "#333",
              cursor: "pointer",
              minWidth: "200px",
            }}
          >
            <option value="">-- Select Truck --</option>
            {trucks.map((truck) => (
              <option key={truck._id} value={truck._id}>
                {truck.plateNo || truck.truckNumber || truck._id}
              </option>
            ))}
          </select>
        )}

        {/* Branch Selector */}
        {filterType === "branch" && (
          <select
            value={selectedBranch}
            onChange={(e) => setSelectedBranch(e.target.value)}
            style={{
              padding: "10px 12px",
              border: "1px solid #ddd",
              borderRadius: "8px",
              fontSize: "14px",
              background: "#f8f8f8",
              color: "#333",
              cursor: "pointer",
              minWidth: "200px",
            }}
          >
            <option value="">-- Select Branch --</option>
            {branches.map((branch) => (
              <option key={branch._id} value={branch._id}>
                {branch.branchName}
              </option>
            ))}
          </select>
        )}
      </div>

      <MapContainer
        center={defaultCenter}
        zoom={8}
        style={{ height: "100%", width: "100%" }}
        ref={setMapInstance}
      >
        <TileLayer 
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution="Seagills Lanka Delivery"
        />

        {filteredBranches.map((b) => {
          const coords = b.location?.coordinates;
          if (!coords) return null;
          const [lon, lat] = coords;
          return (
            <Marker
              key={b._id}
              position={[lat, lon]}
              icon={branchIcon}
              eventHandlers={{
                click: () => handleBranchClick(b),
              }}
            >
              <Popup>
                <div style={{ fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" }}>
                  <b>Branch:</b> {b.branchName}
                  <br />
                  <small>Click marker for routes</small>
                </div>
              </Popup>
            </Marker>
          );
        })}

        {filteredTrucks.map((t) => {
          const coords = t.currentLocation?.coordinates;
          if (!coords) return null;

          const status = isAssignedToday(t._id) ? "Assigned" : "Idle";

          return (
            <Marker
              key={t._id}
              position={[coords[1], coords[0]]}
              icon={truckIcon}
            >
              <Popup>
                <div style={{ fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" }}>
                  <b>Plate No:</b> {t.plateNo || t.truckNumber || "N/A"}
                  <br />
                  <b>Colour:</b> {t.colour || "N/A"}
                  <br />
                  <b>Status:</b> {status}
                </div>
              </Popup>
            </Marker>
          );
        })}

        <FitBounds markers={markers} />
        <RoutePolylineComponent routeLayer={routeLayer} map={mapInstance} />
      </MapContainer>

      {/* Branch Routes Popup */}
      {routePopup && (
        <div
          className="branch-popup"
          style={{
            position: "fixed",
            top: "60px",
            right: "20px",
            width: "280px",
            maxHeight: "400px",
            overflowY: "auto",
            background: "#fff",
            borderRadius: "14px",
            padding: "16px",
            zIndex: 9999,
            boxShadow: "0 8px 20px rgba(0,0,0,0.2)",
            fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
          }}
        >
          <div
            className="branch-popup-header"
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "12px",
            }}
          >
            <h3
              style={{
                margin: 0,
                fontSize: "18px",
                color: "#333",
                fontWeight: 600,
              }}
            >
              {routePopup.branch.branchName}
            </h3>
            <button
              id="branch-popup-close"
              onClick={closeRoutePopup}
              style={{
                background: "#f0f0f0",
                border: "none",
                color: "#555",
                fontSize: "16px",
                fontWeight: "bold",
                borderRadius: "8px",
                cursor: "pointer",
                width: "28px",
                height: "28px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                transition: "background 0.2s, color 0.2s",
              }}
              onMouseEnter={(e) => {
                e.target.style.background = "#e0e0e0";
                e.target.style.color = "#000";
              }}
              onMouseLeave={(e) => {
                e.target.style.background = "#f0f0f0";
                e.target.style.color = "#555";
              }}
            >
              ×
            </button>
          </div>

          <div>
            {routePopup.routes.length === 0 ? (
              <p style={{ color: "#6b7280", margin: "16px 0", fontSize: "14px" }}>
                No routes available.
              </p>
            ) : (
              routePopup.routes.map((route, idx) => (
                <button
                  key={idx}
                  className="route-btn"
                  onClick={() => handleRouteSelect(route)}
                  style={{
                    width: "100%",
                    textAlign: "left",
                    padding: "10px 12px",
                    marginBottom: "8px",
                    border: "none",
                    borderRadius: "8px",
                    background: "#f8f8f8",
                    color: "#333",
                    cursor: "pointer",
                    fontSize: "14px",
                    transition: "background 0.2s, box-shadow 0.2s",
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.background = "#e6e6e6";
                    e.target.style.boxShadow = "inset 0 0 0 1px #ccc";
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.background = "#f8f8f8";
                    e.target.style.boxShadow = "none";
                  }}
                  onMouseDown={(e) => {
                    e.target.style.background = "#dcdcdc";
                  }}
                  onMouseUp={(e) => {
                    e.target.style.background = "#e6e6e6";
                  }}
                >
                  {route.start.name} → {route.end.name}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}