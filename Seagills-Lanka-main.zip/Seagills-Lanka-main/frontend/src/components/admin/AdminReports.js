// components/admin/AdminReports.js
// SPRINT 3 - User Story 8: Admin generates summary report of enroute orders

import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import '../../styles/AdminReports.css';

const AdminReports = () => {
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    coordinatorId: ''
  });
  const [coordinators, setCoordinators] = useState([]);

  useEffect(() => {
    // Set default date range (last 30 days)
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);
    
    setFilters({
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0],
      coordinatorId: ''
    });

    fetchCoordinators();
    generateReport();
  }, []);

  const fetchCoordinators = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/users/role/DeliveryCoordinator');
      const result = await response.json();
      
      if (result.success) {
        setCoordinators(result.users || []);
      }
    } catch (error) {
      console.error('Error fetching coordinators:', error);
    }
  };

  const generateReport = async () => {
    setLoading(true);
    
    try {
      const queryParams = new URLSearchParams();
      if (filters.startDate) queryParams.append('startDate', filters.startDate);
      if (filters.endDate) queryParams.append('endDate', filters.endDate);
      if (filters.coordinatorId) queryParams.append('coordinatorId', filters.coordinatorId);

      const response = await fetch(`http://localhost:5000/api/enroute-orders/reports/summary?${queryParams}`);
      const result = await response.json();
      
      if (result.success) {
        setReportData(result.data);
        toast.success('Report generated successfully');
      } else {
        toast.error('Failed to generate report');
      }
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Network error while generating report');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const exportReport = () => {
    if (!reportData) return;
    
    // Create CSV content
    const csvContent = [
      ['Order ID', 'Customer Location', 'Contact', 'Status', 'Coordinator', 'Created Date', 'Action Date'].join(','),
      ...reportData.orders.map(order => [
        order._id,
        `"${order.customerLocation}"`,
        order.contactNum,
        order.status || 'pending',
        order.deliveryCoordinatorID ? 
          `"${order.deliveryCoordinatorID.firstName} ${order.deliveryCoordinatorID.lastName}"` : 'Unassigned',
        new Date(order.createdAt).toLocaleDateString(),
        order.acceptedAt ? new Date(order.acceptedAt).toLocaleDateString() : 
        order.rejectedAt ? new Date(order.rejectedAt).toLocaleDateString() : 'Pending'
      ].join(','))
    ].join('\n');

    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `enroute-orders-report-${Date.now()}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast.success('Report exported successfully');
  };

  return (
    <div className="admin-reports-container">
      <div className="reports-header">
        <h1>Enroute Orders Report</h1>
        <p>Monitor delivery performance and order trends</p>
      </div>

      {/* Filters */}
      <div className="filters-section">
        <h3>Report Filters</h3>
        <div className="filters-grid">
          <div className="filter-group">
            <label htmlFor="startDate">Start Date:</label>
            <input
              type="date"
              id="startDate"
              name="startDate"
              value={filters.startDate}
              onChange={handleFilterChange}
            />
          </div>
          
          <div className="filter-group">
            <label htmlFor="endDate">End Date:</label>
            <input
              type="date"
              id="endDate"
              name="endDate"
              value={filters.endDate}
              onChange={handleFilterChange}
            />
          </div>
          
          <div className="filter-group">
            <label htmlFor="coordinatorId">Coordinator:</label>
            <select
              id="coordinatorId"
              name="coordinatorId"
              value={filters.coordinatorId}
              onChange={handleFilterChange}
            >
              <option value="">All Coordinators</option>
              {coordinators.map(coord => (
                <option key={coord._id} value={coord._id}>
                  {coord.firstName} {coord.lastName}
                </option>
              ))}
            </select>
          </div>
          
          <div className="filter-actions">
            <button
              onClick={generateReport}
              disabled={loading}
              className="btn-generate"
            >
              {loading ? 'Generating...' : 'Generate Report'}
            </button>
          </div>
        </div>
      </div>

      {/* Report Results */}
      {reportData && (
        <div className="report-results">
          {/* Summary Statistics */}
          <div className="stats-section">
            <h3>Summary Statistics</h3>
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-number">{reportData.statistics.totalRequests}</div>
                <div className="stat-label">Total Requests</div>
              </div>
              <div className="stat-card pending">
                <div className="stat-number">{reportData.statistics.pendingRequests}</div>
                <div className="stat-label">Pending</div>
              </div>
              <div className="stat-card accepted">
                <div className="stat-number">{reportData.statistics.acceptedRequests}</div>
                <div className="stat-label">Accepted</div>
              </div>
              <div className="stat-card rejected">
                <div className="stat-number">{reportData.statistics.rejectedRequests}</div>
                <div className="stat-label">Rejected</div>
              </div>
              <div className="stat-card delivered">
                <div className="stat-number">{reportData.statistics.deliveredRequests}</div>
                <div className="stat-label">Delivered</div>
              </div>
            </div>
          </div>

          {/* Performance Chart */}
          <div className="chart-section">
            <h3>Performance Overview</h3>
            <div className="performance-chart">
              <div className="chart-bar">
                <div className="bar-section accepted" style={{
                  width: `${(reportData.statistics.acceptedRequests / reportData.statistics.totalRequests) * 100}%`
                }}>
                  <span>Accepted ({Math.round((reportData.statistics.acceptedRequests / reportData.statistics.totalRequests) * 100)}%)</span>
                </div>
                <div className="bar-section rejected" style={{
                  width: `${(reportData.statistics.rejectedRequests / reportData.statistics.totalRequests) * 100}%`
                }}>
                  <span>Rejected ({Math.round((reportData.statistics.rejectedRequests / reportData.statistics.totalRequests) * 100)}%)</span>
                </div>
                <div className="bar-section pending" style={{
                  width: `${(reportData.statistics.pendingRequests / reportData.statistics.totalRequests) * 100}%`
                }}>
                  <span>Pending ({Math.round((reportData.statistics.pendingRequests / reportData.statistics.totalRequests) * 100)}%)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Coordinator Performance */}
          {Object.keys(reportData.statistics.coordinatorPerformance).length > 0 && (
            <div className="coordinator-performance">
              <h3>Coordinator Performance</h3>
              <div className="performance-table">
                <table>
                  <thead>
                    <tr>
                      <th>Coordinator</th>
                      <th>Total Requests</th>
                      <th>Accepted</th>
                      <th>Rejected</th>
                      <th>Delivered</th>
                      <th>Acceptance Rate</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(reportData.statistics.coordinatorPerformance).map(([coordId, stats]) => (
                      <tr key={coordId}>
                        <td>{stats.name}</td>
                        <td>{stats.total}</td>
                        <td className="accepted">{stats.accepted}</td>
                        <td className="rejected">{stats.rejected}</td>
                        <td className="delivered">{stats.delivered}</td>
                        <td>
                          {stats.total > 0 ? 
                            `${Math.round((stats.accepted / stats.total) * 100)}%` : '0%'
                          }
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Recent Orders Table */}
          <div className="orders-section">
            <div className="section-header">
              <h3>Recent Orders</h3>
              <button onClick={exportReport} className="btn-export">
                Export CSV
              </button>
            </div>
            
            <div className="orders-table">
              <table>
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Customer Location</th>
                    <th>Contact</th>
                    <th>Status</th>
                    <th>Coordinator</th>
                    <th>Created</th>
                    <th>Action Date</th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.orders.slice(0, 50).map(order => (
                    <tr key={order._id}>
                      <td>#{order._id.slice(-6)}</td>
                      <td>{order.customerLocation}</td>
                      <td>{order.contactNum}</td>
                      <td>
                        <span className={`status-badge ${order.status || 'pending'}`}>
                          {order.status || 'pending'}
                        </span>
                      </td>
                      <td>
                        {order.deliveryCoordinatorID ? 
                          `${order.deliveryCoordinatorID.firstName} ${order.deliveryCoordinatorID.lastName}` : 
                          'Unassigned'
                        }
                      </td>
                      <td>{new Date(order.createdAt).toLocaleDateString()}</td>
                      <td>
                        {order.acceptedAt && new Date(order.acceptedAt).toLocaleDateString()}
                        {order.rejectedAt && new Date(order.rejectedAt).toLocaleDateString()}
                        {!order.acceptedAt && !order.rejectedAt && 'Pending'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Report Info */}
          <div className="report-info">
            <p>
              <strong>Report Generated:</strong> {new Date(reportData.reportDate).toLocaleString()}
            </p>
            <p>
              <strong>Date Range:</strong> {filters.startDate} to {filters.endDate}
            </p>
            {filters.coordinatorId && (
              <p>
                <strong>Filtered by Coordinator:</strong> {
                  coordinators.find(c => c._id === filters.coordinatorId)?.firstName + ' ' +
                  coordinators.find(c => c._id === filters.coordinatorId)?.lastName
                }
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminReports;
