import React, { useState, useEffect } from 'react';
import axios from 'axios';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable'; 
import './PreorderReport.css';

function PreorderReport() {
  const [preorders, setPreorders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Fetch all preorders
  const fetchPreorders = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/preorders', {
        headers: { Authorization: `Bearer ${token}` },
      });

      // Use the correct field from backend response
      setPreorders(Array.isArray(response.data.preorders) ? response.data.preorders : []);
      setError('');
    } catch (err) {
      console.error(err);
      setError('Failed to fetch preorders');
      setPreorders([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPreorders();
  }, []);

  // ✅ Correct PDF export (register plugin manually)
  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Preorder Report', 14, 20);

    doc.setFontSize(11);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 14, 28);

    const tableData = preorders.map((order) => [
      new Date(order.orderDate).toLocaleDateString(),
      `${order.registeredCustomerID?.firstName || 'N/A'} ${order.registeredCustomerID?.lastName || ''}`,
      order.address || 'N/A',
      `Rs.${order.totalAmount?.toFixed(2) || '0.00'}`,
      order.paymentMethod?.toUpperCase() || 'N/A',
      order.orderStatus?.toUpperCase() || 'PENDING',
      order.deliveryDate ? new Date(order.deliveryDate).toLocaleDateString() : 'N/A',
      order.products?.length || 0,
    ]);

    autoTable(doc, {
      startY: 35,
      head: [['Date', 'Customer', 'Address', 'Amount', 'Payment', 'Status', 'Delivery', 'Items']],
      body: tableData,
      theme: 'striped',
      headStyles: { fillColor: [52, 152, 219], textColor: 255 },
      styles: { fontSize: 9 },
      columnStyles: { 2: { cellWidth: 35 }, 3: { halign: 'right' } },
    });

    doc.save(`Preorder_Report_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  if (loading) return <div>Loading preorders...</div>;
  if (error) return <div>{error}</div>;

  const totalAmount = preorders.reduce((sum, order) => sum + (order.totalAmount ?? 0), 0);

  return (
    <div className="preorder-report-container">
      <div className="report-header">
        <h1>Preorder Report</h1>
        <button className="export-btn" onClick={exportToPDF}>📄 Export to PDF</button>
      </div>
      <div className="total-amount-report">
        <strong>Total Amount:&nbsp;</strong>Rs.{totalAmount.toFixed(2)}
      </div>
      <table className="preorder-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Customer</th>
            <th>Address</th>
            <th>Amount</th>
            <th>Payment</th>
            <th>Status</th>
            <th>Delivery</th>
            <th>Items</th>
          </tr>
        </thead>
        <tbody>
          {preorders.length === 0 ? (
            <tr>
              <td colSpan="8">No preorders found</td>
            </tr>
          ) : (
            preorders.map((order) => (
              <tr key={order._id}>
                <td>{new Date(order.orderDate).toLocaleDateString()}</td>
                <td>{`${order.registeredCustomerID?.firstName || 'N/A'} ${order.registeredCustomerID?.lastName || ''}`}</td>
                <td>{order.address || 'N/A'}</td>
                <td>Rs.{order.totalAmount?.toFixed(2) || '0.00'}</td>
                <td>{order.paymentMethod?.toUpperCase() || 'N/A'}</td>
                <td>{order.orderStatus?.toUpperCase() || 'PENDING'}</td>
                <td>{order.deliveryDate ? new Date(order.deliveryDate).toLocaleDateString() : 'N/A'}</td>
                <td>{order.products?.length || 0}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default PreorderReport;
