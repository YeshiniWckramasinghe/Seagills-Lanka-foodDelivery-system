// src/features/admin/AdminQuickActionsData.js
import React from "react";
import {
  FaTruck,
  FaCalendarAlt,
  FaChartLine,
  FaUsersCog,
  FaRoute,
  FaMapMarkedAlt,
  FaSearchLocation,
  FaClock,
  FaBoxes,
  FaBoxOpen,
} from "react-icons/fa";
import theme from "../../styles/theme";

export const quickActions = [
  {
    icon: <FaTruck />,
    title: "Assign Truck",
    description: "Assign trucks to coordinators",
    path: "/admin/assign-truck",
    color: theme.colors.primary,
  },
  {
    icon: <FaClock />,
    title: "Set Schedules",
    description: "Manage truck routes and schedules",
    path: "/admin/schedules",
    color: "#FFA726",
  },
  {
    icon: <FaUsersCog />,
    title: "Manage Users",
    description: "User management",
    path: "/admin/users",
    color: "#AB47BC",
  },
  {
    icon: <FaBoxes />,
    title: "Category Default Stock",
    description: "Set default quantities for products by category",
    path: "/admin/category-default-stock",
    color: theme.colors.secondary,
  },
  {
    icon: <FaTruck />,
    title: "Truck Management",
    description: "Add, edit, and view trucks",
    path: "/admin/trucks",
    color: "#00BCD4",
  },
  {
    icon: <FaBoxOpen />,
    title: "Manage Stock",
    description: "Stock management",
    path: "/admin/inventory",
    color: "#cf6824ff",
  },
  {
    icon: <FaRoute />,
    title: "Route Management",
    description: "Define and manage routes",
    path: "/admin/routes",
    color: "#FF5722",
  },
  {
    icon: <FaSearchLocation />,
    title: "Track Truck",
    description: "Monitor truck locations in real-time",
    path: "/admin-map",
    color: "#4DB6AC",
  },
  {
    icon: <FaCalendarAlt />,
    title: "Route Assignment",
    description: "Assign routes to trucks for schedules",
    path: "/admin/truck-routes",
    color: "#673AB7",
  },
   {
    icon: <FaChartLine />,
    title: "View Reports",
    description: "Analytics and reports",
    path: "/admin/reports",
    color: "#66BB6A",
  },
];