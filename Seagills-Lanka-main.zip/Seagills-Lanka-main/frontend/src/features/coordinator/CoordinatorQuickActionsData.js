// src/features/coordinator/CoordinatorQuickActionsData.js
import React from "react";
import {
  FaTruck,
  FaTruckLoading,
  FaDollarSign,
  FaClipboardCheck,
  FaExclamationTriangle,
  FaLock,
  FaFileAlt,
} from "react-icons/fa";
import theme from "../../styles/theme"; // Import theme

export const actionCards = [
  {
    icon: <FaClipboardCheck />,
    title: "Verify Pre-Orders",
    description: "Verify and confirm orders",
    path: "/verify-orders",
    color: "#FFA726",
  },
  {
    icon: <FaTruckLoading />,
    title: "Daily Loading",
    description: "Record products loaded for delivery",
    path: "/daily-loading",
    color: theme.colors.primary,
  },
  {
    icon: <FaTruck />,
    title: "En Route Orders",
    description: "Track orders in transit",
    path: "/en-route-orders",
    color: "#673AB7",
  },
  {
    icon: <FaDollarSign />,
    title: "Pre Orders",
    description: "Record payment information",
    path: "/update-payments",
    color: "#66BB6A",
  },
  {
    icon: <FaExclamationTriangle />,
    title: "Record Incident",
    description: "Report breakdowns, delays, or accidents",
    path: "/record-incident",
    color: "#AB47BC",
  },
  {
    icon: <FaLock />,
    title: "Close Trip",
    description: "Submit final deliveries, payments, and close the run",
    path: "/close-trip",
    color: "#FF5722",
  },
  {
    icon: <FaFileAlt />,
    title: "Trip Report",
    description: "Generate and review the final trip summary report",
    path: "/coordinator/trip-report",
    color: "#00BCD4",
  },
];
