// src/styles/theme.js
// Centralized color configuration for the entire app

const theme = {
  colors: {
    // Primary Colors
    primary: "#37BABE",
    primaryDark: "#2A9499",
    primaryLight: "#5AC9CD",

    secondary: "#48F0BD",
    secondaryDark: "#3BD4A8",
    secondaryLight: "#6FF4CC",

    // Neutral Colors
    background: "#F5F7FA",
    backgroundDark: "#E8ECF1",
    white: "#FFFFFF",

    // Text Colors
    textPrimary: "#2D3748",
    textSecondary: "#718096",
    textLight: "#A0AEC0",

    // Status Colors
    success: "#48F0BD",
    warning: "#FFA726",
    error: "#EF5350",
    info: "#37BABE",

    // Border Colors
    border: "#E2E8F0",
    borderLight: "#F0F4F8",

    // Shadow
    shadow: "rgba(0, 0, 0, 0.1)",
    shadowMedium: "rgba(0, 0, 0, 0.15)",
    shadowHeavy: "rgba(0, 0, 0, 0.25)",
  },

  // Spacing
  spacing: {
    xs: "4px",
    sm: "8px",
    md: "16px",
    lg: "24px",
    xl: "32px",
    xxl: "48px",
  },

  // Border Radius
  borderRadius: {
    sm: "4px",
    md: "8px",
    lg: "12px",
    xl: "16px",
    full: "9999px",
  },

  // Typography
  typography: {
    fontFamily:
      "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif",
    fontSize: {
      xs: "12px",
      sm: "14px",
      base: "16px",
      lg: "18px",
      xl: "20px",
      "2xl": "24px",
      "3xl": "30px",
      "4xl": "36px",
    },
    fontWeight: {
      normal: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
    },
  },

  // Transitions
  transitions: {
    fast: "150ms ease-in-out",
    normal: "250ms ease-in-out",
    slow: "350ms ease-in-out",
  },
};

export default theme;
