// src/Component/common/ErrorBanner.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";

const ErrorBanner = ({ message, onRetry }) => (
  <BannerContainer>
    <ErrorText>{message}</ErrorText>
    {onRetry && <RetryButton onClick={onRetry}>Retry</RetryButton>}
  </BannerContainer>
);

// Styled Components
const BannerContainer = styled.div`
  background: #fee;
  border: 1px solid #fcc;
  border-radius: ${theme.borderRadius.md};
  padding: ${theme.spacing.md} ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.lg};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 4px rgba(255, 0, 0, 0.1);
`;

const ErrorText = styled.span`
  color: #c33;
  font-weight: ${theme.typography.fontWeight.medium};
  flex-grow: 1;
`;

const RetryButton = styled.button`
  background: #f44336; /* Red primary */
  color: white;
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  cursor: pointer;
  font-weight: ${theme.typography.fontWeight.semibold};
  transition: all ${theme.transitions.normal};
  margin-left: ${theme.spacing.md};

  &:hover {
    background: #d32f2f;
  }
`;

export default ErrorBanner;
