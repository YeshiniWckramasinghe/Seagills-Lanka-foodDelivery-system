// src/Component/common/LoadingState.jsx
import React from "react";
import styled, { keyframes } from "styled-components";
import theme from "../../styles/theme";

const spin = keyframes`
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
`;

const LoadingContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  gap: ${theme.spacing.lg};
  background: ${theme.colors.background};
`;

const LoadingSpinner = styled.div`
  width: 50px;
  height: 50px;
  border: 4px solid ${theme.colors.border};
  border-top: 4px solid ${theme.colors.primary};
  border-radius: 50%;
  animation: ${spin} 1s linear infinite;
`;

const LoadingText = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.lg};
`;

const LoadingState = ({ text = "Loading dashboard..." }) => (
  <LoadingContainer>
    <LoadingSpinner />
    <LoadingText>{text}</LoadingText>
  </LoadingContainer>
);

export default LoadingState;
