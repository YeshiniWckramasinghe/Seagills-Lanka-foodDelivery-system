// frontend/src/Component/Modal.jsx
import React from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { FaCheckCircle, FaExclamationCircle, FaTimes } from "react-icons/fa";

const Modal = ({
  isOpen,
  onClose,
  type = "success",
  title,
  message,
  onConfirm,
}) => {
  if (!isOpen) return null;

  const isSuccess = type === "success";
  const isError = type === "error";

  return (
    <Overlay onClick={onClose}>
      <ModalContainer onClick={(e) => e.stopPropagation()}>
        <CloseButton onClick={onClose}>
          <FaTimes />
        </CloseButton>

        <IconWrapper type={type}>
          {isSuccess && <FaCheckCircle />}
          {isError && <FaExclamationCircle />}
        </IconWrapper>

        <Title>{title || (isSuccess ? "Success!" : "Error")}</Title>

        <Message>{message}</Message>

        <ButtonGroup>
          {onConfirm ? (
            <>
              <SecondaryButton onClick={onClose}>Cancel</SecondaryButton>
              <PrimaryButton onClick={onConfirm} type={type}>
                Confirm
              </PrimaryButton>
            </>
          ) : (
            <PrimaryButton onClick={onClose} type={type}>
              OK
            </PrimaryButton>
          )}
        </ButtonGroup>
      </ModalContainer>
    </Overlay>
  );
};

// Styled Components
const Overlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  backdrop-filter: blur(4px);
`;

const ModalContainer = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xxl};
  max-width: 500px;
  width: 90%;
  position: relative;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  animation: slideUp 0.3s ease-out;

  @keyframes slideUp {
    from {
      transform: translateY(50px);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }
`;

const CloseButton = styled.button`
  position: absolute;
  top: ${theme.spacing.md};
  right: ${theme.spacing.md};
  background: none;
  border: none;
  color: ${theme.colors.textSecondary};
  font-size: 20px;
  cursor: pointer;
  padding: ${theme.spacing.sm};
  transition: color ${theme.transitions.fast};

  &:hover {
    color: ${theme.colors.textPrimary};
  }
`;

const IconWrapper = styled.div`
  width: 80px;
  height: 80px;
  margin: 0 auto ${theme.spacing.lg};
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 40px;

  ${(props) =>
    props.type === "success" &&
    `
    background: #E8F5E9;
    color: #4CAF50;
  `}

  ${(props) =>
    props.type === "error" &&
    `
    background: #FFEBEE;
    color: #F44336;
  `}
`;

const Title = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  text-align: center;
  margin: 0 0 ${theme.spacing.md};
`;

const Message = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
  text-align: center;
  line-height: 1.6;
  margin: 0 0 ${theme.spacing.xl};
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: ${theme.spacing.md};
  justify-content: center;
`;

const PrimaryButton = styled.button`
  background: ${(props) =>
    props.type === "error" ? theme.colors.error : theme.colors.primary};
  color: white;
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  min-width: 120px;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const SecondaryButton = styled.button`
  background: ${theme.colors.background};
  color: ${theme.colors.textPrimary};
  border: 1px solid ${theme.colors.border};
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  min-width: 120px;

  &:hover {
    background: ${theme.colors.backgroundDark};
  }
`;

export default Modal;
