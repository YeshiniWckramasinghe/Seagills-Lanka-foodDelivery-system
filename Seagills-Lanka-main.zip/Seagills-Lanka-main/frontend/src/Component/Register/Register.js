import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './Register.css';

function Register() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [telephone, setTelephone] = useState("");
  const [role, setRole] = useState("RegisteredCustomer");
  const [branchID, setBranchID] = useState(""); // optional
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    try {
      const res = await fetch("http://localhost:5000/api/users/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          password,
          firstName,
          lastName,
          email,
          telephone,
          role,
          branchID: role === "DeliveryCoordinator" ? branchID : undefined
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.message || "Registration failed");
      } else {
        setSuccess("Registration successful! You can now login.");
        // Optionally redirect to login page
        setTimeout(() => navigate("/login"), 2000);
      }
    } catch (err) {
      console.error(err);
      setError("Something went wrong. Try again.");
    }
  };

  return (
    <div className="register-container">
      <h1>Create Your Account</h1>
      {error && <p className="register-error">{error}</p>}
      {success && <p className="register-success">{success}</p>}

      <form onSubmit={handleSubmit}>
        <div>
          <label>Username:</label>
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} required />
        </div>
        <div>
          <label>Password:</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        <div>
          <label>First Name:</label>
          <input type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)} required />
        </div>
        <div>
          <label>Last Name:</label>
          <input type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} required />
        </div>
        <div>
          <label>Email:</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div>
          <label>Contact Number:</label>
          <input type="text" value={telephone} onChange={(e) => setTelephone(e.target.value)} required />
        </div>
        <div>
          <label>Role:</label>
          <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="RegisteredCustomer">Customer</option>
            <option value="Admin">Admin</option>
            <option value="StockManager">Stock Manager</option>
            <option value="DeliveryCoordinator">Delivery Coordinator</option>
          </select>
        </div>
        {role === "DeliveryCoordinator" && (
          <div>
            <label>Branch ID:</label>
            <input type="text" value={branchID} onChange={(e) => setBranchID(e.target.value)} required />
          </div>
        )}
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default Register;
