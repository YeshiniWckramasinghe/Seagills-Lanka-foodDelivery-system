import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Profile.css";

function Profile({ userId, token }) {
  const navigate = useNavigate();
  const [preorders, setPreorders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Edit Modal State
  const [showEditModal, setShowEditModal] = useState(false);
  const [editOrder, setEditOrder] = useState(null);
  const [editDeliveryDate, setEditDeliveryDate] = useState("");
  const [editProducts, setEditProducts] = useState([]);

  // Delete Confirmation State
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteId, setDeleteId] = useState(null);

  const actualUserId = userId || JSON.parse(localStorage.getItem("user"))?.id;
  const actualToken = token || localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user"));

  // ----- DATE FORMAT HELPERS -----
  function formatDateForInput(dateString) {
    if (!dateString) return "";
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, "0");
    const day = date.getDate().toString().padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function formatDateForDisplay(dateString) {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleDateString();
  }

  // ----- FETCH PREORDERS -----
  useEffect(() => {
    async function fetchPreorders() {
      setLoading(true);
      setError("");
      if (!actualUserId || !actualToken) {
        setError("User ID or token is missing. Please log in again.");
        setLoading(false);
        return;
      }
      try {
        const res = await fetch(
          `http://localhost:5000/api/preorders/customer/${actualUserId}`,
          { headers: { Authorization: `Bearer ${actualToken}` } }
        );
        if (!res.ok) throw new Error("Could not fetch preorders.");
        const data = await res.json();
        setPreorders(data.preorders || []);
      } catch (err) {
        setError("Failed to load preorders.");
      }
      setLoading(false);
    }
    fetchPreorders();
  }, [actualUserId, actualToken]);

  // ----- DELETE HANDLERS -----
  function handleDeleteClick(orderId) {
    setDeleteId(orderId);
    setShowDeleteConfirm(true);
  }

  async function confirmDelete() {
    try {
      await fetch(`http://localhost:5000/api/preorders/${deleteId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${actualToken}` },
      });
      setPreorders(prev => prev.filter(o => o._id !== deleteId));
    } catch (err) {
      alert("Delete failed. Try again!");
    }
    setShowDeleteConfirm(false);
    setDeleteId(null);
  }

  // ----- EDIT HANDLERS -----
  function handleEditClick(order) {
    setEditOrder(order);
    setEditDeliveryDate(formatDateForInput(order.deliveryDate));
    setEditProducts(order.products.map(prod => ({
      ...prod,
      newQuantity: prod.quantity
    })));
    setShowEditModal(true);
  }

  function handleProductQuantityChange(idx, value) {
    setEditProducts(prev =>
      prev.map((p, i) =>
        i === idx ? { ...p, newQuantity: Number(value) } : p
      )
    );
  }

  function getEditTotalAmount() {
    return editProducts.reduce(
      (sum, prod) =>
        sum + (prod.productID.price || 0) * (prod.newQuantity || 0),
      0
    );
  }

  async function handleEditSave() {
    try {
      const productsBody = editProducts.map(prod => ({
        productID: prod.productID._id,
        quantity: prod.newQuantity
      }));

      const res = await fetch(`http://localhost:5000/api/preorders/${editOrder._id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${actualToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          deliveryDate: editDeliveryDate,
          products: productsBody
        })
      });

      if (!res.ok) throw new Error("Could not update preorder.");

      // Update local state
      setPreorders(prev =>
        prev.map(order =>
          order._id === editOrder._id
            ? {
                ...order,
                deliveryDate: editDeliveryDate,
                products: editProducts.map(p => ({
                  ...p,
                  quantity: p.newQuantity
                })),
                totalAmount: getEditTotalAmount()
              }
            : order
        )
      );

      setShowEditModal(false);
      setEditOrder(null);
    } catch (err) {
      alert("Failed to update the preorder.");
    }
  }

  //REORDER Handler
  function handleReorder(order) {
    // Pass all necessary fields except _id, deliveryDate, and orderStatus
    navigate("/preorder-form", {
      state: {
        products: order.products.map(prod => ({
          productID: prod.productID,      // Full object for form prefilling
          quantity: prod.quantity,
          price: prod.productID.price
        })),
        branchID: order.branchID,
        // You can also pass branch name, user data, etc. if needed for prefilling
      }
    });
  }

  // ----- RENDER -----
  return (
    <div className="profile-container">
      <div className="profile-greeting">
        {user ? `Hello, ${user.username}!` : "Hello!"}
      </div>

      <h2 className="profile-title">Your Preorders</h2>

      {loading && <p className="profile-loading">Loading...</p>}
      {error && <p className="profile-error">{error}</p>}

      {!loading && !error && (
        <>
          {preorders.length === 0 ? (
            <p className="profile-empty">You have no preorders yet.</p>
          ) : (
            <ul className="profile-preorders-list">
              {preorders.map(order => (
                <li key={order._id} className="profile-preorder-card">
                  <div className="profile-card-header">
                    <span><b>Order Date:</b> {formatDateForDisplay(order.orderDate)}</span>
                    <span><b>Delivery Date:</b> {formatDateForDisplay(order.deliveryDate)}</span>
                    <span className={`profile-status status-${order.orderStatus}`}>
                      {order.orderStatus}
                    </span>
                  </div>

                  <div className="profile-card-body">
                    <div><b>Branch:</b> {order.branchID?.branchName || "N/A"}</div>
                    <div>
                      <b>Products:</b>
                      <ul className="profile-product-list">
                        {order.products.map(prod => (
                          <li key={prod._id}>
                            {prod.productID.productName} ({prod.quantity} units)
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div><b>Total items:</b> {order.totalItems}</div>
                    <div><b>Total price:</b> Rs. {order.totalAmount}</div>
                    {order.payment && (
                      <div>
                        <b>Payment:</b> {order.payment.status || "Unknown"}
                      </div>
                    )}
                  </div>

                  <div className="profile-card-actions">
                    <button
                      onClick={() => handleEditClick(order)}
                      className="profile-edit-btn"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteClick(order._id)}
                      className="profile-delete-btn"
                    >
                      Delete
                    </button>

                    <button
                      onClick={() => handleReorder(order)}
                      className="profile-reorder-btn"
                    >
                      Reorder
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {showDeleteConfirm && (
        <div className="modal-overlay">
          <div className="modal">
            <p>Are you sure you want to delete this preorder?</p>
            <button onClick={confirmDelete}>Yes</button>
            <button onClick={() => setShowDeleteConfirm(false)}>No</button>
          </div>
        </div>
      )}

      {/* EDIT MODAL */}
      {showEditModal && editOrder && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Edit Preorder</h3>

            <label>
              Delivery Date:{" "}
              <input
                type="date"
                value={editDeliveryDate}
                onChange={e => setEditDeliveryDate(e.target.value)}
              />
            </label>

            <div>
              <h4>Products & Quantity:</h4>
              <ul>
                {editProducts.map((prod, idx) => (
                  <li key={prod._id}>
                    {prod.productID.productName} (Rs. {(prod.productID.price * prod.newQuantity).toFixed(2)})
                    <input
                      type="number"
                      min="1"
                      value={prod.newQuantity}
                      onChange={e => handleProductQuantityChange(idx, e.target.value)}
                    />
                  </li>
                ))}
              </ul>
              <div style={{ marginTop: "12px", fontWeight: 600 }}>
                Total Price: Rs. {getEditTotalAmount().toFixed(2)}
              </div>
            </div>

            <button onClick={handleEditSave}>Save Changes</button>
            <button onClick={() => setShowEditModal(false)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Profile;
