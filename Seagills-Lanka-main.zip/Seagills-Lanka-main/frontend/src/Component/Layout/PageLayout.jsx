// src/Component/Layout/PageLayout.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";
import { FaTruck, FaArrowLeft } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

const PageLayout = ({
  children,
  pageTitle,
  pageSubtitle,
  backPath = "/coordinator-dashboard", // Default back path
  userRole = "Coordinator",
}) => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  const handleBack = () => navigate(backPath);

  return (
    <PageContainer>
      <Header>
        <LogoSection onClick={() => navigate("/coordinator-dashboard")}>
          <Logo>
            <FaTruck />
          </Logo>
          <BrandInfo>
            <BrandName>Seagills Lanka</BrandName>
            <BrandTagline>Delivery Management</BrandTagline>
          </BrandInfo>
        </LogoSection>

        <UserSection>
          <UserInfo>
            <UserName>{user.username}</UserName>
            <UserRole>{userRole}</UserRole>
          </UserInfo>
          <SignOutButton onClick={handleBack}>
            <FaArrowLeft /> Back
          </SignOutButton>
        </UserSection>
      </Header>

      <MainContent>
        <PageHeader>
          <PageTitle>{pageTitle}</PageTitle>
          <PageSubtitle>{pageSubtitle}</PageSubtitle>
        </PageHeader>
        {children}
      </MainContent>
    </PageContainer>
  );
};

// Styled Components (Moved from DailyLoading.jsx)

const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
`;

const Header = styled.header`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const SignOutButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const MainContent = styled.main`
  max-width: 1200px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const PageHeader = styled.div`
  margin-bottom: ${theme.spacing.xl};
`;

const PageTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0 0 ${theme.spacing.xs};
`;

const PageSubtitle = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
  margin: 0;
`;

export default PageLayout;
