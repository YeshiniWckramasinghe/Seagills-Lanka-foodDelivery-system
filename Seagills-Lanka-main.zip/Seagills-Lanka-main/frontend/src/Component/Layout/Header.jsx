// src/Component/Layout/Header.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";
import { FaTruck } from "react-icons/fa";

const Header = ({ onSignOut }) => {
  const user = JSON.parse(localStorage.getItem("user") || "{}");
  const userName = user.username || "Admin";
  const userRole = user.role || "User";

  return (
    <StyledHeader>
      <LogoSection>
        <Logo>
          <FaTruck />
        </Logo>
        <BrandInfo>
          <BrandName>Seagills Lanka</BrandName>
          <BrandTagline>Delivery Management</BrandTagline>
        </BrandInfo>
      </LogoSection>

      <UserSection>
        <UserInfo>
          <UserName>{userName}</UserName>
          <UserRole>{userRole}</UserRole>
        </UserInfo>
        <SignOutButton onClick={onSignOut}>Sign Out</SignOutButton>
      </UserSection>
    </StyledHeader>
  );
};

// Styled Components
const StyledHeader = styled.header`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const SignOutButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

export default Header;
