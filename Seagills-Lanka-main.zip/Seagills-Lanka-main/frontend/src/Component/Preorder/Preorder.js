import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useCart } from './CartContext';
import './Preorder.css';

function Preorder() {
  const location = useLocation();
  const navigate = useNavigate();
  const { clearCart } = useCart();

  // Get the order data from location state (passed from PreorderForm)
  const { 
    totalAmount, 
    orderDate, 
    address, 
    deliveryDate, 
    paymentOption 
  } = location.state || {};

  // Clear the cart after successful order
  React.useEffect(() => {
  clearCart();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  return (
    <div className="preorder-confirmed-container">
      <div className="success-icon">✓</div>
      <h2>Preorder Confirmed!</h2>
      <p>Thank you for your order. We will contact you soon with updates.</p>
      
      <div className="order-details">
        <h3>Order Summary</h3>
        <div className="detail-item">
          <span className="label">Order Date:</span>
          <span className="value">{orderDate || 'N/A'}</span>
        </div>
        <div className="detail-item">
          <span className="label">Total Amount:</span>
          <span className="value">Rs.{totalAmount || 'N/A'}</span>
        </div>
        <div className="detail-item">
          <span className="label">Delivery Address:</span>
          <span className="value">{address || 'N/A'}</span>
        </div>
        <div className="detail-item">
          <span className="label">Expected Delivery:</span>
          <span className="value">{deliveryDate || 'N/A'}</span>
        </div>
        <div className="detail-item">
          <span className="label">Payment Method:</span>
          <span className="value">
            {paymentOption ? paymentOption.charAt(0).toUpperCase() + paymentOption.slice(1) : 'N/A'}
          </span>
        </div>
      </div>

      <div className="action-buttons">
        <button className="home-btn" onClick={() => navigate('/home')}>
          Back to Home
        </button>
        <button className="continue-shopping-btn" onClick={() => navigate('/products')}>
          Continue Shopping
        </button>
      </div>
    </div>
  );
}

export default Preorder;
