import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useCart } from './CartContext'; 
import './PreorderForm.css';

function PreorderForm() {
  const location = useLocation();
  const navigate = useNavigate();

  // Check if this is a reorder (from Profile) or a normal cart order
  const { products: reorderProducts, branchID, orderDate } = location.state || {};
  const isReorder = !!reorderProducts;

  const [address, setAddress] = useState('');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [paymentOption, setPaymentOption] = useState('cash');
  const [error, setError] = useState('');
  const [minDate, setMinDate] = useState('');

  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const token = localStorage.getItem('token');
  const { cartItems, clearCart } = useCart();

  // Products: use reorder if present, else use cart
  const [formProducts, setFormProducts] = useState(() =>
    isReorder
      ? reorderProducts.map(item => ({
          productID: item.productID._id || item.productID,
          productName: item.productID.productName || item.productID?.productName || '', // display name
          price: item.price ?? item.productID.price ?? 0,
          quantity: item.quantity
        }))
      : cartItems.map(item => ({
          productID: item.id,
          productName: item.name,
          price: item.price,
          quantity: item.quantity
        }))
  );

  // Set min delivery date (tomorrow)
  useEffect(() => {
    const today = new Date();
    today.setDate(today.getDate() + 1); // tomorrow
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    setMinDate(`${yyyy}-${mm}-${dd}`);
  }, []);

  // Live update product quantity
  function handleQuantityChange(idx, val) {
    setFormProducts(prev => prev.map((p, i) =>
      i === idx ? { ...p, quantity: Math.max(1, Number(val)) } : p
    ));
  }

  // Calculate total price
  const calcTotal = formProducts.reduce(
    (sum, item) => sum + (item.price * item.quantity),
    0
  );

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!address || !deliveryDate || !paymentOption) {
      setError('Please fill out all fields.');
      return;
    }

    const selectedDate = new Date(deliveryDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    if (selectedDate < tomorrow) {
      setError("You can't choose today or a past date. Please select a date at least 1 day in advance.");
      return;
    }

    if (!formProducts.length) {
      setError('No products selected.');
      return;
    }

    if (!user.id) {
      setError('User not found, please log in.');
      return;
    }

    const preorderData = {
      registeredCustomerID: user.id,
      address,
      products: formProducts.map(p => ({
        productID: p.productID,
        quantity: p.quantity
      })),
      branchID: branchID?._id || branchID, // from reorder or undefined
      orderDate: orderDate || new Date(),
      deliveryDate,
      paymentOption
    };

    try {
      const response = await fetch('http://localhost:5000/api/preorders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(preorderData)
      });

      if (!response.ok) {
        const result = await response.json();
        setError(result.message || 'Failed to place preorder.');
        return;
      }

      if (!isReorder) clearCart();

      navigate('/preorder', {
        state: {
          totalAmount: calcTotal,
          orderDate,
          address,
          deliveryDate,
          paymentOption
        }
      });

    } catch (err) {
      setError('Network error.');
    }
  };

  return (
    <div className="preorder-form-container">
      <h2>Confirm Your Preorder</h2>
      <div className="preorder-summary">
        <div>
          <strong>Total Amount:</strong> Rs.{calcTotal || 'N/A'}
        </div>
        <div>
          <strong>Order Date:</strong> {orderDate || new Date().toLocaleDateString()}
        </div>
        <div>
          <strong>Products:</strong>
          <ul className="preorder-products-list">
            {formProducts.map((item, idx) => (
              <ul key={item.productID}>
                {item.productName} &nbsp;
                <input
                  type="number"
                  value={item.quantity}
                  min={1}
                  style={{ width: "50px" }}
                  onChange={e => handleQuantityChange(idx, e.target.value)}
                />
              </ul>
            ))}
          </ul>
        </div>
      </div>
      <form onSubmit={handleSubmit} className="preorder-form">
        <div className="form-group">
          <label>Delivery Address</label>
          <input 
            type="text" 
            value={address} 
            onChange={e => setAddress(e.target.value)} 
            required 
          />
        </div>
        <div className="form-group">
          <label>Expected Delivery Date</label>
          <input 
            type="date" 
            value={deliveryDate} 
            onChange={e => setDeliveryDate(e.target.value)} 
            required 
            min={minDate}
          />
        </div>
        <div className="form-group">
          <label>Payment Option</label>
          <div className="payment-options">
            <label>
              <input 
                type="radio" 
                value="card"
                checked={paymentOption === "card"}
                onChange={e => setPaymentOption(e.target.value)}
              /> Card
            </label>
            <label>
              <input 
                type="radio" 
                value="cash"
                checked={paymentOption === "cash"}
                onChange={e => setPaymentOption(e.target.value)}
              /> Cash
            </label>
          </div>
        </div>
        {error && <div className="form-error">{error}</div>}
        <button type="submit" className="confirm-btn">Confirm Preorder</button>
      </form>
    </div>
  );
}

export default PreorderForm;
