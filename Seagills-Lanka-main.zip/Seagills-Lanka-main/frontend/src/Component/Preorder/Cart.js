import React from 'react';
import { useCart } from './CartContext';
import './Cart.css';
import { useNavigate } from "react-router-dom";


function Cart() {
  const { cartItems, updateQuantity, removeFromCart, getCartTotal, clearCart } = useCart();
  const navigate = useNavigate();

  if (cartItems.length === 0) {
    return (
      <div className="cart-page-container">
        <div className="cart-container">
          <h2>Your Cart</h2>
          <p>Your cart is empty</p>
        </div>
      </div>
    );
  }

  return (
    <div className="cart-container">
  <h2>Your Cart</h2>
  {cartItems.map((item) => (
    <div key={item.id} className="cart-item">
      <img src={item.image} alt={item.name} className="cart-item-image" />
      <div className="cart-item-details">
        <h3>{item.name}</h3>
        <p>Price: {item.price}</p>
        <div className="cart-item-controls">
          <button onClick={() => updateQuantity(item.id, item.quantity - 1)}>-</button>
          <span>{item.quantity}</span>
          <button onClick={() => updateQuantity(item.id, item.quantity + 1)}>+</button>
        </div>
      </div>
      <button onClick={() => removeFromCart(item.id)} className="remove-btn" aria-label="Remove">
        <img 
          src="https://cdn4.iconfinder.com/data/icons/social-messaging-ui-coloricon-1/21/52-512.png"
          alt="Remove" 
          className="remove-icon"
        />
      </button>
    </div>
  ))}
  <div className="cart-summary">
    <div className="cart-summary-row total">
      <span>Total:</span>
      <span>Rs.{getCartTotal().toFixed(2)}</span>
    </div>
    <div className="cart-action-btns">
      <button onClick={clearCart} className="clear-cart-btn">
        Clear Cart
      </button>
      <button
        className="checkout-btn"
        onClick={() =>
          navigate('/preorder-form', {
            state: {
              totalAmount: getCartTotal(),
              orderDate: new Date().toLocaleDateString()
            }
          })
        }
      >
        Make a Preorder
      </button>
    </div>
  </div>
</div>

  );
}

export default Cart;
