import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "./NavBar.css";
import logo from "./Seagills Lanka Logo.png"; 
import cartImg from "./cart.png";
import { useCart } from "../Preorder/CartContext";

function NavBar() {
  const { getCartUniqueItemsCount } = useCart();
  const navigate = useNavigate();
  const cartCount = getCartUniqueItemsCount();

  // ✅ Handles Enroute Order button click
  const handleEnrouteOrder = () => {
    navigate("/customer/request");
  };

  return (
    <nav className="navbar">
      {/* Left: Logo */}
      <div className="navbar-left">
        <img src={logo} alt="Logo" className="navbar-logo" />
      </div>

      {/* Center: Navigation Links */}
      <div className="navbar-center">
        <Link to="/" className="navbar-link">Home</Link>
        <Link to="/products" className="navbar-link">Products</Link>
        <Link to="/about" className="navbar-link">About Us</Link>
        <Link to="/profile" className="navbar-link">Profile</Link>

        {/* ✅ Fixed Track Truck Live link */}
        <a
          href="http://localhost:5000"
          target="_blank"
          rel="noopener noreferrer"
          className="navbar-link"
        >
          Track Truck Live
        </a>
      </div>

      {/* Right: Cart & Auth */}
      <div className="navbar-right">
        <Link to="/cart" className="navbar-cart-link">
          <span className="navbar-cart-icon">
            <img src={cartImg} alt="Cart" className="navbar-cart-image" />
            <span className="navbar-cart-count">{cartCount}</span>
          </span>
        </Link>

        {/* ✅ Enroute Order Button */}
        <button 
          onClick={handleEnrouteOrder}
          className="navbar-btn navbar-enroute-btn"
        >
          Enroute Order
        </button>

        <Link to="/login" className="navbar-btn">Login</Link>
        <Link to="/register" className="navbar-btn">Register</Link>
      </div>
    </nav>
  );
}

export default NavBar;
