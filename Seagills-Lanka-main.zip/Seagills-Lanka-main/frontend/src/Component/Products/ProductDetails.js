import React, { useState, useEffect } from 'react';
import { useParams } from "react-router-dom";
import "./ProductDetails.css";
import { useCart } from '../Preorder/CartContext';

function ProductDetails() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();

  useEffect(() => {
    fetch(`http://localhost:5000/api/products/${id}`)
      .then((res) => res.json())
      .then((data) => setProduct(data));
  }, [id]);

  const handleAddToCart = () => {
    if (product) {
      const cartProduct = {
        id: product._id,
        name: product.productName,
        price: product.displayPrice,
        image: product.productImage,
        category: product.category
      };
      addToCart(cartProduct, quantity);
      alert(`Added ${quantity} ${product.productName}(s) to cart!`);
    }
  };

  if (!product) return <div>Loading...</div>;

  return (
    <div className="product-details-page-container">
      {/* No NavBar or Footer here! */}
      <div className="product-details-container">
        <div className="product-details-image">
          <img src={product.productImage} alt={product.productName} />
        </div>
        <div className="product-details-info">
          <div className="product-details-title">{product.productName}</div>
          <div className="product-details-price">{product.displayPrice}</div>
          <div className="product-details-actions">
            <div className="qty-selector">
              <button className="qty-btn" onClick={() => setQuantity(q => Math.max(1, q-1))}>-</button>
              <span className="qty-value">{quantity}</span>
              <button className="qty-btn" onClick={() => setQuantity(q => q+1)}>+</button>
            </div>
            <button className="action-btn" onClick={handleAddToCart}>
              Add to cart
            </button>
          </div>
          <div className="product-details-category">
            <label>Categories:</label> {product.category}
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetails;
