import React, { useEffect, useState } from "react";
import ProductCard from "./productCard";
import "./Products.css";
import CategoryBar from "./CategoryBar";
import { useLocation, useNavigate } from "react-router-dom";

function Products() {
  const [products, setProducts] = useState([]);
  const location = useLocation();
  const navigate = useNavigate();

  // Read the category from the URL query string
  const params = new URLSearchParams(location.search);
  const selectedCategory = params.get("category");

  useEffect(() => {
    fetch("http://localhost:5000/api/products")
      .then((res) => res.json())
      .then((data) => setProducts(data))
      .catch((err) => console.error("Fetch products error:", err));
  }, []);

  // Filter products based on URL query
  const shownProducts = selectedCategory
    ? products.filter(
        (p) =>
          p.category && p.category.toLowerCase() === selectedCategory.toLowerCase()
      )
    : products;

  // Handle category selection from CategoryBar
  const handleCategorySelect = (category) => {
    // Update the URL query string
    navigate(`/products?category=${category}`);
  };

  return (
    <div className="products-page-container">
      {/* Categories Section */}
      <h2 style={{ textAlign: "center", marginBottom: "16px" }}>Categories</h2>
      <CategoryBar onSelect={handleCategorySelect} />
      <br />

      {/* Products Section */}
      <h2>Products</h2>
      <div className="products-container">
        <div className="products-row">
          {shownProducts.map((product) => (
            <ProductCard
              key={product._id}
              id={product._id}
              name={product.productName}
              price={product.displayPrice}
              imgSrc={product.productImage}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default Products;
