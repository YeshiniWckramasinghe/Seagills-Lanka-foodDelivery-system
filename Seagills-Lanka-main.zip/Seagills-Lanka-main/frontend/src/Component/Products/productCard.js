import React from "react";
import { useNavigate } from "react-router-dom";
import "./productCard.css";

export default function ProductCard({ id, imgSrc, name, price }) {
  const navigate = useNavigate();

  return (
    <div className="product-card" onClick={() => navigate(`/products/${id}`)}>
      <img src={imgSrc} alt={name} className="product-img"/>
      <div className="product-info">
        <div className="product-name">{name}</div>
        <div className="product-price">{price}</div>
      </div>
    </div>
  );
}
