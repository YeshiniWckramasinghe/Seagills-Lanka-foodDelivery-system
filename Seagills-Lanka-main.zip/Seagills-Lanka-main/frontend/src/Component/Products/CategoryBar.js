import React from "react";
import "./CategoryBar.css";
import { useNavigate } from "react-router-dom";  // <-- Add this

const categories = [
  { name: "Meat", icon: "https://img.freepik.com/premium-photo/raw-meat-isolated-white-background_947206-3922.jpg" },
  { name: "Fish", icon: "https://static.vecteezy.com/system/resources/thumbnails/036/744/123/small_2x/ai-generated-raw-fish-isolated-on-transparent-background-free-png.png" },
  { name: "Veg & Spices", icon: "https://img.freepik.com/premium-photo/collection-vegetables-isolated-white-background_44074-1573.jpg?w=2000" },
  { name: "Fruits", icon: "https://thumbs.dreamstime.com/b/different-fruits-24060140.jpg" },
];

export default function CategoryBar() {
  const navigate = useNavigate(); // Use this for navigation

  return (
    <div className="category-bar">
      {categories.map((cat) => (
        <div
          key={cat.name}
          className="category-item"
          onClick={() => navigate(`/products?category=${encodeURIComponent(cat.name)}`)} // On click, go to Products page and pass selected category in query string
        >
          <div className="category-circle">
            <img src={cat.icon} alt={cat.name} />
          </div>
          <div className="category-name">{cat.name}</div>
        </div>
      ))}
    </div>
  );
}
