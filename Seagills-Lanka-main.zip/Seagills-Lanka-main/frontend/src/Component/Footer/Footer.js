import { Link } from "react-router-dom";
import "./Footer.css";

const Footer = () => {
  return (
    <footer className="footer-container">
      <div className="footer-content">
        {/* Logo / Brand */}
        <div className="footer-brand">
          <h2>Seagills Lanka</h2>
          <p>Fresh groceries delivered to your doorstep</p>
        </div>

        {/* Links */}
        <div className="footer-links">
          <div className="footer-section">
            <h3>Company</h3>
            <a href="/about">About Us</a>
            <a href="/about">Contact</a>
            <a href="/about">Privacy Policy</a>
          </div>

          <div className="footer-section">
            <h3>Categories</h3>
            <a href="/products?category=Meat">Meat</a>
            <a href="/products?category=Fish">Fish</a>
            <a href="/products?category=Veg%20%26%20Spices">Vegetables & Spices</a>
            <a href="/products?category=Fruits">Fruits</a>
          </div>

        </div>

        {/* Contact Info */}
        <div className="footer-contact">
          <h3>Contact</h3>
          <p>Email: <a href="mailto:info@seagillslanka.com">info@seagillslanka.com</a></p>
          <p>Phone: +94 11 234 5678</p>
          <p>Address: No. 25, Galle Road, Colombo, Sri Lanka</p>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Seagills Lanka. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
