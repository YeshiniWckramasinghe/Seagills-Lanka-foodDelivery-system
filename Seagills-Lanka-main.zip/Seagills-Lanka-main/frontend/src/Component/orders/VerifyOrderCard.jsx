// frontend/src/Component/orders/VerifyOrderCard.jsx
import React from "react";
import styled from "styled-components";
import { FaCheckCircle, FaUser, FaMapMarkerAlt, FaPhone } from "react-icons/fa";
import theme from "../../styles/theme";

const VerifyOrderCard = ({
  preorder,
  isVerified,
  onToggleVerify,
  hideCheckbox,
}) => {
  return (
    <OrderCard>
      <OrderHeader>
        <OrderId>Order #{preorder._id.slice(-6).toUpperCase()}</OrderId>
        <HeaderRight>
          <StatusBadge status={preorder.orderStatus}>
            {preorder.orderStatus}
          </StatusBadge>
          {!hideCheckbox && (
            <CheckboxWrapper>
              <Checkbox
                type="checkbox"
                checked={isVerified}
                onChange={onToggleVerify}
                id={`verify-${preorder._id}`}
              />
              <CheckboxLabel htmlFor={`verify-${preorder._id}`}>
                {isVerified ? (
                  <FaCheckCircle style={{ color: theme.colors.success }} />
                ) : null}
                Verify Order
              </CheckboxLabel>
            </CheckboxWrapper>
          )}
        </HeaderRight>
      </OrderHeader>

      <CustomerInfo>
        <InfoRow>
          <InfoIcon>
            <FaUser />
          </InfoIcon>
          <InfoText>
            {preorder.registeredCustomerID?.firstName}{" "}
            {preorder.registeredCustomerID?.lastName}
          </InfoText>
        </InfoRow>
        <InfoRow>
          <InfoIcon>
            <FaPhone />
          </InfoIcon>
          <InfoText>
            {preorder.registeredCustomerID?.telephone || "N/A"}
          </InfoText>
        </InfoRow>
        <InfoRow>
          <InfoIcon>
            <FaMapMarkerAlt />
          </InfoIcon>
          <InfoText>{preorder.address || "N/A"}</InfoText>
        </InfoRow>
      </CustomerInfo>

      <ProductsList>
        <ProductsTitle>
          Products ({preorder.products?.length || 0})
        </ProductsTitle>
        {preorder.products?.map((product, idx) => (
          <ProductItem key={idx}>
            <ProductName>{product.productID?.productName}</ProductName>
            <ProductQuantity>
              Qty: {product.quantity} {product.productID?.unit}
            </ProductQuantity>
          </ProductItem>
        ))}
      </ProductsList>

      <OrderTotal>
        Total: LKR {preorder.totalAmount?.toFixed(2) || "0.00"}
      </OrderTotal>
    </OrderCard>
  );
};

export default VerifyOrderCard;

// Styled Components
const OrderCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.lg};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px ${theme.colors.shadowMedium};
  }
`;

const OrderHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.md};
  padding-bottom: ${theme.spacing.md};
  border-bottom: 1px solid ${theme.colors.border};
`;

const HeaderRight = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
`;

const OrderId = styled.h4`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0;
`;

const StatusBadge = styled.span`
  padding: ${theme.spacing.xs} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.full};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
  text-transform: capitalize;
  background: ${(props) => {
    switch (props.status) {
      case "verified":
      case "loaded":
        return "#E8F5E9";
      case "pending":
        return "#FFF3E0";
      case "assigned":
        return "#E3F2FD";
      default:
        return "#F5F5F5";
    }
  }};
  color: ${(props) => {
    switch (props.status) {
      case "verified":
      case "loaded":
        return "#4CAF50";
      case "pending":
        return "#FF9800";
      case "assigned":
        return "#2196F3";
      default:
        return "#757575";
    }
  }};
`;

const CustomerInfo = styled.div`
  margin-bottom: ${theme.spacing.md};
`;

const InfoRow = styled.div`
  display: flex;
  align-items: flex-start;
  gap: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.sm};
`;

const InfoIcon = styled.div`
  color: ${theme.colors.primary};
  font-size: 16px;
  margin-top: 2px;
  flex-shrink: 0;
`;

const InfoText = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  line-height: 1.5;
`;

const ProductsList = styled.div`
  margin-bottom: ${theme.spacing.md};
`;

const ProductsTitle = styled.h5`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.sm};
`;

const ProductItem = styled.div`
  display: flex;
  justify-content: space-between;
  padding: ${theme.spacing.sm};
  background: ${theme.colors.background};
  border-radius: ${theme.borderRadius.md};
  margin-bottom: ${theme.spacing.xs};
`;

const ProductName = styled.span`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
`;

const ProductQuantity = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const OrderTotal = styled.div`
  color: ${theme.colors.primary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.bold};
  margin-bottom: ${theme.spacing.md};
  padding-top: ${theme.spacing.md};
  border-top: 1px solid ${theme.colors.border};
  text-align: right;
`;

const CheckboxWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
`;

const Checkbox = styled.input`
  width: 20px;
  height: 20px;
  cursor: pointer;
  accent-color: ${theme.colors.primary};
`;

const CheckboxLabel = styled.label`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.base};
  font-weight: ${theme.typography.fontWeight.medium};
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: ${theme.spacing.xs};
`;
