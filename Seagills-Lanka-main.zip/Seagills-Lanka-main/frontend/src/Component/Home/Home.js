import React from 'react';
import "./Home.css";
import {useNavigate } from "react-router-dom";
import Products from '../Products/Products'; 

function Home() {
  const navigate = useNavigate();

  return (
    <div>
      {/* Post Banner */}
      <div className="home-post-banner"></div>
      <br></br><br></br>
      
      <Products/>

    </div>
  );
}

export default Home;
