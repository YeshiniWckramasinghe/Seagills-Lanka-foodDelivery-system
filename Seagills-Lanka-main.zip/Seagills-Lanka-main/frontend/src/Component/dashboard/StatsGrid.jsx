// src/Component/dashboard/StatsGrid.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";
import StatCard from "./StatCard";
import {
  FaBox,
  FaTruckLoading,
  FaTruck,
  FaUsers,
  FaUserTie,
} from "react-icons/fa";

const StatsGrid = ({ data }) => {
  const statCardsData = [
    {
      icon: <FaBox />,
      label: "Pre-Orders",
      value: data.preOrders,
      change: `${data.ordersChange} vs last month`,
      changePositive: data.ordersChange?.includes("+"),
      iconColor: "#5C9FFF",
    },
    {
      icon: <FaTruckLoading />,
      label: "Enroute Orders",
      value: data.enrouteOrders,
      change: `${data.ordersChange} vs last month`,
      changePositive: data.ordersChange?.includes("+"),
      iconColor: "#5C9FFF",
    },
    {
      icon: <FaTruck />,
      label: "Total Trucks",
      value: data.totalTrucks,
      change: `${data.trucksChange} no change`,
      changePositive: data.trucksChange?.includes("+"),
      iconColor: "#A0AEC0",
    },
    {
      icon: <FaUsers />,
      label: "Coordinators",
      value: data.coordinators,
      change: `${data.coordinatorsChange} new this month`,
      changePositive: data.coordinatorsChange?.includes("+"),
      iconColor: theme.colors.secondary,
    },
    {
      icon: <FaUserTie />,
      label: "Drivers",
      value: data.drivers,
      change: `${data.revenueChange} vs last month`,
      changePositive: data.revenueChange?.includes("+"),
      iconColor: "#FFB74D",
    },
  ];

  return (
    <GridContainer>
      {statCardsData.map((stat, index) => (
        <StatCard
          key={index}
          icon={stat.icon}
          label={stat.label}
          value={stat.value}
          change={stat.change}
          changePositive={stat.changePositive}
          iconColor={stat.iconColor}
        />
      ))}
    </GridContainer>
  );
};

// Styled Components
const GridContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.xl};
`;

export default StatsGrid;
