// src/Component/dashboard/ActionsSection.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";
import ActionCard from "./ActionCard";

const ActionsSection = ({ actions, navigate }) => {
  return (
    <SectionContainer>
      <SectionTitle>Quick Actions</SectionTitle>
      <ActionsGrid>
        {actions.map((action, index) => (
          <ActionCard
            key={index}
            icon={action.icon}
            title={action.title}
            onClick={() => navigate(action.path)}
            color={action.color}
          />
        ))}
      </ActionsGrid>
    </SectionContainer>
  );
};

// Styled Components
const SectionContainer = styled.div`
  margin-top: ${theme.spacing.xxl};
`;

const SectionTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
`;

const ActionsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: ${theme.spacing.lg};
`;

export default ActionsSection;
