// src/Component/dashboard/ActionCard.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";

const ActionCard = ({ icon, title, onClick, color, gradient }) => {
  return (
    <CardContainer onClick={onClick}>
      <ActionIcon $color={color} $gradient={gradient}>
        {icon}
      </ActionIcon>
      <ActionTitle>{title}</ActionTitle>
    </CardContainer>
  );
};

// Styled Components
const CardContainer = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  text-align: center;
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  box-shadow: 0 2px 8px ${theme.colors.shadow};

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px ${theme.colors.shadowMedium};
  }
`;

const ActionIcon = styled.div`
  width: 64px;
  height: 64px;
  background: ${(props) =>
    props.$gradient
      ? props.$gradient
      : props.$color
      ? `linear-gradient(135deg, ${props.$color} 0%, ${props.$color}cc 100%)`
      : theme.colors.primary};
  color: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  margin: 0 auto ${theme.spacing.md};
`;

const ActionTitle = styled.h4`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0;
`;

export default ActionCard;
