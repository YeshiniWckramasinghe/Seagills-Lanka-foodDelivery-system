// src/Component/dashboard/StatCard.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";

const StatCard = ({
  icon,
  label,
  value,
  change,
  changePositive,
  iconColor,
}) => {
  return (
    <CardContainer>
      <StatIcon color={iconColor}>{icon}</StatIcon>
      <StatContent>
        <StatLabel>{label}</StatLabel>
        <StatValue>{value}</StatValue>
        <StatChange positive={changePositive}>{change}</StatChange>
      </StatContent>
    </CardContainer>
  );
};

// Styled Components
const CardContainer = styled.div`
  background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
  border: 1px solid rgba(0, 0, 0, 0.05)
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  display: flex;
  gap: ${theme.spacing.lg};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px ${theme.colors.shadowMedium};
  }
`;

const StatIcon = styled.div`
  width: 64px;
  height: 64px;
  background: ${(props) => props.color};
  color: white;
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  flex-shrink: 0;
`;

const StatContent = styled.div`
  flex: 1;
`;

const StatLabel = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  margin-bottom: ${theme.spacing.xs};
`;

const StatValue = styled.div`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin-bottom: ${theme.spacing.xs};
`;

const StatChange = styled.div`
  color: ${(props) =>
    props.positive ? "#4CAF50" : theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.xs};
  font-weight: ${theme.typography.fontWeight.medium};
`;

export default StatCard;
