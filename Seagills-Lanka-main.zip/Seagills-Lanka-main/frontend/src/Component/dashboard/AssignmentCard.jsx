// src/Component/dashboard/AssignmentCard.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";
import {
  FaTruck,
  FaMapMarkerAlt,
  FaUser,
  FaRoute,
  FaClock,
} from "react-icons/fa";

const AssignmentCard = ({ assignment, scheduledStartTime }) => {
  return (
    <CardContainer>
      <CardTitle>
        <FaTruck /> Today's Assignment
      </CardTitle>
      <AssignmentDetails>
        <AssignmentItem>
          <ItemIcon $primary>
            <FaTruck />
          </ItemIcon>
          <ItemInfo>
            <ItemLabel>Truck</ItemLabel>
            <ItemValue>{assignment.truck}</ItemValue>
          </ItemInfo>
        </AssignmentItem>

        <AssignmentItem>
          <ItemIcon>
            <FaMapMarkerAlt />
          </ItemIcon>
          <ItemInfo>
            <ItemLabel>Route</ItemLabel>
            <ItemValue>{assignment.route}</ItemValue>
          </ItemInfo>
        </AssignmentItem>

        <AssignmentItem>
          <ItemIcon $secondary>
            <FaUser />
          </ItemIcon>
          <ItemInfo>
            <ItemLabel>Driver</ItemLabel>
            <ItemValue>{assignment.driver}</ItemValue>
          </ItemInfo>
        </AssignmentItem>

        <AssignmentItem>
          <ItemIcon $clock>
            <FaClock />
          </ItemIcon>
          <ItemInfo>
            <ItemLabel>Scheduled Start</ItemLabel>
            <ItemValue>
              {scheduledStartTime || assignment.scheduledStartTime || "Not Set"}
            </ItemValue>
          </ItemInfo>
        </AssignmentItem>
      </AssignmentDetails>
    </CardContainer>
  );
};

// Styled Components
const CardContainer = styled.div`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  margin-bottom: ${theme.spacing.xl};
  box-shadow: 0 4px 16px ${theme.colors.shadow};
`;

const CardTitle = styled.h3`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
`;

const AssignmentDetails = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${theme.spacing.lg};
`;

const AssignmentItem = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
`;

const ItemIcon = styled.div`
  width: 48px;
  height: 48px;
  background: ${(props) =>
    props.$primary
      ? theme.colors.white
      : props.$secondary
      ? theme.colors.secondary
      : props.$clock
      ? "rgba(255, 193, 7, 0.9)"
      : "rgba(255, 255, 255, 0.2)"};
  color: ${(props) =>
    props.$primary
      ? theme.colors.primary
      : props.$secondary || props.$clock
      ? theme.colors.primary
      : theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
`;

const ItemInfo = styled.div``;

const ItemLabel = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
  margin-bottom: ${theme.spacing.xs};
`;

const ItemValue = styled.div`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
`;

export default AssignmentCard;
