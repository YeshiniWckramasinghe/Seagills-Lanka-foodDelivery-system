import React from "react";
import styled from "styled-components";

const theme = {
  colors: {
    white: "#ffffff",
    textPrimary: "#1a1a1a",
    textSecondary: "#666666",
    primary: "#14b8a6",
    border: "#e5e7eb",
    shadow: "rgba(0, 0, 0, 0.1)",
  },
  spacing: {
    sm: "0.5rem",
    lg: "1rem",
    xl: "1.5rem",
  },
  borderRadius: {
    xl: "12px",
  },
  typography: {
    fontSize: {
      base: "1rem",
      "2xl": "1.5rem",
      "4xl": "2.25rem",
    },
    fontWeight: {
      semibold: "600",
      bold: "700",
    },
  },
};

const SummaryCard = ({ summary }) => {
  return (
    <CardContainer>
      <SectionTitle>Today's Summary</SectionTitle>
      <SummaryGrid>
        <SummaryItem>
          <SummaryValue>
            {summary.preorder?.completed || 0}/{summary.preorder?.total || 0}
          </SummaryValue>
          <SummaryLabel>Preorders Completed</SummaryLabel>
        </SummaryItem>
        <SummaryDivider />
        <SummaryItem>
          <SummaryValue>{summary.enroute?.completed || 0}</SummaryValue>
          <SummaryLabel>En-route Orders Completed</SummaryLabel>
        </SummaryItem>
      </SummaryGrid>
    </CardContainer>
  );
};

// Styled Components
const CardContainer = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const SectionTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
`;

const SummaryGrid = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-around;
  gap: ${theme.spacing.xl};

  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const SummaryItem = styled.div`
  text-align: center;
  flex: 1;
`;

const SummaryValue = styled.div`
  color: ${theme.colors.primary};
  font-size: ${theme.typography.fontSize["4xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin-bottom: ${theme.spacing.sm};
`;

const SummaryLabel = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
`;

const SummaryDivider = styled.div`
  width: 2px;
  height: 60px;
  background: ${theme.colors.border};

  @media (max-width: 768px) {
    width: 100%;
    height: 2px;
  }
`;

export default SummaryCard;
