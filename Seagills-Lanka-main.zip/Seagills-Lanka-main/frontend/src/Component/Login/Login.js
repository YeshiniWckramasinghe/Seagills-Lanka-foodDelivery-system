import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "./Login.css";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const res = await fetch("http://localhost:5000/api/users/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();
      if (!res.ok) {
    setError(data.message || "Incorrect Username or Password");
}else {
        localStorage.setItem("token", data.token);
        localStorage.setItem("user", JSON.stringify(data.user));

        // Role-based redirection
        // Role-based redirection
const userRole = data.user.role;

if (userRole === "DeliveryCoordinator") {
  navigate("/coordinator-dashboard");
} else if (userRole === "Admin") {
  navigate("/admin-dashboard");
} else if (userRole === "StockManager") {
  navigate("/stock-dashboard");
} else if (userRole === "RegisteredCustomer") {
  navigate("/");
} else if (userRole === "TruckDriver") {
   navigate(`/driver-map/${data.user.id}`); // use 'id', not '_id'
 // <-- redirect to DriverMap
} else {
  navigate("/"); // Default fallback
}

      }
    } catch (err) {
      console.error(err);
      setError("Something went wrong. Try again.");
    }
  };

  return (
    <div className="login-container">
      <h1>Login</h1>
      {error && <p className="login-error">{error}</p>}

      <form onSubmit={handleSubmit}>
        <div>
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>

        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button type="submit">Login</button>
      </form>

      <div className="login-links">
        <p>
          Don't have an account? <Link to="/register">Register</Link>
        </p>
        <p>
          <Link to="/forgot-password">Forgot Password?</Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
