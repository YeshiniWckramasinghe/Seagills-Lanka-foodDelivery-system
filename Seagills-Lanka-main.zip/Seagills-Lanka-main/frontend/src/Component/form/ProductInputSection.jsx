// src/Component/form/ProductInputSection.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";
import { FaPlus } from "react-icons/fa";
import FormGroup from "./FormGroup";

const ProductInputSection = ({
  category, // The category selected in the main form (passed down)
  currentProduct,
  filteredProducts,
  units,
  handleProductChange,
  addProduct,
}) => {
  const productsAvailable = filteredProducts.length > 0;

  return (
    <>
      <SectionHeader>Add Products</SectionHeader>

      {/* Info Message based on category selection */}
      {!category && (
        <InfoMessage>
          Please select a category first to see available products
        </InfoMessage>
      )}

      {category && (
        <>
          <ProductInputGrid>
            {/* 1. Product Dropdown */}
            <FormGroup
              label="Product *"
              type="select"
              name="productID"
              value={currentProduct.productID}
              onChange={handleProductChange}
              disabled={!productsAvailable}
              note={
                !productsAvailable
                  ? "No products found for this category"
                  : null
              }
            >
              <option value="">Select product...</option>
              {filteredProducts.map((product) => (
                <option key={product._id} value={product._id}>
                  {product.productName} - LKR {product.price}
                </option>
              ))}
            </FormGroup>

            {/* 2. Quantity Input */}
            <FormGroup
              label="Quantity *"
              type="input"
              inputType="number"
              name="quantity"
              value={currentProduct.quantity}
              onChange={handleProductChange}
              placeholder="Enter quantity..."
              min="0"
              step="0.01"
            />

            {/* 3. Unit Dropdown */}
            <FormGroup
              label="Unit *"
              type="select"
              name="unit"
              value={currentProduct.unit}
              onChange={handleProductChange}
            >
              {units.map((unit) => (
                <option key={unit} value={unit}>
                  {unit}
                </option>
              ))}
            </FormGroup>
          </ProductInputGrid>

          <AddProductButton type="button" onClick={addProduct}>
            <FaPlus /> Add Product
          </AddProductButton>
        </>
      )}
    </>
  );
};

// Styled Components
const SectionHeader = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
`;

const ProductInputGrid = styled.div`
  display: grid;
  /* Updated grid: 2fr for Product, 1fr for Quantity, 1fr for Unit */
  grid-template-columns: 2fr 1fr 1fr;
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.md};

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const InfoMessage = styled.div`
  background: #e3f2fd;
  border: 1px solid #90caf9;
  border-radius: ${theme.borderRadius.md};
  padding: ${theme.spacing.md};
  color: #1976d2;
  margin-bottom: ${theme.spacing.lg};
  text-align: center;
`;

const AddProductButton = styled.button`
  background: ${theme.colors.secondary};
  color: ${theme.colors.textPrimary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: inline-flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  &:hover {
    background: ${theme.colors.secondaryDark};
    transform: translateY(-2px);
  }
`;

export default ProductInputSection;
