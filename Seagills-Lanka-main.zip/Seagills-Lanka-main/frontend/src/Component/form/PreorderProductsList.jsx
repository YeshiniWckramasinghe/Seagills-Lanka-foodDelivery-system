// src/Component/form/PreorderProductsList.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";

const PreorderProductsList = ({ items }) => {
  if (!items || items.length === 0) {
    return <EmptyMessage>No preorder products assigned for today</EmptyMessage>;
  }

  // Group products by name and sum quantities
  const groupedProducts = items.reduce((acc, item) => {
    const key = item.productName;
    if (acc[key]) {
      acc[key].totalQuantity += item.quantity;
    } else {
      acc[key] = {
        productName: item.productName,
        totalQuantity: item.quantity,
        unit: item.unit,
      };
    }
    return acc;
  }, {});

  const totalItems = items.length;
  const uniqueProducts = Object.keys(groupedProducts).length;

  return (
    <Container>
      <Header>
        <Title>Verified Preorder Products</Title>
        <Stats>
          <Stat>
            <StatLabel>Total Items:</StatLabel>
            <StatValue>{totalItems}</StatValue>
          </Stat>
          <Stat>
            <StatLabel>Unique Products:</StatLabel>
            <StatValue>{uniqueProducts}</StatValue>
          </Stat>
        </Stats>
      </Header>

      <ProductsGrid>
        {Object.entries(groupedProducts).map(([key, product]) => (
          <ProductCard key={key}>
            <ProductName>{product.productName}</ProductName>
            <QuantityDisplay>
              <QuantityValue>{product.totalQuantity}</QuantityValue>
              <UnitLabel>{product.unit}</UnitLabel>
            </QuantityDisplay>
          </ProductCard>
        ))}
      </ProductsGrid>

      <TotalBox>
        <TotalLabel>Total Preorder Products: </TotalLabel>
        <TotalCount>{uniqueProducts} items</TotalCount>
      </TotalBox>
    </Container>
  );
};

const Container = styled.div`
  background: ${theme.colors.background};
  border-radius: ${theme.borderRadius.md};
  padding: ${theme.spacing.lg};
  border: 2px solid ${theme.colors.info};
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.lg};

  @media (max-width: 768px) {
    flex-direction: column;
    gap: ${theme.spacing.md};
    align-items: flex-start;
  }
`;

const Title = styled.h4`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0;
`;

const Stats = styled.div`
  display: flex;
  gap: ${theme.spacing.lg};
`;

const Stat = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
`;

const StatLabel = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const StatValue = styled.span`
  color: ${theme.colors.primary};
  font-weight: ${theme.typography.fontWeight.bold};
  font-size: ${theme.typography.fontSize.lg};
`;

const ProductsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: ${theme.spacing.md};
  margin-bottom: ${theme.spacing.lg};
`;

const ProductCard = styled.div`
  background: ${theme.colors.white};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  padding: ${theme.spacing.md};
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`;

const ProductName = styled.div`
  color: ${theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin-bottom: ${theme.spacing.sm};
  font-size: ${theme.typography.fontSize.base};
`;

const QuantityDisplay = styled.div`
  display: flex;
  align-items: baseline;
  gap: ${theme.spacing.sm};
`;

const QuantityValue = styled.span`
  color: ${theme.colors.info};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
`;

const UnitLabel = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const TotalBox = styled.div`
  background: ${theme.colors.info};
  color: ${theme.colors.white};
  padding: ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  display: flex;
  justify-content: center;
  align-items: center;
  gap: ${theme.spacing.md};
  font-weight: ${theme.typography.fontWeight.semibold};
`;

const TotalLabel = styled.span``;

const TotalCount = styled.span`
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.bold};
`;

const EmptyMessage = styled.div`
  background: ${theme.colors.background};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  padding: ${theme.spacing.lg};
  text-align: center;
  color: ${theme.colors.textSecondary};
`;

export default PreorderProductsList;
