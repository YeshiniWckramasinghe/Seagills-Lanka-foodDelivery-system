// src/Component/form/FormGroup.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";

// Styled Components
const GroupContainer = styled.div`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.sm};
`;

const Input = styled.input`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};
  background: ${(props) =>
    props.readOnly || props.disabled
      ? theme.colors.backgroundDark
      : theme.colors.white};

  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }

  &:disabled {
    background: ${theme.colors.backgroundDark};
    cursor: not-allowed;
  }

  &:read-only {
    background: ${theme.colors.backgroundDark};
    cursor: default;
  }
`;

const Select = styled.select`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};
  background: ${theme.colors.white};
  cursor: pointer;

  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }

  &:disabled {
    background: ${theme.colors.backgroundDark};
    cursor: not-allowed;
  }
`;

const DisplayField = styled.div`
  padding: ${theme.spacing.md};
  background: ${theme.colors.backgroundDark};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  color: ${theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.medium};
  min-height: 46px; /* Match input height */
`;

const FieldNote = styled.div`
  font-size: ${theme.typography.fontSize.xs};
  color: ${theme.colors.textSecondary};
  margin-top: ${theme.spacing.xs};
`;

const ComponentMap = {
  input: Input,
  select: Select,
  display: DisplayField,
};

// Main Component
const FormGroup = ({
  label,
  type = "input", // input, select, display
  inputType, // for input type="date", type="number", etc.
  note,
  children, // for select options or display content
  ...props
}) => {
  const Component = ComponentMap[type];

  if (!Component) return null;

  return (
    <GroupContainer>
      {label && <Label>{label}</Label>}
      {type === "display" ? (
        <DisplayField>
          {children}
          {note && <FieldNote>{note}</FieldNote>}
        </DisplayField>
      ) : type === "input" ? (
        <>
          <Component type={inputType || "text"} {...props} />
          {note && <FieldNote>{note}</FieldNote>}
        </>
      ) : (
        <>
          <Component {...props}>{children}</Component>
          {note && <FieldNote>{note}</FieldNote>}
        </>
      )}
    </GroupContainer>
  );
};
export default FormGroup;
