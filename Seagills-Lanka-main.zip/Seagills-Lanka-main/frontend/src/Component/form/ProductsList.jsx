// src/Component/form/ProductsList.jsx
import React from "react";
import styled from "styled-components";
import theme from "../../styles/theme";
import { FaTimes } from "react-icons/fa";

const ProductsList = ({ items, removeProduct }) => {
  return (
    <ListContainer>
      <ProductsHeader>Added Products ({items.length})</ProductsHeader>
      {items.map((item, index) => (
        <ProductItem key={index}>
          <ProductInfo>
            <ProductName>{item.productName}</ProductName>
            <ProductDetails>
              Quantity: {item.quantity} {item.unit}
            </ProductDetails>
          </ProductInfo>
          <RemoveButton type="button" onClick={() => removeProduct(index)}>
            <FaTimes />
          </RemoveButton>
        </ProductItem>
      ))}
    </ListContainer>
  );
};

// Styled Components
const ListContainer = styled.div`
  margin-top: ${theme.spacing.lg};
`;

const ProductsHeader = styled.h4`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.md};
`;

const ProductItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${theme.spacing.md};
  background: ${theme.colors.background};
  border-radius: ${theme.borderRadius.md};
  margin-bottom: ${theme.spacing.sm};
`;

const ProductInfo = styled.div``;

const ProductName = styled.div`
  color: ${theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.xs};
`;

const ProductDetails = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const RemoveButton = styled.button`
  background: ${theme.colors.error};
  color: white;
  border: none;
  width: 32px;
  height: 32px;
  border-radius: ${theme.borderRadius.md};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all ${theme.transitions.fast};

  &:hover {
    background: #d32f2f;
  }
`;

export default ProductsList;
