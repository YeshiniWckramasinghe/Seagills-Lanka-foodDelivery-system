import React from "react";
import "./AboutUs.css";

const AboutUs = () => {
  return (
    <div className="about-container">
      <div className="about-header">
        <h1>About Seagills Lanka Grocery</h1>
        <p>Your Trusted Partner for Fresh and Fast Grocery Delivery</p>
      </div>

      <div className="about-content">
        <section className="about-section">
          <h2>Who We Are</h2>
          <p>
            Seagills Lanka Grocery is a nationwide delivery service dedicated to
            bringing the market straight to your doorstep. We take pride in
            connecting customers with farm-fresh produce, quality meats, seafood,
            fruits, and aromatic spices — all sourced from trusted local
            suppliers and delivered with care.
          </p>
        </section>

        <section className="about-section">
          <h2>Our Categories</h2>
          <ul>
            <li>
              <strong>Meat:</strong> Fresh, hygienically packed chicken, beef, and
              mutton from approved farms.
            </li>
            <li>
              <strong>Fish:</strong> Daily-caught seafood from coastal suppliers
              ensuring premium freshness.
            </li>
            <li>
              <strong>Vegetables & Spices:</strong> Handpicked greens and locally
              ground spices for healthy, flavorful cooking.
            </li>
            <li>
              <strong>Fruits:</strong> Juicy seasonal and tropical fruits, selected
              at the peak of freshness.
            </li>
          </ul>
        </section>

        <section className="about-section">
          <h2>Our Mission</h2>
          <p>
            To simplify grocery shopping by providing a reliable, affordable, and
            eco-friendly delivery service that saves your time while guaranteeing
            top quality in every order.
          </p>
        </section>

        <section className="about-section">
          <h2>Why Choose Us?</h2>
          <ul>
            <li>Daily fresh products from local suppliers</li>
            <li>Quick and temperature-controlled delivery</li>
            <li>Separate delivery lorries for each category</li>
            <li>Preorder and on-route order options</li>
            <li>Secure payment methods and instant e-billing</li>
          </ul>
        </section>

        <section className="about-section">
          <h2>Contact Us</h2>
          <p>Email: <a href="mailto:info@seagillslanka.com">info@seagillslanka.com</a></p>
          <p>Phone: +94 11 234 5678</p>
          <p>Address: No. 25, Galle Road, Colombo, Sri Lanka</p>
        </section>
      </div>
    </div>
  );
};

export default AboutUs;
