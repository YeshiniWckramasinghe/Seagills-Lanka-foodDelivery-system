
import React, { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import { 
  MdAdd, 
  MdEdit, 
  MdDelete, 
  MdClose, 
  MdAnalytics,
  MdWarning,
  MdInventory2
} from "react-icons/md";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { FaTruck } from "react-icons/fa";

const Stock = () => {
  const navigate = useNavigate();
  const [stocks, setStocks] = useState([]);
  const [products, setProducts] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isChartOpen, setIsChartOpen] = useState(false);
  const [lowStockThreshold, setLowStockThreshold] = useState(10);
  const [formData, setFormData] = useState({
    _id: "",
    productID: "",
    stockLevel: "",
    lastRestockedDate: "",
  });

  // Fetch stock data
  const fetchStocks = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/manage-stock/view");
      setStocks(res.data);
    } catch (err) {
      console.error(err);
      toast.error("Error fetching stocks");
    }
  };

      const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  // Fetch products for dropdown
  const fetchProducts = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/products");
      setProducts(res.data);
    } catch (err) {
      console.error(err);
      toast.error("Error fetching products");
    }
  };

  useEffect(() => {
    fetchStocks();
    fetchProducts();
  }, []);

  // Handle input
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Add or Update Stock
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        productID: formData.productID,
        stockLevel: formData.stockLevel,
        lastRestockedDate: formData.lastRestockedDate,
      };

      if (formData._id) {
        await axios.put(
          `http://localhost:5000/api/manage-stock/update/${formData._id}`,
          payload
        );
        toast.success("Stock updated successfully!");
      } else {
        await axios.post("http://localhost:5000/api/manage-stock/add", payload);
        toast.success("Stock added successfully!");
      }

      setIsModalOpen(false);
      setFormData({ _id: "", productID: "", stockLevel: "", lastRestockedDate: "" });
      fetchStocks();
    } catch (err) {
      console.error(err.response?.data || err.message);
      toast.error(err.response?.data?.message || "Error saving stock");
    }
  };

  // Edit stock
  const handleEdit = (stock) => {
    setFormData({
      _id: stock._id,
      productID: stock.productID?._id || "",
      stockLevel: stock.stockLevel || "",
      lastRestockedDate: stock.lastRestockedDate
        ? new Date(stock.lastRestockedDate).toISOString().split("T")[0]
        : "",
    });
    setIsModalOpen(true);
  };

  // Delete stock
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this stock?")) return;
    try {
      await axios.delete(`http://localhost:5000/api/manage-stock/delete/${id}`);
      toast.success("Stock deleted successfully!");
      fetchStocks();
    } catch (err) {
      console.error(err);
      toast.error("Error deleting stock");
    }
  };

  // Get low stock items
  const lowStockItems = stocks.filter(stock => stock.stockLevel <= lowStockThreshold);
  
  // Get stock status data for charts
  const getStockStatusData = () => {
    const low = stocks.filter(stock => stock.stockLevel <= lowStockThreshold).length;
    const adequate = stocks.filter(stock => stock.stockLevel > lowStockThreshold && stock.stockLevel <= 50).length;
    const high = stocks.filter(stock => stock.stockLevel > 50).length;
    
    return [
      { name: 'Low Stock', value: low, color: '#ef4444' },
      { name: 'sufficient', value: adequate, color: '#3b82f6' },
      { name: 'High Stock', value: high, color: '#10b981' }
    ];
  };

  // Prepare chart data
  const chartData = stocks.map(stock => ({
    name: stock.productID?.productName || 'Unknown',
    stock: stock.stockLevel,
    status: stock.stockLevel <= lowStockThreshold ? 'Low' : stock.stockLevel <= 50 ? 'Adequate' : 'High'
  }));

  const COLORS = ['#ef4444', '#3b82f6', '#10b981'];

  return (
    <PageContainer>
          <Header>
            <LogoSection onClick={() => navigate("/admin-dashboard")}>
              <Logo>
                <FaTruck color={theme.colors.primary} />
              </Logo>
              <BrandInfo>
                <BrandName>Seagills Lanka</BrandName>
                <BrandTagline>Inventory Management</BrandTagline>
              </BrandInfo>
            </LogoSection>

            <UserSection>
          <UserInfo>
            <UserName>
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </UserName>
            <UserRole>Admin</UserRole>
          </UserInfo>
          <DateText>{today}</DateText>
          <BackButton onClick={() => navigate("/admin-dashboard")}>Back</BackButton>
        </UserSection>
      </Header>
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <MdInventory2 className="text-blue-600 text-2xl" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Stock Management</h1>
            <p className="text-gray-600">Manage product inventory and stock levels</p>
          </div>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setIsChartOpen(true)}
            className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg shadow hover:bg-green-700 transition-colors"
          >
            <MdAnalytics /> View Analytics
          </button>
          <button
            onClick={() => {
              setFormData({ _id: "", productID: "", stockLevel: "", lastRestockedDate: "" });
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg shadow hover:bg-blue-700 transition-colors"
          >
            <MdAdd /> Add Stock
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg shadow border-l-4 border-blue-500">
          <h3 className="text-gray-600 text-sm">Total Products</h3>
          <p className="text-2xl font-bold text-gray-800">{stocks.length}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow border-l-4 border-green-500">
          <h3 className="text-gray-600 text-sm">In Stock</h3>
          <p className="text-2xl font-bold text-gray-800">
            {stocks.filter(s => s.stockLevel > 0).length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow border-l-4 border-red-500">
          <h3 className="text-gray-600 text-sm">Low Stock</h3>
          <p className="text-2xl font-bold text-red-600">{lowStockItems.length}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow border-l-4 border-yellow-500">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-gray-600 text-sm">Low Stock Threshold</h3>
              <p className="text-2xl font-bold text-gray-800">{lowStockThreshold}</p>
            </div>
            <input
              type="number"
              value={lowStockThreshold}
              onChange={(e) => setLowStockThreshold(Number(e.target.value))}
              className="w-16 p-1 border rounded text-sm"
              min="1"
            />
          </div>
        </div>
      </div>

      {/* Low Stock Alert */}
      {lowStockItems.length > 0 && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3">
          <MdWarning className="text-red-500 text-xl flex-shrink-0" />
          <div>
            <h4 className="font-semibold text-red-800">Low Stock Alert</h4>
            <p className="text-red-600 text-sm">
              {lowStockItems.length} product{lowStockItems.length > 1 ? 's' : ''} have stock levels below {lowStockThreshold}
            </p>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b">
                <th className="p-4 text-left font-semibold text-gray-700">Product</th>
                <th className="p-4 text-left font-semibold text-gray-700">Stock Level</th>
                <th className="p-4 text-left font-semibold text-gray-700">Status</th>
                <th className="p-4 text-left font-semibold text-gray-700">Last Restocked</th>
                <th className="p-4 text-center font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {stocks.map((stock) => {
                const isLowStock = stock.stockLevel <= lowStockThreshold;
                return (
                  <tr key={stock._id} className="border-b hover:bg-gray-50 transition-colors">
                    <td className="p-4">
                      <div className="font-medium text-gray-900">
                        {stock.productID?.productName || "N/A"}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <span className={`font-semibold ${
                          isLowStock ? 'text-red-600' : 'text-gray-900'
                        }`}>
                          {stock.stockLevel}
                        </span>
                        {isLowStock && (
                          <MdWarning className="text-red-500" size={16} />
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        isLowStock 
                          ? 'bg-red-100 text-red-800'
                          : stock.stockLevel <= 50
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {isLowStock ? 'Low Stock' : stock.stockLevel <= 50 ? 'sufficient' : 'High Stock'}
                      </span>
                    </td>
                    <td className="p-4 text-gray-600">
                      {stock.lastRestockedDate
                        ? new Date(stock.lastRestockedDate).toLocaleDateString()
                        : "—"}
                    </td>
                    <td className="p-4">
                      <div className="flex justify-center gap-2">
                        <button
                          onClick={() => handleEdit(stock)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Edit stock"
                        >
                          <MdEdit size={18} />
                        </button>
                        <button
                          onClick={() => handleDelete(stock._id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete stock"
                        >
                          <MdDelete size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {stocks.length === 0 && (
                <tr>
                  <td colSpan="5" className="text-center p-8 text-gray-500">
                    <MdInventory2 className="mx-auto text-4xl text-gray-300 mb-2" />
                    No stock records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Stock Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded-xl shadow-2xl w-full max-w-md mx-4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-800">
                {formData._id ? "Edit Stock" : "Add New Stock"}
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <MdClose size={24} className="text-gray-500" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Product
                </label>
                <select
                  name="productID"
                  value={formData.productID}
                  onChange={handleChange}
                  className="w-full border border-gray-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  required
                >
                  <option value="">Select Product</option>
                  {products.map((product) => (
                    <option key={product._id} value={product._id}>
                      {product.productName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Stock Level
                </label>
                <input
                  type="number"
                  name="stockLevel"
                  placeholder="Enter stock quantity"
                  value={formData.stockLevel}
                  onChange={handleChange}
                  className="w-full border border-gray-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  min={0}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Last Restocked Date
                </label>
                <input
                  type="date"
                  name="lastRestockedDate"
                  value={formData.lastRestockedDate}
                  onChange={handleChange}
                  className="w-full border border-gray-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold"
              >
                {formData._id ? "Update Stock" : "Add Stock"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Charts Modal */}
      {isChartOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded-xl shadow-2xl w-full max-w-6xl mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Stock Analytics</h2>
              <button 
                onClick={() => setIsChartOpen(false)}
                className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <MdClose size={24} className="text-gray-500" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              {/* Stock Levels Bar Chart */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-4 text-gray-800">Stock Levels by Product</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar 
                        dataKey="stock" 
                        name="Stock Level"
                        fill="#3b82f6"
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Stock Status Pie Chart */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-4 text-gray-800">Stock Status Distribution</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={getStockStatusData()}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value, percent }) => 
                          `${name}: ${value} (${(percent * 100).toFixed(0)}%)`
                        }
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {getStockStatusData().map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Low Stock Products */}
            {lowStockItems.length > 0 && (
              <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                <h3 className="text-lg font-semibold mb-4 text-red-800 flex items-center gap-2">
                  <MdWarning /> Low Stock Products (Below {lowStockThreshold})
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {lowStockItems.map(item => (
                    <div key={item._id} className="bg-white p-3 rounded border border-red-200">
                      <div className="font-medium text-red-800">
                        {item.productID?.productName || 'Unknown'}
                      </div>
                      <div className="text-red-600 text-sm">
                        Current Stock: {item.stockLevel}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <ToastContainer position="top-right" />
    </div>
    </PageContainer>
  );
};

// Styled Components
const PageContainer = styled.div`
  
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
  
`;

const Header = styled.header`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  z-index: 1;
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const DateText = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
`;

const BackButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

export default Stock;