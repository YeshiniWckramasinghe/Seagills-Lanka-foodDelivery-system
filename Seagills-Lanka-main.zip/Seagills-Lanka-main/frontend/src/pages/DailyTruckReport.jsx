import React, { useEffect, useState } from "react";
import styled, { createGlobalStyle } from "styled-components";
import { jsPDF } from "jspdf";
import "jspdf-autotable";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import { reportAPI } from "../services/api";

// Reset html/body margins for this component only
const ResetGlobalStyle = createGlobalStyle`
  html, body {
    margin: 0 !important;
    padding: 0 !important;
    height: 100%;
  }
`;

const DailyTruckReport = () => {
  const navigate = useNavigate();
  const [reportData, setReportData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [displayDate, setDisplayDate] = useState("");

  // Fetch today's report
  useEffect(() => {
    // FIX: Get LOCAL date, not UTC
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const localDate = `${year}-${month}-${day}`;
    
    setDisplayDate(localDate); // Store for display
    console.log("📅 Fetching report for LOCAL date:", localDate);

    const fetchReport = async () => {
      try {
        setLoading(true);
        setError(null);
        
        console.log(`🔄 Making request for: ${localDate}`);
        const res = await reportAPI.getDailyTruckReport(localDate);
        
        console.log("✅ API Response:", res.data);
        
        if (res.data.success) {
          console.log("📊 Report data received:", res.data.report);
          setReportData(res.data.report || []);
        } else {
          console.warn("⚠️ API returned success: false");
          setReportData([]);
        }
      } catch (err) {
        console.error("❌ Failed to fetch report:", err);
        
        // More detailed error logging
        if (err.response) {
          console.error("Backend error status:", err.response.status);
          console.error("Backend error data:", err.response.data);
          console.error("Full error object:", JSON.stringify(err.response.data, null, 2));
          setError(
            `Error: ${err.response.status} - ${err.response.data?.message || JSON.stringify(err.response.data)}`
          );
        } else if (err.request) {
          console.error("No response received:", err.request);
          setError("No response from server. Check if backend is running.");
        } else {
          console.error("Error:", err.message);
          setError(`Failed: ${err.message}`);
        }
        
        setReportData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchReport();
  }, []);

  const downloadPDF = () => {
    try {
      const autoTable = require("jspdf-autotable").default;

      const doc = new jsPDF();

      autoTable(doc, {
        head: [
          [
            "Truck Number",
            "Plate No",
            "Colour",
            "Status",
            "Route",
            "Start Time",
            "Trip Status",
          ],
        ],
        body: reportData.map((truck) => [
          truck.truckNumber || "-",
          truck.plateNo || "-",
          truck.colour || "-",
          truck.status || "-",
          truck.route ? truck.route.replace(/→/g, "->") : "-",
          truck.startTime || "-",
          truck.tripStatus || "-",
        ]),
        startY: 30,
        styles: {
          font: "helvetica",
          fontSize: 10,
        },
        headStyles: {
          fillColor: [41, 128, 185],
          textColor: 255,
          fontStyle: "bold",
        },
      });

      doc.setFontSize(18);
      doc.text("Seagills Lanka - Daily Truck Report", 14, 15);

      const dateStr = new Date().toLocaleDateString();
      doc.setFontSize(10);
      doc.text(`Date: ${dateStr}`, 180, 10, { align: "right" });

      doc.save(`SeagillsLanka_DailyTruckReport_${dateStr}.pdf`);
      console.log("✅ PDF generated successfully");
    } catch (err) {
      console.error("❌ PDF download error:", err);
      alert("Error generating PDF: " + err.message);
    }
  };

  return (
    <>
      <ResetGlobalStyle />
      <PageContainer>
        <Header>
          <Title>Daily Truck Assignment Report</Title>
          <BackButton onClick={() => navigate("/admin-reports")}>
            Back
          </BackButton>
        </Header>

        <Content>
          {loading && (
            <LoadingMessage>
              ⏳ Loading report data for {displayDate}...
            </LoadingMessage>
          )}
          
          {error && (
            <>
              <ErrorMessage>
                <strong>❌ Error:</strong> {error}
              </ErrorMessage>
              <DebugInfo>
                <p><strong>Troubleshooting:</strong></p>
                <ul>
                  <li>✓ Is your backend running on port 5000?</li>
                  <li>✓ Have you created any truck assignments for today?</li>
                  <li>✓ Check browser console (F12) for more details</li>
                  <li>✓ Check backend logs for API errors</li>
                </ul>
              </DebugInfo>
            </>
          )}

          {!loading && !error && (
            <>
              <TableContainer>
                <Table>
                  <thead>
                    <tr>
                      <th>Truck Number</th>
                      <th>Plate No</th>
                      <th>Colour</th>
                      <th>Status</th>
                      <th>Route</th>
                      <th>Start Time</th>
                      <th>Trip Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reportData.length > 0 ? (
                      reportData.map((truck, idx) => (
                        <tr key={idx}>
                          <td>{truck.truckNumber}</td>
                          <td>{truck.plateNo}</td>
                          <td>{truck.colour}</td>
                          <td>{truck.status}</td>
                          <td>{truck.route}</td>
                          <td>{truck.startTime || "-"}</td>
                          <td>{truck.tripStatus}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="7">
                          ℹ️ No trucks assigned for today ({displayDate})
                        </td>
                      </tr>
                    )}
                  </tbody>
                </Table>
              </TableContainer>

              {reportData.length > 0 && (
                <DownloadButton onClick={downloadPDF}>
                  Download as PDF
                </DownloadButton>
              )}
            </>
          )}
        </Content>
      </PageContainer>
    </>
  );
};

// Styled Components
const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
  margin: 0;
  padding: 0;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  background: ${theme.colors.primary};
  color: white;
  margin: 0;
`;

const Title = styled.h2`
  font-size: ${theme.typography.fontSize["2xl"]};
  margin: 0;
`;

const BackButton = styled.button`
  background: white;
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  cursor: pointer;

  &:hover {
    opacity: 0.9;
  }
`;

const Content = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
  display: flex;
  flex-direction: column;
  gap: ${theme.spacing.lg};
`;

const LoadingMessage = styled.div`
  text-align: center;
  padding: ${theme.spacing.xl};
  font-size: ${theme.typography.fontSize.md};
  color: ${theme.colors.textSecondary};
`;

const ErrorMessage = styled.div`
  background: #fee;
  border: 2px solid #fcc;
  color: #c33;
  padding: ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  text-align: left;
  font-family: monospace;
  font-size: ${theme.typography.fontSize.sm};
`;

const DebugInfo = styled.div`
  background: #f9f9f9;
  border: 1px solid #ddd;
  padding: ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.sm};
  
  ul {
    margin: 0;
    padding-left: 20px;
  }
  
  li {
    margin: 8px 0;
  }
`;

const TableContainer = styled.div`
  overflow-x: auto;
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  background: white;
  border: 1px solid ${theme.colors.border};

  th,
  td {
    padding: ${theme.spacing.sm};
    text-align: left;
    border: 1px solid ${theme.colors.border};
    font-size: ${theme.typography.fontSize.sm};
  }

  th {
    background: ${theme.colors.primary};
    color: white;
    font-weight: bold;
  }

  tbody tr:hover {
    background: #f5f5f5;
  }
`;

const DownloadButton = styled.button`
  align-self: flex-end;
  background: ${theme.colors.primary};
  color: white;
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  cursor: pointer;
  font-weight: ${theme.typography.fontWeight.semibold};

  &:hover {
    background: ${theme.colors.primaryDark};
  }

  &:active {
    transform: scale(0.98);
  }
`;

export default DailyTruckReport;