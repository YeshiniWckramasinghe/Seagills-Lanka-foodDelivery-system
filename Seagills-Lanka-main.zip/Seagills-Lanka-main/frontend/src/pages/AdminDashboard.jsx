// src/pages/AdminDashboard.jsx
import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { useNavigate } from "react-router-dom";
import theme from "../styles/theme";
import Modal from "../Component/Modal";
import {
  truckAPI,
  userAPI,
  preorderAPI,
  enrouteOrderAPI,
} from "../services/api";
import { quickActions } from "../features/admin/AdminQuickActionsData";
import Header from "../Component/Layout/Header";
import LoadingState from "../Component/common/LoadingState";
import StatsGrid from "../Component/dashboard/StatsGrid";
import ActionsSection from "../Component/dashboard/ActionsSection";

import {
  FaTruck,
  FaBox,
  FaUsers,
  FaDollarSign,
  FaCalendarAlt,
  FaChartLine,
  FaClipboardList,
  FaUsersCog,
  FaBoxOpen,
} from "react-icons/fa";


const AdminDashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Dashboard state, which will be passed down to StatsGrid
  const [dashboardData, setDashboardData] = useState({
    preOrders: 0,
    preOrdersChange: "+0%",
    enrouteOrders: 0,
    enrouteOrdersChange: "+0%",
    totalTrucks: 0,
    trucksChange: "+0%",
    coordinators: 0,
    coordinatorsChange: "+0%",
    drivers: 0,
    driversChange: "+0%",
  });

  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  // Data Fetching Logic
  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [trucksRes, coordinatorsRes, driversRes, preordersRes, enrouteRes] =
        await Promise.all([
          truckAPI.getAllTrucks(),
          userAPI.getAllDeliveryCoordinators(),
          userAPI.getUsersByRole("truck_driver"),
          preorderAPI.getAllPreorders(),
          enrouteOrderAPI.getAllOrders(),
        ]);

      const truckCount = trucksRes.data.length;
      const coordinatorCount = coordinatorsRes.data.count || 0;
      const driverCount = driversRes.data.length;

      // Count preorders and enroute orders
      const preOrderCount = preordersRes.data.length;
      const enrouteOrderCount = enrouteRes.data.length;

      setDashboardData((prevData) => ({
        ...prevData,
        totalTrucks: truckCount,
        coordinators: coordinatorCount,
        drivers: driverCount,
        preOrders: preOrderCount,
        enrouteOrders: enrouteOrderCount,
      }));
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      // setModal({ isOpen: true, type: 'error', title: 'Data Error', message: 'Could not load dashboard stats.' });
    } finally {
      setLoading(false);
    }
  };

  // Lifecycle/Side Effects
  useEffect(() => {
    document.body.style.paddingTop = "0";
    fetchDashboardData();
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Handlers
  const handleSignOut = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/login");
  };

  // Utility for time formatting

  const quickActionsLocal = [
    {
      icon: <FaTruck />,
      title: "Assign Truck",
      description: "Assign trucks to coordinators",
      path: "/admin/assign-truck",
      color: theme.colors.primary,
    },
    {
      icon: <FaCalendarAlt />,
      title: "Set Schedules",
      description: "Manage delivery schedules",
      path: "/admin/schedules",
      color: "#FFA726",
    },
    {
      icon: <FaChartLine />,
      title: "View Reports",
      description: "Analytics and reports",
      path: "/admin/reports",
      color: "#66BB6A",
    },
    {
      icon: <FaUsersCog />,
      title: "Manage Users",
      description: "User management",
      path: "/admin/users",
      color: "#AB47BC",
    },
    {
      icon: <FaBoxOpen  />,
      title: "Manage Stock",
      description: "Stock management",
      path: "/admin/inventory",
      color: "#cf6824ff",
    },
  ];


  const formatTime = currentTime.toLocaleString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  // Render Loading State
  if (loading) {
    return <LoadingState />;
  }

  // Main Render
  return (
    <PageContainer>
      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      {/* Reusable Header Component */}
      <Header onSignOut={handleSignOut} />

      <MainContent>
        {/* Page Header Section */}
        <PageHeader>
          <div>
            <PageTitle>Admin Dashboard</PageTitle>
            <PageSubtitle>
              Welcome back! Here's what's happening with your deliveries today.
            </PageSubtitle>
          </div>
          <TimeDisplay>{formatTime}</TimeDisplay>
        </PageHeader>

        {/* Reusable Stats Grid Component */}
        <StatsGrid data={dashboardData} />

        {/* Reusable Actions Section Component */}
        <ActionsSection actions={quickActions} navigate={navigate} />
      </MainContent>
    </PageContainer>
  );
};

// Styled Components for the Main Layout (Keep these here)
const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
`;


const LoadingContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  gap: ${theme.spacing.lg};
`;

const LoadingSpinner = styled.div`
  width: 50px;
  height: 50px;
  border: 4px solid ${theme.colors.border};
  border-top: 4px solid ${theme.colors.primary};
  border-radius: 50%;
  animation: spin 1s linear infinite;

  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`;

const LoadingText = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.lg};
`;

const HeaderStyled = styled.header`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const SignOutButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;


const MainContent = styled.main`
  max-width: 1400px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const PageHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: ${theme.spacing.xl};

  @media (max-width: 768px) {
    flex-direction: column;
    gap: ${theme.spacing.md};
  }
`;

const PageTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0 0 ${theme.spacing.xs};
`;

const PageSubtitle = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
  margin: 0;
  max-width: 600px;
`;

const TimeDisplay = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
`;



const StatsGridStyled = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.xl};
`;

const StatCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  display: flex;
  gap: ${theme.spacing.lg};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px ${theme.colors.shadowMedium};
  }
`;

const StatIcon = styled.div`
  width: 64px;
  height: 64px;
  background: ${(props) => props.color};
  color: white;
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  flex-shrink: 0;
`;

const StatContent = styled.div`
  flex: 1;
`;

const StatLabel = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  margin-bottom: ${theme.spacing.xs};
`;

const StatValue = styled.div`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin-bottom: ${theme.spacing.xs};
`;

const StatChange = styled.div`
  color: ${(props) =>
    props.positive ? "#4CAF50" : theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.xs};
  font-weight: ${theme.typography.fontWeight.medium};
`;

const ActionsSectionStyled = styled.div`
  margin-top: ${theme.spacing.xxl};
`;

const SectionTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
`;

const ActionsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: ${theme.spacing.lg};
`;

const ActionCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  text-align: center;
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  box-shadow: 0 2px 8px ${theme.colors.shadow};

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px ${theme.colors.shadowMedium};
  }
`;

const ActionIcon = styled.div`
  width: 64px;
  height: 64px;
  background: ${(props) => props.color};
  color: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  margin: 0 auto ${theme.spacing.md};
`;

const ActionTitle = styled.h4`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0;
`;


export default AdminDashboard;