// src/pages/SetSchedules.jsx
import React, { useState, useEffect } from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import {
  FaTruck,
  FaPlus,
  FaEdit,
  FaTrash,
  FaTimes,
  FaRoute,
  FaClock,
  FaCheckCircle,
  FaHourglassHalf,
  FaCalendar,
} from "react-icons/fa";
import { truckRouteAPI, truckAPI, routeAPI } from "../services/api";
import Modal from "../Component/Modal";

const SetSchedules = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [schedules, setSchedules] = useState([]);
  const [trucks, setTrucks] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [formData, setFormData] = useState({
    truckID: "",
    routeID: "",
    date: new Date().toISOString().split("T")[0],
    startTime: "",
  });

  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  useEffect(() => {
    document.body.style.paddingTop = "0";
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, []);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      await Promise.all([fetchSchedules(), fetchTrucks(), fetchRoutes()]);
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchSchedules = async () => {
    try {
      const response = await truckRouteAPI.getAllSchedules();
      setSchedules(Array.isArray(response.data) ? response.data : []);
    } catch (err) {
      console.error("Error fetching schedules:", err);
    }
  };

  const fetchTrucks = async () => {
    try {
      const response = await truckAPI.getAllTrucks();
      setTrucks(Array.isArray(response.data) ? response.data : []);
    } catch (err) {
      console.error("Error fetching trucks:", err);
    }
  };

  const fetchRoutes = async () => {
    try {
      const response = await routeAPI.getAllRoutes();
      setRoutes(Array.isArray(response.data) ? response.data : []);
    } catch (err) {
      console.error("Error fetching routes:", err);
    }
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.truckID || !formData.routeID || !formData.startTime) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Missing Information",
        message:
          "Please fill in all required fields (Truck, Route, Date, Start Time)",
      });
      return;
    }

    try {
      if (editingId) {
        const response = await truckRouteAPI.updateSchedule(
          editingId,
          formData
        );
        setModal({
          isOpen: true,
          type: "success",
          title: "Success",
          message: "Schedule updated successfully",
        });
      } else {
        const response = await truckRouteAPI.createSchedule(formData);
        setModal({
          isOpen: true,
          type: "success",
          title: "Success",
          message: "Schedule created successfully",
        });
      }

      resetForm();
      fetchSchedules();
    } catch (err) {
      console.error("Error saving schedule:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Error",
        message: err.response?.data?.message || "Failed to save schedule",
      });
    }
  };

  const handleEdit = (schedule) => {
    setFormData({
      truckID: schedule.truckID?._id || "",
      routeID: schedule.routeID?._id || "",
      date: new Date(schedule.date).toISOString().split("T")[0],
      startTime: schedule.startTime || "",
    });
    setEditingId(schedule._id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this schedule?")) {
      try {
        await truckRouteAPI.deleteSchedule(id);
        setModal({
          isOpen: true,
          type: "success",
          title: "Deleted",
          message: "Schedule deleted successfully",
        });
        fetchSchedules();
      } catch (err) {
        console.error("Error deleting schedule:", err);
        setModal({
          isOpen: true,
          type: "error",
          title: "Error",
          message: "Failed to delete schedule",
        });
      }
    }
  };

  const resetForm = () => {
    setFormData({
      truckID: "",
      routeID: "",
      date: new Date().toISOString().split("T")[0],
      startTime: "",
    });
    setEditingId(null);
    setShowForm(false);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const formatTime = (timeString) => {
    return timeString;
  };

  // NEW: Get status badge based on trip status
  const getStatusBadge = (schedule) => {
    const status = schedule.tripStatus || "scheduled";

    switch (status) {
      case "completed":
        return (
          <StatusBadge $status="completed">
            <FaCheckCircle /> Completed
          </StatusBadge>
        );
      case "in_progress":
        return (
          <StatusBadge $status="in_progress">
            <FaHourglassHalf /> In Progress
          </StatusBadge>
        );
      case "scheduled":
      default:
        return (
          <StatusBadge $status="scheduled">
            <FaCalendar /> Scheduled
          </StatusBadge>
        );
    }
  };

  return (
    <PageContainer>
      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      <Header>
        <LogoSection onClick={() => navigate("/admin-dashboard")}>
          <Logo>
            <FaTruck />
          </Logo>
          <BrandInfo>
            <BrandName>Seagills Lanka</BrandName>
            <BrandTagline>Delivery Management</BrandTagline>
          </BrandInfo>
        </LogoSection>

        <UserSection>
          <UserInfo>
            <UserName>
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </UserName>
            <UserRole>Admin</UserRole>
          </UserInfo>
          <BackButton onClick={() => navigate("/admin-dashboard")}>
            Back
          </BackButton>
        </UserSection>
      </Header>

      <MainContent>
        <PageHeader>
          <PageTitle>Set Schedules</PageTitle>
          <DateDisplay>
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </DateDisplay>
        </PageHeader>

        <FormSection show={showForm}>
          <FormCard>
            <FormHeader>
              <FormTitle>
                <FaPlus /> {editingId ? "Edit" : "New"} Schedule
              </FormTitle>
              {showForm && (
                <CloseButton onClick={resetForm}>
                  <FaTimes />
                </CloseButton>
              )}
            </FormHeader>

            <form onSubmit={handleSubmit}>
              <FormGrid>
                <FormGroup>
                  <Label>Select Truck</Label>
                  <Select
                    name="truckID"
                    value={formData.truckID}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Choose truck...</option>
                    {trucks.map((truck) => (
                      <option key={truck._id} value={truck._id}>
                        {truck.plateNo}{" "}
                        {truck.colour ? `- ${truck.colour}` : ""}
                      </option>
                    ))}
                  </Select>
                </FormGroup>

                <FormGroup>
                  <Label>Select Route</Label>
                  <Select
                    name="routeID"
                    value={formData.routeID}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Choose route...</option>
                    {routes.map((route) => (
                      <option key={route._id} value={route._id}>
                        {`${route.start?.name} to ${route.end?.name}`}
                      </option>
                    ))}
                  </Select>
                </FormGroup>

                <FormGroup>
                  <Label>Date</Label>
                  <Input
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    required
                  />
                </FormGroup>

                <FormGroup>
                  <Label>Start Time</Label>
                  <Input
                    type="time"
                    name="startTime"
                    value={formData.startTime}
                    onChange={handleInputChange}
                    required
                  />
                </FormGroup>
              </FormGrid>

              <ButtonGroup>
                <SubmitButton type="submit">
                  {editingId ? "Update Schedule" : "Create Schedule"}
                </SubmitButton>
                <CancelButton type="button" onClick={resetForm}>
                  Cancel
                </CancelButton>
              </ButtonGroup>
            </form>
          </FormCard>
        </FormSection>

        {!showForm && (
          <AddButton onClick={() => setShowForm(true)}>
            <FaPlus /> New Schedule
          </AddButton>
        )}

        <SchedulesSection>
          <SectionTitle>All Schedules</SectionTitle>

          {loading ? (
            <LoadingText>Loading schedules...</LoadingText>
          ) : schedules.length === 0 ? (
            <EmptyState>
              <EmptyText>No schedules found. Create one above!</EmptyText>
            </EmptyState>
          ) : (
            <SchedulesGrid>
              {schedules.map((schedule) => (
                <ScheduleCard key={schedule._id}>
                  <CardHeader>
                    <TruckBadge>
                      <FaTruck /> {schedule.truckID?.plateNo || "N/A"}
                    </TruckBadge>
                    <ActionButtons>
                      <EditButton onClick={() => handleEdit(schedule)}>
                        <FaEdit />
                      </EditButton>
                      <DeleteButton onClick={() => handleDelete(schedule._id)}>
                        <FaTrash />
                      </DeleteButton>
                    </ActionButtons>
                  </CardHeader>

                  <CardBody>
                    <InfoRow>
                      <InfoIcon>
                        <FaRoute />
                      </InfoIcon>
                      <InfoText>
                        {schedule.routeID?.start?.name} →{" "}
                        {schedule.routeID?.end?.name}
                      </InfoText>
                    </InfoRow>

                    <InfoRow>
                      <InfoIcon>
                        <FaClock />
                      </InfoIcon>
                      <InfoText>
                        {formatTime(schedule.startTime)}
                        {schedule.endTime
                          ? ` - ${formatTime(schedule.endTime)}`
                          : " (Run Pending)"}
                      </InfoText>
                    </InfoRow>

                    <DateInfo>{formatDate(schedule.date)}</DateInfo>

                    {/* NEW: Status Badge */}
                    <StatusSection>{getStatusBadge(schedule)}</StatusSection>
                  </CardBody>
                </ScheduleCard>
              ))}
            </SchedulesGrid>
          )}
        </SchedulesSection>
      </MainContent>
    </PageContainer>
  );
};

// Styled Components
const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
`;

const Header = styled.header`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const BackButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const MainContent = styled.main`
  max-width: 1400px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const PageHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.xl};
`;

const PageTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const DateDisplay = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const FormSection = styled.div`
  margin-bottom: ${theme.spacing.xl};
  display: ${(props) => (props.show ? "block" : "none")};
`;

const FormCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const FormHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.lg};
`;

const FormTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0;
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.textSecondary};
  font-size: 24px;
  cursor: pointer;
  transition: color ${theme.transitions.fast};

  &:hover {
    color: ${theme.colors.textPrimary};
  }
`;

const FormGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.lg};
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.sm};
`;

const Select = styled.select`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};
  background: ${theme.colors.white};
  cursor: pointer;

  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }
`;

const Input = styled.input`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};

  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: ${theme.spacing.md};
  justify-content: flex-end;
`;

const SubmitButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const CancelButton = styled.button`
  background: ${theme.colors.background};
  color: ${theme.colors.textPrimary};
  border: 1px solid ${theme.colors.border};
  padding: ${theme.spacing.sm} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    background: ${theme.colors.backgroundDark};
  }
`;

const AddButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.xl};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const SchedulesSection = styled.div``;

const SectionTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
`;

const LoadingText = styled.p`
  color: ${theme.colors.textSecondary};
  text-align: center;
  padding: ${theme.spacing.xl};
`;

const EmptyState = styled.div`
  text-align: center;
  padding: ${theme.spacing.xl};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
`;

const EmptyText = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
`;

const SchedulesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: ${theme.spacing.lg};
`;

const ScheduleCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.lg};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px ${theme.colors.shadowMedium};
  }
`;

const CardHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.md};
  padding-bottom: ${theme.spacing.md};
  border-bottom: 1px solid ${theme.colors.border};
`;

const TruckBadge = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  color: ${theme.colors.primary};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const ActionButtons = styled.div`
  display: flex;
  gap: ${theme.spacing.sm};
`;

const EditButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.primary};
  cursor: pointer;
  font-size: 18px;
  padding: ${theme.spacing.xs};
  transition: color ${theme.transitions.fast};

  &:hover {
    color: ${theme.colors.primaryDark};
  }
`;

const DeleteButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.error};
  cursor: pointer;
  font-size: 18px;
  padding: ${theme.spacing.xs};
  transition: color ${theme.transitions.fast};

  &:hover {
    color: #d32f2f;
  }
`;

const CardBody = styled.div``;

const InfoRow = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.sm};
`;

const InfoIcon = styled.div`
  color: ${theme.colors.secondary};
  font-size: 16px;
`;

const InfoText = styled.span`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
`;

const DateInfo = styled.div`
  margin-top: ${theme.spacing.md};
  padding-top: ${theme.spacing.md};
  border-top: 1px solid ${theme.colors.border};
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  text-align: center;
`;

// NEW: Status Badge Styles
const StatusSection = styled.div`
  margin-top: ${theme.spacing.md};
  display: flex;
  justify-content: center;
`;

const StatusBadge = styled.div`
  display: inline-flex;
  align-items: center;
  gap: ${theme.spacing.xs};
  padding: ${theme.spacing.xs} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.lg};
  font-size: ${theme.typography.fontSize.xs};
  font-weight: ${theme.typography.fontWeight.semibold};

  ${(props) => {
    switch (props.$status) {
      case "completed":
        return `
          background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
          color: white;
        `;
      case "in_progress":
        return `
          background: linear-gradient(135deg, #ff9800 0%, #ffa726 100%);
          color: white;
        `;
      case "scheduled":
      default:
        return `
          background: linear-gradient(135deg, #2196f3 0%, #42a5f5 100%);
          color: white;
        `;
    }
  }}

  svg {
    font-size: ${theme.typography.fontSize.sm};
  }
`;

export default SetSchedules;
