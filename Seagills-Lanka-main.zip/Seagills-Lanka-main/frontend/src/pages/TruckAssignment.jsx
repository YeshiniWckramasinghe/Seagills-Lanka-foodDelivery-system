// src/pages/TruckAssignment.jsx
import React, { useState, useEffect } from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import { FaTruck, FaPlus, FaEdit, FaTrash, FaTimes } from "react-icons/fa";
import {
  assignedTruckAPI,
  truckAPI,
  driverAPI,
  userAPI,
} from "../services/api";
import Modal from "../Component/Modal";

const TruckAssignment = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [assignments, setAssignments] = useState([]);
  const [trucks, setTrucks] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [coordinators, setCoordinators] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [formData, setFormData] = useState({
    truckID: "",
    driverID: "",
    deliveryCoordinatorID: "",
    date: new Date().toISOString().split("T")[0],
  });

  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  useEffect(() => {
    document.body.style.paddingTop = "0";
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, []);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      await Promise.all([
        fetchAssignments(),
        fetchTrucks(),
        fetchDrivers(),
        fetchCoordinators(),
      ]);
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchAssignments = async () => {
    try {
      const response = await assignedTruckAPI.getAllAssignments();
      if (response.data.success) setAssignments(response.data.assignments);
    } catch (err) {
      console.error("Error fetching assignments:", err);
    }
  };

  const fetchTrucks = async () => {
    try {
      const response = await truckAPI.getAllTrucks();
      setTrucks(Array.isArray(response.data) ? response.data : []);
    } catch (err) {
      console.error("Error fetching trucks:", err);
    }
  };

  const fetchDrivers = async () => {
    try {
      const res = await driverAPI.getAllDrivers();
      console.log("Drivers response:", res.data);
      const driversData = Array.isArray(res.data)
        ? res.data
        : res.data.drivers || res.data.data || [];
      setDrivers(driversData);
    } catch (err) {
      console.error("Error fetching drivers:", err);
    }
  };

  const fetchCoordinators = async () => {
    try {
      const response = await userAPI.getAllDeliveryCoordinators();
      setCoordinators(response.data.coordinators || []);
    } catch (err) {
      console.error("Error fetching coordinators:", err);
    }
  };

  const handleInputChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.truckID ||
      !formData.driverID ||
      !formData.deliveryCoordinatorID
    ) {
      return setModal({
        isOpen: true,
        type: "error",
        title: "Missing Information",
        message: "Please fill in all fields",
      });
    }

    try {
      const payload = {
        truckID: formData.truckID,
        driverID: formData.driverID,
        deliveryCoordinatorID: formData.deliveryCoordinatorID,
        date: formData.date,
      };

      if (editingId) {
        const response = await assignedTruckAPI.updateAssignment(
          editingId,
          payload
        );
        if (response.data.success) {
          setModal({
            isOpen: true,
            type: "success",
            title: "Success",
            message: "Assignment updated successfully",
          });
        }
      } else {
        const response = await assignedTruckAPI.createAssignment(payload);
        if (response.data.success) {
          setModal({
            isOpen: true,
            type: "success",
            title: "Success",
            message: "Truck assigned successfully",
          });
        }
      }
      resetForm();
      fetchAssignments();
    } catch (err) {
      console.error("Error saving assignment:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Error",
        message: err.response?.data?.message || "Failed to save assignment",
      });
    }
  };

  const handleEdit = (assignment) => {
    if (!assignment) return;
    setFormData({
      truckID: assignment.truckID?._id || "",
      driverID: assignment.driverID?._id || "",
      deliveryCoordinatorID: assignment.deliveryCoordinatorID?._id || "",
      date: new Date(assignment.date).toISOString().split("T")[0],
    });
    setEditingId(assignment._id || null);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this assignment?"))
      return;
    try {
      const response = await assignedTruckAPI.deleteAssignment(id);
      if (response.data.success) {
        setModal({
          isOpen: true,
          type: "success",
          title: "Deleted",
          message: "Assignment deleted successfully",
        });
        fetchAssignments();
      }
    } catch (err) {
      console.error("Error deleting assignment:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Error",
        message: "Failed to delete assignment",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      truckID: "",
      driverID: "",
      deliveryCoordinatorID: "",
      date: new Date().toISOString().split("T")[0],
    });
    setEditingId(null);
    setShowForm(false);
  };

  const formatDate = (dateString) =>
    new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "numeric",
      day: "numeric",
    });

  return (
    <PageContainer>
      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      <Header>
        <LogoSection onClick={() => navigate("/admin-dashboard")}>
          <Logo>
            <FaTruck />
          </Logo>
          <BrandInfo>
            <BrandName>Seagills Lanka</BrandName>
            <BrandTagline>Delivery Management</BrandTagline>
          </BrandInfo>
        </LogoSection>

        <UserSection>
          <UserInfo>
            <UserName>
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </UserName>
            <UserRole>Admin</UserRole>
          </UserInfo>
          <SignOutButton onClick={() => navigate("/admin-dashboard")}>
            Back
          </SignOutButton>
        </UserSection>
      </Header>

      <MainContent>
        <PageHeader>
          <PageTitle>Truck Assignment</PageTitle>
          <DateDisplay>
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </DateDisplay>
        </PageHeader>

        <FormSection show={showForm}>
          <FormCard>
            <FormHeader>
              <FormTitle>
                <FaPlus /> {editingId ? "Edit" : "New"} Truck Assignment
              </FormTitle>
              {showForm && (
                <CloseButton onClick={resetForm}>
                  <FaTimes />
                </CloseButton>
              )}
            </FormHeader>

            <form onSubmit={handleSubmit}>
              <FormGrid>
                <FormGroup>
                  <Label>Select Truck</Label>
                  <Select
                    name="truckID"
                    value={formData.truckID}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Choose truck...</option>
                    {trucks.map((truck) => (
                      <option key={truck._id} value={truck._id}>
                        {truck.plateNo || "Unnamed Truck"}
                        {truck.colour ? ` - ${truck.colour}` : ""}
                      </option>
                    ))}
                  </Select>
                </FormGroup>

                <FormGroup>
                  <Label>Delivery Coordinator</Label>
                  <Select
                    name="deliveryCoordinatorID"
                    value={formData.deliveryCoordinatorID}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Choose coordinator...</option>
                    {coordinators.map((coord) => (
                      <option key={coord._id} value={coord._id}>
                        {coord.firstName} {coord.lastName} ({coord.username})
                      </option>
                    ))}
                  </Select>
                </FormGroup>

                <FormGroup>
                  <Label>Driver</Label>
                  <Select
                    name="driverID"
                    value={formData.driverID}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Choose driver...</option>
                    {drivers.map((driver) => (
                      <option key={driver._id} value={driver._id}>
                        {driver.firstName} {driver.lastName} ({driver.telephone}
                        )
                      </option>
                    ))}
                  </Select>
                </FormGroup>

                <FormGroup>
                  <Label>Date</Label>
                  <Input
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    required
                  />
                </FormGroup>
              </FormGrid>

              <ButtonGroup>
                <SubmitButton type="submit">
                  {editingId ? "Update Assignment" : "Assign Truck"}
                </SubmitButton>
                <CancelButton type="button" onClick={resetForm}>
                  Cancel
                </CancelButton>
              </ButtonGroup>
            </form>
          </FormCard>
        </FormSection>

        {!showForm && (
          <AddButton onClick={() => setShowForm(true)}>
            <FaPlus /> New Truck Assignment
          </AddButton>
        )}

        <AssignmentsSection>
          <SectionTitle>All Truck Assignments</SectionTitle>
          {loading ? (
            <LoadingText>Loading assignments...</LoadingText>
          ) : assignments.length === 0 ? (
            <EmptyState>
              <EmptyText>No assignments found. Create one above!</EmptyText>
            </EmptyState>
          ) : (
            <AssignmentsTable>
              <TableHeader>
                <HeaderCell>Truck</HeaderCell>
                <HeaderCell>Delivery Coordinator</HeaderCell>
                <HeaderCell>Driver</HeaderCell>
                <HeaderCell>Date</HeaderCell>
                <HeaderCell>Status</HeaderCell>
                <HeaderCell>Actions</HeaderCell>
              </TableHeader>
              <TableBody>
                {assignments.map((assignment) => (
                  <TableRow key={assignment._id}>
                    <TableCell>
                      {assignment.truckID?.plateNo || "N/A"}
                    </TableCell>
                    <TableCell>
                      {assignment.deliveryCoordinatorID?.firstName}{" "}
                      {assignment.deliveryCoordinatorID?.lastName}
                    </TableCell>
                    <TableCell>
                      {assignment.driverID
                        ? `${assignment.driverID.firstName} ${assignment.driverID.lastName}`
                        : "N/A"}
                    </TableCell>
                    <TableCell>{formatDate(assignment.date)}</TableCell>
                    <TableCell>
                      <StatusBadge
                        active={new Date(assignment.date) >= new Date()}
                      >
                        {new Date(assignment.date) >= new Date()
                          ? "active"
                          : "completed"}
                      </StatusBadge>
                    </TableCell>
                    <TableCell>
                      <ActionButtons>
                        <EditButton onClick={() => handleEdit(assignment)}>
                          <FaEdit />
                        </EditButton>
                        <DeleteButton
                          onClick={() => handleDelete(assignment._id)}
                        >
                          <FaTrash />
                        </DeleteButton>
                      </ActionButtons>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </AssignmentsTable>
          )}
        </AssignmentsSection>
      </MainContent>
    </PageContainer>
  );
};

//
// --------------- Styled Components (unchanged) ---------------
//

// Styled Components
const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
`;

const Header = styled.header`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const SignOutButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const MainContent = styled.main`
  max-width: 1400px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const PageHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.xl};
`;

const PageTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const DateDisplay = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const FormSection = styled.div`
  margin-bottom: ${theme.spacing.xl};
  display: ${(props) => (props.show ? "block" : "none")};
`;

const FormCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const FormHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.lg};
`;

const FormTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0;
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.textSecondary};
  font-size: 24px;
  cursor: pointer;
  transition: color ${theme.transitions.fast};

  &:hover {
    color: ${theme.colors.textPrimary};
  }
`;

const FormGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.lg};
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.sm};
`;

const Select = styled.select`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};
  background: ${theme.colors.white};
  cursor: pointer;

  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }
`;

const Input = styled.input`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};

  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: ${theme.spacing.md};
  justify-content: flex-end;
`;

const SubmitButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const CancelButton = styled.button`
  background: ${theme.colors.background};
  color: ${theme.colors.textPrimary};
  border: 1px solid ${theme.colors.border};
  padding: ${theme.spacing.sm} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    background: ${theme.colors.backgroundDark};
  }
`;

const AddButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.xl};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const AssignmentsSection = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const SectionTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
`;

const LoadingText = styled.p`
  color: ${theme.colors.textSecondary};
  text-align: center;
  padding: ${theme.spacing.xl};
`;

const EmptyState = styled.div`
  text-align: center;
  padding: ${theme.spacing.xl};
`;

const EmptyText = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
`;

const AssignmentsTable = styled.table`
  width: 100%;
  border-collapse: collapse;
`;

const TableHeader = styled.thead`
  background: ${theme.colors.background};
`;

const HeaderCell = styled.th`
  padding: ${theme.spacing.md};
  text-align: left;
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
  text-transform: uppercase;
`;

const TableBody = styled.tbody``;

const TableRow = styled.tr`
  border-bottom: 1px solid ${theme.colors.border};
  transition: background ${theme.transitions.fast};

  &:hover {
    background: ${theme.colors.background};
  }
`;

const TableCell = styled.td`
  padding: ${theme.spacing.md};
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
`;

const StatusBadge = styled.span`
  padding: ${theme.spacing.xs} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.full};
  font-size: ${theme.typography.fontSize.xs};
  font-weight: ${theme.typography.fontWeight.semibold};
  text-transform: lowercase;
  background: ${(props) => (props.active ? "#4CAF50" : "#9E9E9E")};
  color: white;
`;

const ActionButtons = styled.div`
  display: flex;
  gap: ${theme.spacing.sm};
`;

const EditButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.primary};
  cursor: pointer;
  font-size: 18px;
  padding: ${theme.spacing.xs};
  transition: color ${theme.transitions.fast};

  &:hover {
    color: ${theme.colors.primaryDark};
  }
`;

const DeleteButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.error};
  cursor: pointer;
  font-size: 18px;
  padding: ${theme.spacing.xs};
  transition: color ${theme.transitions.fast};

  &:hover {
    color: #d32f2f;
  }
`;

export default TruckAssignment;
