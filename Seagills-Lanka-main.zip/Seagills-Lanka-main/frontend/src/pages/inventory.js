// src/pages/Inventory.jsx

import React from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import { BsFillPeopleFill } from "react-icons/bs";
import { GiCardboardBoxClosed } from "react-icons/gi";
import { HiChartSquareBar } from "react-icons/hi";
import { FaTruck } from "react-icons/fa";

const Inventory = () => {
  const navigate = useNavigate();

  const cardData = [
    {
      title: "Manage Inventory",
      description: "Manage Inventory information and relationships",
      icon: <BsFillPeopleFill color="#CF3CE0" />,
      buttonText: "View Inventory",
      route: "/admin/inventory/inventorypage",
    },
    {
      title: "Manage Supplier",
      description: "Manage supplier information and relationships",
      icon: <BsFillPeopleFill color="#CF3CE0" />,
      buttonText: "View Suppliers",
      route: "/admin/inventory/supplier",
    },
    {
      title: "Manage Product Stock",
      description: "Track and update product stock levels",
      icon: <HiChartSquareBar color="#02ACFA" />,
      buttonText: "View Stock",
      route: "/admin/inventory/stock",
    },
  ];

  const handleCardClick = (route) => {
    navigate(route);
  };

  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <PageContainer>
      <Header>
        <LogoSection onClick={() => navigate("/admin-dashboard")}>
          <Logo>
            <FaTruck color={theme.colors.primary} />
          </Logo>
          <BrandInfo>
            <BrandName>Seagills Lanka</BrandName>
            <BrandTagline>Inventory Management</BrandTagline>
          </BrandInfo>
        </LogoSection>

        <UserSection>
          <UserInfo>
            <UserName>
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </UserName>
            <UserRole>Admin</UserRole>
          </UserInfo>
          <DateText>{today}</DateText>
          <BackButton onClick={() => navigate("/admin-dashboard")}>Back</BackButton>
        </UserSection>
      </Header>

      <MainContent>
        <PageHeader>
          <PageTitle>Inventory Dashboard</PageTitle>
        </PageHeader>

        <Grid>
          {cardData.map((card, index) => (
            <Card key={index}>
              <IconWrapper>{card.icon}</IconWrapper>
              <CardTitle>{card.title}</CardTitle>
              <CardDesc>{card.description}</CardDesc>
              <CardButton onClick={() => handleCardClick(card.route)}>
                {card.buttonText}
              </CardButton>
            </Card>
          ))}
        </Grid>
      </MainContent>
    </PageContainer>
  );
};

// Styled Components
const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
  padding-top: 100px; /* header height */
`;

const Header = styled.header`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  z-index: 1000;
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const DateText = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
`;

const BackButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const MainContent = styled.main`
  max-width: 1400px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const PageHeader = styled.div`
  display: flex;
  justify-content: center;
  margin-bottom: ${theme.spacing.xl};
`;

const PageTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${theme.spacing.xl};
`;

const Card = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.lg};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  text-align: center;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px ${theme.colors.shadowMedium};
  }
`;

const IconWrapper = styled.div`
  font-size: 48px;
  display: flex;
  justify-content: center;  
  align-items: center;
  margin-bottom: ${theme.spacing.md};
`;

const CardTitle = styled.h3`
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin-bottom: ${theme.spacing.sm};
`;

const CardDesc = styled.p`
  font-size: ${theme.typography.fontSize.sm};
  color: ${theme.colors.textSecondary};
  margin-bottom: ${theme.spacing.md};
`;

const CardButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  cursor: pointer;
  font-weight: ${theme.typography.fontWeight.semibold};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

export default Inventory;
