// src/pages/VerifyOrders.jsx
import React, { useState, useEffect } from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import { assignedTruckAPI, preorderAPI } from "../services/api";
import {
  FaTruck,
  FaArrowLeft,
  FaCheckCircle,
  FaTimesCircle,
  FaBoxOpen,
  FaUser,
  FaMapMarkerAlt,
  FaPhone,
} from "react-icons/fa";
import Modal from "../Component/Modal";
import VerifyOrderCard from "../Component/orders/VerifyOrderCard";

const VerifyOrders = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [preorders, setPreorders] = useState([]);
  const [selectedPreorder, setSelectedPreorder] = useState(null);
  const [verificationNotes, setVerificationNotes] = useState("");
  const [todayAssignment, setTodayAssignment] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [isVerificationCompleted, setIsVerificationCompleted] = useState(false);
  const [verifiedOrders, setVerifiedOrders] = useState([]);

  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  // Remove body padding from NavBar
  useEffect(() => {
    document.body.style.paddingTop = "0";
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, []);

  useEffect(() => {
    fetchTodayAssignment();
  }, []);

  const fetchTodayAssignment = async () => {
    try {
      const userStr = localStorage.getItem("user");
      if (!userStr) {
        navigate("/login");
        return;
      }

      const user = JSON.parse(userStr);
      const today = new Date().toISOString().split("T")[0];

      const response = await assignedTruckAPI.getAssignmentsByDate(today);

      if (response.data.success && response.data.assignments.length > 0) {
        const myAssignment = response.data.assignments.find(
          (a) => a.deliveryCoordinatorID._id === user.id
        );

        if (myAssignment) {
          setTodayAssignment(myAssignment);
          await fetchPreorders(myAssignment.truckID._id, today);
        } else {
          setModal({
            isOpen: true,
            type: "error",
            title: "No Assignment",
            message: "No truck has been assigned to you for today",
          });
          setLoading(false);
        }
      } else {
        setModal({
          isOpen: true,
          type: "error",
          title: "No Assignments",
          message: "No truck assignments found for today",
        });
        setLoading(false);
      }
    } catch (err) {
      console.error("Error fetching assignment:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Error",
        message: err.response?.data?.message || "Failed to load assignment",
      });
      setLoading(false);
    }
  };

  const fetchPreorders = async (truckId, date) => {
    try {
      setLoading(true); // Using fetch since we need to add this to api.js
      const token = localStorage.getItem("token");
      const response = await fetch(
        `${
          process.env.REACT_APP_API_URL || "http://localhost:5000/api"
        }/preorders/truck/${truckId}?date=${date}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      // ✨ REQUIRED CHANGE 1: Check for response success
      if (!response.ok) {
        // Attempt to parse JSON error body if available, otherwise use status text
        const errorData = await response.json().catch(() => ({}));
        throw new Error(
          errorData.message || response.statusText || "Failed to fetch orders"
        );
      }

      // ✨ REQUIRED CHANGE 2: Parse the response body into a JavaScript object
      const data = await response.json();

      if (data) {
        // Map preorderProducts to products to match component expectations
        // ✨ REQUIRED CHANGE 3: Use 'data' instead of 'response.data'
        const normalizedPreorders = (data.preorders || []).map((preorder) => ({
          ...preorder,
          products: (preorder.preorderProducts || preorder.products || []).map(
            (product) => ({
              ...product, // Ensure productID object structure for compatibility
              productID: {
                _id: product.productID,
                productName: product.productName,
                unit: product.unit,
              },
              quantity: product.quantity,
              unit: product.unit,
            })
          ),
        }));
        setPreorders(normalizedPreorders);
      } else {
        setModal({
          isOpen: true,
          type: "error",
          title: "Error Loading Orders", // 'data' is now defined and can be used here
          message: data.message || "Failed to load preorders",
        });
      }
    } catch (err) {
      console.error("Error fetching preorders:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Error", // Pass the error message from the thrown error
        message: err.message || "Failed to load preorders for this truck",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleToggleVerify = (orderId, orderStatus) => {
    // Don't allow toggling if already verified
    if (orderStatus === "verified") {
      return;
    }

    setVerifiedOrders((prev) =>
      prev.includes(orderId)
        ? prev.filter((id) => id !== orderId)
        : [...prev, orderId]
    );
  };

  const handleSelectAll = () => {
    // Only include orders that are not yet verified
    const unverifiedOrderIds = preorders
      .filter((p) => p.orderStatus !== "verified")
      .map((p) => p._id);

    if (verifiedOrders.length === unverifiedOrderIds.length) {
      setVerifiedOrders([]);
    } else {
      setVerifiedOrders(unverifiedOrderIds);
    }
  };

  const handleCompleteVerification = async () => {
    try {
      setSubmitting(true);
      const userStr = localStorage.getItem("user");
      const user = JSON.parse(userStr);

      for (const orderId of verifiedOrders) {
        await preorderAPI.verifyPreorder(orderId, {
          verificationStatus: "verified",
          verifiedBy: user.id,
        });
      }

      setPreorders((prev) =>
        prev.map((p) =>
          verifiedOrders.includes(p._id) ? { ...p, orderStatus: "verified" } : p
        )
      );

      setVerifiedOrders([]);
      setIsVerificationCompleted(true);

      setModal({
        isOpen: true,
        type: "success",
        title: "Success!",
        message: "All pre-orders have been verified successfully!",
      });

      setTimeout(() => {
        navigate("/coordinator-dashboard");
      }, 1500);
    } catch (err) {
      console.error("Error verifying order:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Error",
        message: "An error occurred while verifying the order",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "verified":
      case "loaded":
        return theme.colors.success;
      case "pending":
        return theme.colors.warning;
      case "cancelled":
      case "failed":
        return theme.colors.error;
      default:
        return theme.colors.textSecondary;
    }
  };

  if (loading) {
    return (
      <PageContainer>
        <LoadingContainer>
          <LoadingSpinner />
          <LoadingText>Loading orders...</LoadingText>
        </LoadingContainer>
      </PageContainer>
    );
  }

  const username = JSON.parse(localStorage.getItem("user") || "{}").username;

  // Count unverified orders
  const unverifiedCount = preorders.filter(
    (p) => p.orderStatus !== "verified"
  ).length;

  // Check if all unverified orders are selected
  const allUnverifiedSelected =
    unverifiedCount > 0 && verifiedOrders.length === unverifiedCount;

  return (
    <PageContainer>
      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      <Header>
        <LogoSection onClick={() => navigate("/coordinator-dashboard")}>
          <Logo>
            <FaTruck />
          </Logo>
          <BrandInfo>
            <BrandName>Seagills Lanka</BrandName>
            <BrandTagline>Delivery Management</BrandTagline>
          </BrandInfo>
        </LogoSection>

        <UserSection>
          <UserInfo>
            <UserName>
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </UserName>
            <UserRole>Coordinator</UserRole>
          </UserInfo>
          <BackButton onClick={() => navigate("/coordinator-dashboard")}>
            <FaArrowLeft /> Back
          </BackButton>
        </UserSection>
      </Header>

      <MainContent>
        <PageHeader>
          <div>
            <PageTitle>Verify Orders</PageTitle>
            <PageSubtitle>
              Verify and confirm pre-orders for loading
            </PageSubtitle>
          </div>
          <HeaderRight>
            {todayAssignment && (
              <TruckInfo>
                <FaTruck />
                <span>Truck: {todayAssignment.truckID.plateNo}</span>
              </TruckInfo>
            )}
          </HeaderRight>
        </PageHeader>

        {preorders.length === 0 ? (
          <EmptyState>
            <EmptyIcon>
              <FaBoxOpen />
            </EmptyIcon>
            <EmptyTitle>No Pre-orders Found</EmptyTitle>
            <EmptyText>
              There are no pre-orders assigned to this truck for today.
            </EmptyText>
          </EmptyState>
        ) : (
          <>
            <SelectAllSection>
              {unverifiedCount > 0 && (
                <SelectAllText onClick={handleSelectAll}>
                  Select All ({verifiedOrders.length}/{unverifiedCount})
                </SelectAllText>
              )}
            </SelectAllSection>

            <OrdersGrid>
              {preorders.map((preorder) => (
                <VerifyOrderCardWrapper key={preorder._id}>
                  <VerifyOrderCard
                    preorder={preorder}
                    isVerified={verifiedOrders.includes(preorder._id)}
                    onToggleVerify={() =>
                      handleToggleVerify(preorder._id, preorder.orderStatus)
                    }
                    isDisabled={preorder.orderStatus === "verified"}
                    hideCheckbox={
                      isVerificationCompleted ||
                      preorder.orderStatus === "verified"
                    }
                  />
                </VerifyOrderCardWrapper>
              ))}
            </OrdersGrid>

            <VerificationFooter>
              <CompleteVerificationButton
                onClick={handleCompleteVerification}
                disabled={!allUnverifiedSelected || submitting}
                $allVerified={allUnverifiedSelected && !submitting}
              >
                {submitting
                  ? "Verifying..."
                  : allUnverifiedSelected
                  ? "Complete Verification"
                  : "All pre-orders verified for today"}
              </CompleteVerificationButton>
            </VerificationFooter>
          </>
        )}
      </MainContent>
    </PageContainer>
  );
};

// Styled Components
const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
`;

const LoadingContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  gap: ${theme.spacing.lg};
`;

const LoadingSpinner = styled.div`
  width: 50px;
  height: 50px;
  border: 4px solid ${theme.colors.border};
  border-top: 4px solid ${theme.colors.primary};
  border-radius: 50%;
  animation: spin 1s linear infinite;

  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`;

const LoadingText = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.lg};
`;

const Header = styled.header`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const BackButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const MainContent = styled.main`
  max-width: 1400px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const PageHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.xl};

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: flex-start;
    gap: ${theme.spacing.md};
  }
`;

const HeaderRight = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};

  @media (max-width: 768px) {
    margin-top: ${theme.spacing.md};
  }
`;

const PageTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0 0 ${theme.spacing.xs};
`;

const PageSubtitle = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
  margin: 0;
`;

const TruckInfo = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  padding: ${theme.spacing.md} ${theme.spacing.lg};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  color: ${theme.colors.primary};
  font-weight: ${theme.typography.fontWeight.semibold};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const SelectAllSection = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-bottom: ${theme.spacing.lg};
`;

const SelectAllText = styled.span`
  color: ${theme.colors.primary};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  text-decoration: underline;
  font-size: ${theme.typography.fontSize.base};

  &:hover {
    color: ${theme.colors.primaryDark};
  }
`;

const EmptyState = styled.div`
  text-align: center;
  padding: ${theme.spacing.xxl} ${theme.spacing.xl};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const EmptyIcon = styled.div`
  font-size: 64px;
  color: ${theme.colors.textLight};
  margin-bottom: ${theme.spacing.lg};
`;

const EmptyTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.sm};
`;

const EmptyText = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
  margin: 0;
`;

const OrdersGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: ${theme.spacing.lg};
`;

const VerifyOrderCardWrapper = styled.div`
  position: relative;
`;

const VerificationFooter = styled.div`
  margin-top: ${theme.spacing.xl};
  padding-top: ${theme.spacing.lg};
  border-top: 1px solid ${theme.colors.border};
  display: flex;
  justify-content: center;
  width: 100%;
`;

const CompleteVerificationButton = styled.button`
  width: 100%;
  max-width: 400px;
  font-size: ${theme.typography.fontSize.lg};
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  background: ${(props) =>
    props.$allVerified
      ? `linear-gradient(135deg, ${theme.colors.success} 0%, #388E3C 100%)`
      : theme.colors.textLight};
  color: white;
  border: none;
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: ${(props) => (props.disabled ? "not-allowed" : "pointer")};
  transition: all ${theme.transitions.normal};
  opacity: ${(props) => (props.disabled ? 0.6 : 1)};

  &:hover {
    transform: ${(props) => (props.disabled ? "none" : "translateY(-2px)")};
    box-shadow: ${(props) =>
      props.disabled ? "none" : `0 4px 12px ${theme.colors.shadowMedium}}`};
  }
`;

const OrderHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.md};
  padding-bottom: ${theme.spacing.md};
  border-bottom: 1px solid ${theme.colors.border};
`;

const OrderId = styled.h4`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0;
`;

const StatusBadge = styled.span`
  padding: ${theme.spacing.xs} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.full};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
  text-transform: capitalize;
  background: ${(props) => {
    switch (props.status) {
      case "verified":
      case "loaded":
        return "#E8F5E9";
      case "pending":
        return "#FFF3E0";
      default:
        return "#F5F5F5";
    }
  }};
  color: ${(props) => {
    switch (props.status) {
      case "verified":
      case "loaded":
        return "#4CAF50";
      case "pending":
        return "#FF9800";
      default:
        return "#757575";
    }
  }};
`;

const CustomerInfo = styled.div`
  margin-bottom: ${theme.spacing.md};
`;

const InfoRow = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.sm};
`;

const InfoIcon = styled.div`
  color: ${theme.colors.primary};
  font-size: 16px;
`;

const InfoText = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const ProductsList = styled.div`
  margin-bottom: ${theme.spacing.md};
`;

const ProductsTitle = styled.h5`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.sm};
`;

const ProductItem = styled.div`
  display: flex;
  justify-content: space-between;
  padding: ${theme.spacing.sm};
  background: ${theme.colors.background};
  border-radius: ${theme.borderRadius.md};
  margin-bottom: ${theme.spacing.xs};
`;

const ProductName = styled.span`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
`;

const ProductQuantity = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const OrderTotal = styled.div`
  color: ${theme.colors.primary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.bold};
  margin-bottom: ${theme.spacing.md};
  text-align: right;
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: ${theme.spacing.sm};
`;

const VerifyButton = styled.button`
  flex: 1;
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${theme.spacing.sm};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const VerifiedBadge = styled.div`
  position: absolute;
  top: -12px;
  right: -12px;
  background: ${theme.colors.success};
  color: white;
  padding: ${theme.spacing.sm} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.sm};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.xs};
  box-shadow: 0 2px 8px ${theme.colors.shadowMedium};
`;

const VerificationOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  backdrop-filter: blur(4px);
`;

const VerificationModal = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  width: 90%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  animation: slideUp 0.3s ease-out;

  @keyframes slideUp {
    from {
      transform: translateY(50px);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }
`;

const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${theme.spacing.lg};
  border-bottom: 1px solid ${theme.colors.border};
`;

const ModalTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.textSecondary};
  font-size: 24px;
  cursor: pointer;
  transition: color ${theme.transitions.fast};

  &:hover {
    color: ${theme.colors.textPrimary};
  }
`;

const ModalBody = styled.div`
  padding: ${theme.spacing.lg};
`;

const OrderSummary = styled.div`
  background: ${theme.colors.background};
  padding: ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  margin-bottom: ${theme.spacing.lg};
`;

const SummaryRow = styled.div`
  display: flex;
  justify-content: space-between;
  padding: ${theme.spacing.sm} 0;
  border-bottom: 1px solid ${theme.colors.border};

  &:last-child {
    border-bottom: none;
  }
`;

const Label = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
`;

const Value = styled.span`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
`;

const NotesSection = styled.div`
  margin-bottom: ${theme.spacing.md};
`;

const TextArea = styled.textarea`
  width: 100%;
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  font-family: ${theme.typography.fontFamily};
  resize: vertical;
  transition: all ${theme.transitions.fast};

  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }
`;

const ModalFooter = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: ${theme.spacing.md};
  padding: ${theme.spacing.lg};
  border-top: 1px solid ${theme.colors.border};
`;

const CancelButton = styled.button`
  background: ${theme.colors.background};
  color: ${theme.colors.textPrimary};
  border: 1px solid ${theme.colors.border};
  padding: ${theme.spacing.sm} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    background: ${theme.colors.backgroundDark};
  }
`;

const ConfirmButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

export default VerifyOrders;
