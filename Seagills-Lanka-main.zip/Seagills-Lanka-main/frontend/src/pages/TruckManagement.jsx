// src/pages/TruckManagement.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";
import theme from "../styles/theme";
import { FaTruck, FaPlus, FaEdit, FaTrash, FaTimes } from "react-icons/fa";
import { truckAPI, branchAPI } from "../services/api";
import Modal from "../Component/Modal";

const TruckManagement = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [trucks, setTrucks] = useState([]);
  const [branches, setBranches] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [formData, setFormData] = useState({
    truckNumber: "",
    plateNo: "",
    colour: "",
    branchID: "",
    status: "idle",
  });

  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  useEffect(() => {
    fetchBranches();
    fetchTrucks();
  }, []);

  const fetchTrucks = async () => {
    try {
      setLoading(true);
      const res = await truckAPI.getAllTrucks();
      setTrucks(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("Error fetching trucks:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchBranches = async () => {
    try {
      const res = await branchAPI.getAllBranches();
      setBranches(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("Error fetching branches:", err);
    }
  };

  const handleInputChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const validateAlphanumeric = (value) => /^[A-Za-z0-9\- ]+$/.test(value) && /[A-Za-z]/.test(value) && /\d/.test(value);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const newErrors = {};
    if (!validateAlphanumeric(formData.truckNumber))
      newErrors.truckNumber = "Truck number must contain letters and numbers.";
    if (!validateAlphanumeric(formData.plateNo))
      newErrors.plateNo = "Plate number must contain letters and numbers.";
    if (!formData.branchID) newErrors.branchID = "Select a branch.";

    if (Object.keys(newErrors).length > 0) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Validation Error",
        message: Object.values(newErrors).join(" "),
      });
      return;
    }

    try {
      if (editingId) {
        await truckAPI.updateTruck(editingId, formData);
        setModal({ isOpen: true, type: "success", title: "Updated", message: "Truck updated successfully" });
      } else {
        await truckAPI.createTruck(formData);
        setModal({ isOpen: true, type: "success", title: "Added", message: "Truck added successfully" });
      }
      resetForm();
      fetchTrucks();
    } catch (err) {
      console.error(err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Error",
        message: err.response?.data?.message || "Failed to save truck",
      });
    }
  };

  const handleEdit = (truck) => {
    setFormData({
      truckNumber: truck.truckNumber || "",
      plateNo: truck.plateNo || "",
      colour: truck.colour || "",
      branchID: truck.branchID?._id || "",
      status: truck.status || "idle",
    });
    setEditingId(truck._id || null);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this truck?")) return;
    try {
      await truckAPI.deleteTruck(id);
      setModal({ isOpen: true, type: "success", title: "Deleted", message: "Truck deleted successfully" });
      fetchTrucks();
    } catch (err) {
      console.error(err);
      setModal({ isOpen: true, type: "error", title: "Error", message: "Failed to delete truck" });
    }
  };

  const resetForm = () => {
    setFormData({ truckNumber: "", plateNo: "", colour: "", branchID: "", status: "idle" });
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <PageContainer>
      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      <Header>
        <LogoSection onClick={() => navigate("/admin-dashboard")}>
          <Logo><FaTruck /></Logo>
          <BrandInfo>
            <BrandName>Seagills Lanka</BrandName>
            <BrandTagline>Truck Management</BrandTagline>
          </BrandInfo>
        </LogoSection>

        <UserSection>
          <UserInfo>
            <UserName>{JSON.parse(localStorage.getItem("user") || "{}").username}</UserName>
            <UserRole>Admin</UserRole>
          </UserInfo>
          <SignOutButton onClick={() => navigate("/admin-dashboard")}>Back</SignOutButton>
        </UserSection>
      </Header>

      <ContentWrapper>
        <MainContent>
          <PageHeader>
            <PageTitle>All Trucks</PageTitle>
            <DateDisplay>
              {new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
            </DateDisplay>
          </PageHeader>

          <FormSection show={showForm}>
            <FormCard>
              <FormHeader>
                <FormTitle>
                  <FaPlus /> {editingId ? "Edit Truck" : "New Truck"}
                </FormTitle>
                <CloseButton onClick={resetForm}><FaTimes /></CloseButton>
              </FormHeader>

              <form onSubmit={handleSubmit}>
                <FormGrid>
                  <FormGroup>
                    <Label>Truck Number</Label>
                    <Input name="truckNumber" value={formData.truckNumber} onChange={handleInputChange} required />
                  </FormGroup>

                  <FormGroup>
                    <Label>Plate Number</Label>
                    <Input name="plateNo" value={formData.plateNo} onChange={handleInputChange} required />
                  </FormGroup>

                  <FormGroup>
                    <Label>Colour</Label>
                    <Input name="colour" value={formData.colour} onChange={handleInputChange} />
                  </FormGroup>

                  <FormGroup>
                    <Label>Branch</Label>
                    <select name="branchID" value={formData.branchID} onChange={handleInputChange} required>
                      <option value="">Select Branch</option>
                      {branches.map((b) => (
                        <option key={b._id} value={b._id}>{b.branchName}</option>
                      ))}
                    </select>
                  </FormGroup>
                </FormGrid>

                <ButtonGroup>
                  <SubmitButton type="submit">{editingId ? "Update Truck" : "Add Truck"}</SubmitButton>
                  <CancelButton type="button" onClick={resetForm}>Cancel</CancelButton>
                </ButtonGroup>
              </form>
            </FormCard>
          </FormSection>

          {!showForm && (
            <AddButton onClick={() => setShowForm(true)}><FaPlus /> New Truck</AddButton>
          )}

          <TrucksSection>
            {loading ? (
              <LoadingText>Loading trucks...</LoadingText>
            ) : trucks.length === 0 ? (
              <EmptyState>No trucks found.</EmptyState>
            ) : (
              <TrucksTable>
                <thead>
                  <tr>
                    <TableHeaderCell>Truck No</TableHeaderCell>
                    <TableHeaderCell>Plate</TableHeaderCell>
                    <TableHeaderCell>Colour</TableHeaderCell>
                    <TableHeaderCell>Branch</TableHeaderCell>
                    <TableHeaderCell>Status</TableHeaderCell>
                    <TableHeaderCell>Actions</TableHeaderCell>
                  </tr>
                </thead>
                <tbody>
                  {trucks.map((truck) => (
                    <tr key={truck._id}>
                      <TableCell>{truck.truckNumber}</TableCell>
                      <TableCell>{truck.plateNo}</TableCell>
                      <TableCell>{truck.colour}</TableCell>
                      <TableCell>{truck.branchID?.branchName || "-"}</TableCell>
                     <TableCell>
  <StatusBadge active={truck.status === "active"}>
    {truck.status.toLowerCase()}
  </StatusBadge>
</TableCell>

                      <TableCell>
                        <ActionButtons>
                          <EditButton onClick={() => handleEdit(truck)}><FaEdit /></EditButton>
                          <DeleteButton onClick={() => handleDelete(truck._id)}><FaTrash /></DeleteButton>
                        </ActionButtons>
                      </TableCell>
                    </tr>
                  ))}
                </tbody>
              </TrucksTable>
            )}
          </TrucksSection>
        </MainContent>
      </ContentWrapper>
    </PageContainer>
  );
};
//
// --------------- Styled Components (unchanged) ---------------
//



// Styled Components
const HEADER_HEIGHT = 20;

const StatusBadge = styled.span`
  padding: ${theme.spacing.xs} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.full};
  font-size: ${theme.typography.fontSize.xs};
  font-weight: ${theme.typography.fontWeight.semibold};
  text-transform: lowercase;
  background: ${(props) => (props.active ? "#4CAF50" : "#9E9E9E")};
  color: white;
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const SignOutButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const LoadingText = styled.p`
  color: ${theme.colors.textSecondary};
  text-align: center;
  padding: ${theme.spacing.xl};
`;

const EmptyState = styled.div`
  text-align: center;
  padding: ${theme.spacing.xl};
`;

const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
`;

const Header = styled.header`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 100;
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const ContentWrapper = styled.div`
  padding-top: ${HEADER_HEIGHT}px;
`;

const MainContent = styled.main`
  max-width: 1400px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const TrucksSection = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const TrucksTable = styled.table`
  width: 100%;
  border-collapse: collapse;
`;

const TableHeaderCell = styled.th`
  padding: ${theme.spacing.md};
  text-align: left;
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
  text-transform: uppercase;
`;

const TableCell = styled.td`
  padding: ${theme.spacing.md};
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
`;

const ActionButtons = styled.div`
  display: flex;
  gap: ${theme.spacing.sm};
`;

const EditButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.primary};
  cursor: pointer;
  font-size: 18px;
  padding: ${theme.spacing.xs};
  transition: color ${theme.transitions.fast};
  &:hover {
    color: ${theme.colors.primaryDark};
  }
`;

const DeleteButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.error};
  cursor: pointer;
  font-size: 18px;
  padding: ${theme.spacing.xs};
  transition: color ${theme.transitions.fast};
  &:hover {
    color: #d32f2f;
  }
`;

const PageHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.xl};
`;

const PageTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const DateDisplay = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const FormSection = styled.div`
  margin-bottom: ${theme.spacing.xl};
  display: ${(props) => (props.show ? "block" : "none")};
`;

const FormCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const FormHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.lg};
`;

const FormTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0;
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.textSecondary};
  font-size: 24px;
  cursor: pointer;
  transition: color ${theme.transitions.fast};
  &:hover {
    color: ${theme.colors.textPrimary};
  }
`;

const FormGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.lg};
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.sm};
`;

const Input = styled.input`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};
  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: ${theme.spacing.md};
  justify-content: flex-end;
`;

const SubmitButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const CancelButton = styled.button`
  background: ${theme.colors.background};
  color: ${theme.colors.textPrimary};
  border: 1px solid ${theme.colors.border};
  padding: ${theme.spacing.sm} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  &:hover {
    background: ${theme.colors.backgroundDark};
  }
`;

const AddButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.xl};
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;
export default TruckManagement;
