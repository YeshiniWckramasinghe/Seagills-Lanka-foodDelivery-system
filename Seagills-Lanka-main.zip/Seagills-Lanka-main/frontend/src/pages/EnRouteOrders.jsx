// src/pages/EnRouteOrders.jsx
import React, { useState, useEffect, useCallback } from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import {
  FaTruck,
  FaArrowLeft,
  FaPlus,
  FaShoppingCart,
  FaMapMarkerAlt,
  FaPhone,
  FaDollarSign,
  FaTimes,
  FaCheck,
  FaChevronDown,
  FaChevronUp,
} from "react-icons/fa";
import {
  enrouteOrderAPI,
  productAPI,
  assignedTruckAPI,
  paymentAPI,
  truckRouteAPI,
} from "../services/api";
import Modal from "../Component/Modal";

const EnRouteOrders = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [todayAssignment, setTodayAssignment] = useState(null);
  const [expandedOrderId, setExpandedOrderId] = useState(null);
  const [confirmDialog, setConfirmDialog] = useState({
    isOpen: false,
    orderId: null,
  });
  const [runNotStartedModal, setRunNotStartedModal] = useState(false);

  const [formData, setFormData] = useState({
    customerLocation: "",
    contactNum: "",
    paymentMethod: "cash",
    truckCategory: "",
    products: [],
  });

  const [currentProduct, setCurrentProduct] = useState({
    productID: "",
    productName: "",
    quantity: "",
    unit: "pcs",
  });

  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  const units = ["kg", "g", "nos", "pcs", "bunch"];
  const paymentMethods = ["cash", "card"];

  // Remove body padding
  useEffect(() => {
    document.body.style.paddingTop = "0";
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, []);

  useEffect(() => {
    checkIfRunStarted();
  }, []);

  const checkIfRunStarted = async () => {
    try {
      const userStr = localStorage.getItem("user");
      if (!userStr) {
        navigate("/login");
        return;
      }

      const user = JSON.parse(userStr);
      const today = new Date().toISOString().split("T")[0];

      const response = await assignedTruckAPI.getCoordinatorDailySchedule(
        user.id,
        today
      );

      if (response.data.success && response.data.schedule) {
        const schedule = response.data.schedule;

        // Check if trip has been started
        if (!schedule.tripStartedAt) {
          setRunNotStartedModal(true);
        }
      }
    } catch (err) {
      console.error("Error checking run status:", err);
    }
  };

  useEffect(() => {
    fetchData();
    fetchTodayAssignment();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      await Promise.all([fetchProducts(), fetchOrders()]);
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchProducts = async () => {
    try {
      const response = await productAPI.getAllProducts();
      const productData = Array.isArray(response.data) ? response.data : [];
      setProducts(productData);
      setFilteredProducts(productData);
    } catch (err) {
      console.error("Error fetching products:", err);
    }
  };

  const fetchTodayAssignment = useCallback(async () => {
    try {
      const userStr = localStorage.getItem("user");
      if (!userStr) {
        navigate("/login");
        return;
      }

      const user = JSON.parse(userStr);
      const today = new Date().toISOString().split("T")[0];

      const response = await assignedTruckAPI.getAssignmentsByDate(today);

      if (response.data.success && response.data.assignments.length > 0) {
        const myAssignment = response.data.assignments.find(
          (a) => a.deliveryCoordinatorID._id === user.id
        );

        if (myAssignment) {
          setTodayAssignment(myAssignment);
          setFormData((prev) => ({
            ...prev,
            truckCategory: myAssignment.category || "",
          }));
        } else {
          setModal({
            isOpen: true,
            type: "error",
            title: "No Assignment Found",
            message: "No truck has been assigned to you for today",
          });
        }
      }
    } catch (err) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Failed to Load Assignment",
        message: err.response?.data?.message || err.message,
      });
    }
  }, [navigate]);

  // Filter products when category changes
  useEffect(() => {
    if (formData.truckCategory) {
      const filtered = products.filter((product) => {
        const productCategory = product.category
          ? product.category.replace(/\s+/g, "").toLowerCase().trim()
          : "";
        const selectedCategory = formData.truckCategory
          .replace(/\s+/g, "")
          .toLowerCase()
          .trim();
        return productCategory === selectedCategory;
      });
      setFilteredProducts(filtered);
    } else {
      setFilteredProducts(products);
    }
  }, [formData.truckCategory, products]);

  const fetchOrders = async () => {
    try {
      const userStr = localStorage.getItem("user");
      const user = JSON.parse(userStr);
      const today = new Date().toISOString().split("T")[0];

      const response = await enrouteOrderAPI.getOrdersByCoordinator(user.id, {
        date: today,
      });
      setOrders(response.data.orders || []);
    } catch (err) {
      console.log("No orders yet or error:", err.message);
      setOrders([]);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    // Prevent category from being changed by user input
    if (name === "truckCategory") return;

    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleProductChange = (e) => {
    const { name, value } = e.target;

    if (name === "productID") {
      const selectedProduct = filteredProducts.find((p) => p._id === value);
      setCurrentProduct({
        ...currentProduct,
        productID: value,
        productName: selectedProduct ? selectedProduct.productName : "",
        unit: selectedProduct ? selectedProduct.unit : "pcs",
      });
    } else {
      setCurrentProduct({
        ...currentProduct,
        [name]: value,
      });
    }
  };

  const addProduct = () => {
    if (!currentProduct.productID || !currentProduct.quantity) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Missing Information",
        message: "Please select a product and enter quantity",
      });
      return;
    }

    const product = products.find((p) => p._id === currentProduct.productID);

    setFormData((prev) => ({
      ...prev,
      products: [
        ...prev.products,
        {
          productID: currentProduct.productID,
          productName: currentProduct.productName,
          quantity: parseFloat(currentProduct.quantity),
          unit: currentProduct.unit,
          unitPrice: product.price,
        },
      ],
    }));

    setCurrentProduct({
      productID: "",
      productName: "",
      quantity: "",
      unit: "pcs",
    });
  };

  const removeProduct = (index) => {
    setFormData((prev) => ({
      ...prev,
      products: prev.products.filter((_, i) => i !== index),
    }));
  };

  const calculateTotal = () => {
    return formData.products.reduce((sum, item) => {
      return sum + item.unitPrice * item.quantity;
    }, 0);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.customerLocation || !formData.contactNum) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Missing Information",
        message: "Please fill in customer location and contact number",
      });
      return;
    }

    const phoneRegex = /^0\d{9}$/;
    if (!phoneRegex.test(formData.contactNum.trim())) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Invalid Contact Number",
        message:
          "Contact number must be 10 digits starting with 0 (e.g., 0771234567)",
      });
      return;
    }

    if (formData.products.length === 0) {
      setModal({
        isOpen: true,
        type: "error",
        title: "No Products",
        message: "Please add at least one product to the order",
      });
      return;
    }

    try {
      setLoading(true);
      const userStr = localStorage.getItem("user");
      const user = JSON.parse(userStr);

      const orderData = {
        customerLocation: formData.customerLocation,
        contactNum: formData.contactNum,
        deliveryCoordinatorID: user.id,
        paymentMethod: formData.paymentMethod,
        products: formData.products.map((p) => ({
          productID: p.productID,
          quantity: p.quantity,
          unit: p.unit,
          unitPrice: p.unitPrice,
        })),
      };

      const response = await enrouteOrderAPI.createOrder(orderData);

      if (response.data) {
        setModal({
          isOpen: true,
          type: "success",
          title: "Order Created",
          message: "En-route order created successfully!",
        });
        resetForm();
        fetchOrders();
      }
    } catch (err) {
      console.error("Error creating order:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Error",
        message: err.response?.data?.message || "Failed to create order",
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      customerLocation: "",
      contactNum: "",
      paymentMethod: "cash",
      products: [],
    });
    setShowForm(false);
  };

  const handleMarkDelivered = (orderId) => {
    setConfirmDialog({
      isOpen: true,
      orderId: orderId,
    });
  };

  const confirmMarkDelivered = async () => {
    try {
      const userStr = localStorage.getItem("user");
      const user = JSON.parse(userStr);

      console.log("📋 Sending payment update with:");
      console.log("   Order ID:", confirmDialog.orderId);
      console.log("   Payment Status:", "delivered");
      console.log("   Coordinator ID:", user.id);

      await paymentAPI.updatePayment(confirmDialog.orderId, {
        paymentStatus: "Completed",
        coordinatorID: user.id,
      });

      setModal({
        isOpen: true,
        type: "success",
        title: "Order Delivered",
        message: "Order marked as delivered successfully!",
      });

      setConfirmDialog({ isOpen: false, orderId: null });
      fetchOrders();
    } catch (err) {
      console.error("❌ Full error response:", err.response?.data);
      setModal({
        isOpen: true,
        type: "error",
        title: "Error",
        message:
          err.response?.data?.message || "Failed to mark order as delivered",
      });
    }
  };

  const toggleProductsExpand = (orderId) => {
    setExpandedOrderId(expandedOrderId === orderId ? null : orderId);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "delivered":
        return "#4CAF50";
      case "pending":
        return "#FF9800";
      case "failed":
        return "#F44336";
      default:
        return theme.colors.textSecondary;
    }
  };

  return (
    <PageContainer>
      <Modal
        isOpen={runNotStartedModal}
        onClose={() => {
          setRunNotStartedModal(false);
          navigate("/coordinator-dashboard");
        }}
        type="warning"
        title="Run Not Started"
        message="Please ensure the 'Start Daily Run' button was clicked on the dashboard before accessing en-route orders."
      />

      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      {/* Confirmation Dialog */}
      {confirmDialog.isOpen && (
        <ConfirmationDialogOverlay>
          <ConfirmationDialogContent>
            <DialogTitle>Confirm Delivery</DialogTitle>
            <DialogMessage>
              Are you sure you want to mark this order as delivered?
            </DialogMessage>
            <DialogButtonGroup>
              <DialogConfirmButton onClick={confirmMarkDelivered}>
                <FaCheck /> Yes, Mark Delivered
              </DialogConfirmButton>
              <DialogCancelButton
                onClick={() =>
                  setConfirmDialog({ isOpen: false, orderId: null })
                }
              >
                Cancel
              </DialogCancelButton>
            </DialogButtonGroup>
          </ConfirmationDialogContent>
        </ConfirmationDialogOverlay>
      )}

      <Header>
        <LogoSection onClick={() => navigate("/coordinator-dashboard")}>
          <Logo>
            <FaTruck />
          </Logo>
          <BrandInfo>
            <BrandName>Seagills Lanka</BrandName>
            <BrandTagline>Delivery Management</BrandTagline>
          </BrandInfo>
        </LogoSection>

        <UserSection>
          <UserInfo>
            <UserName>
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </UserName>
            <UserRole>Coordinator</UserRole>
          </UserInfo>
          <BackButton onClick={() => navigate("/coordinator-dashboard")}>
            <FaArrowLeft /> Back
          </BackButton>
        </UserSection>
      </Header>

      <MainContent>
        <PageHeader>
          <PageTitle>En Route Orders</PageTitle>
          <PageSubtitle>Create orders while on delivery</PageSubtitle>
        </PageHeader>

        {!showForm && (
          <AddButton onClick={() => setShowForm(true)}>
            <FaPlus /> New En-Route Order
          </AddButton>
        )}

        {showForm && (
          <FormCard>
            <FormHeader>
              <FormTitle>
                <FaShoppingCart /> Create En-Route Order
              </FormTitle>
              <CloseButton onClick={resetForm}>
                <FaTimes />
              </CloseButton>
            </FormHeader>

            <form onSubmit={handleSubmit}>
              <FormSection>
                <SectionTitle>Order Information</SectionTitle>
                <FormGroup>
                  <Label>Truck Category *</Label>
                  <ReadOnlySelect>
                    {formData.truckCategory
                      ? formData.truckCategory.charAt(0).toUpperCase() +
                        formData.truckCategory.slice(1)
                      : "Loading..."}
                  </ReadOnlySelect>
                </FormGroup>
              </FormSection>
              <Divider />

              <FormSection>
                <SectionTitle>Customer Information</SectionTitle>
                <FormGrid>
                  <FormGroup>
                    <Label>Customer Location *</Label>
                    <Input
                      type="text"
                      name="customerLocation"
                      value={formData.customerLocation}
                      onChange={handleInputChange}
                      placeholder="Enter delivery location..."
                      required
                    />
                  </FormGroup>

                  <FormGroup>
                    <Label>Contact Number *</Label>
                    <Input
                      type="tel"
                      name="contactNum"
                      value={formData.contactNum}
                      onChange={handleInputChange}
                      placeholder="Enter contact number..."
                      required
                    />
                  </FormGroup>

                  <FormGroup>
                    <Label>Payment Method *</Label>
                    <Select
                      name="paymentMethod"
                      value={formData.paymentMethod}
                      onChange={handleInputChange}
                      required
                    >
                      {paymentMethods.map((method) => (
                        <option key={method} value={method}>
                          {method.charAt(0).toUpperCase() + method.slice(1)}
                        </option>
                      ))}
                    </Select>
                  </FormGroup>
                </FormGrid>
              </FormSection>

              <Divider />

              <FormSection>
                <SectionTitle>Add Products</SectionTitle>
                <ProductGrid>
                  <FormGroup>
                    <Label>Product *</Label>
                    <Select
                      name="productID"
                      value={currentProduct.productID}
                      onChange={handleProductChange}
                    >
                      <option value="">Select product...</option>
                      {filteredProducts.map((product) => (
                        <option key={product._id} value={product._id}>
                          {product.productName} - LKR {product.price}
                        </option>
                      ))}
                    </Select>
                  </FormGroup>

                  <FormGroup>
                    <Label>Quantity *</Label>
                    <Input
                      type="number"
                      name="quantity"
                      value={currentProduct.quantity}
                      onChange={handleProductChange}
                      placeholder="Enter quantity..."
                      min="0"
                      step="0.01"
                    />
                  </FormGroup>

                  <FormGroup>
                    <Label>Unit *</Label>
                    <Select
                      name="unit"
                      value={currentProduct.unit}
                      onChange={handleProductChange}
                    >
                      {units.map((unit) => (
                        <option key={unit} value={unit}>
                          {unit}
                        </option>
                      ))}
                    </Select>
                  </FormGroup>
                </ProductGrid>

                <AddProductButton type="button" onClick={addProduct}>
                  <FaPlus /> Add Product
                </AddProductButton>

                {formData.products.length > 0 && (
                  <ProductsList>
                    <ProductsHeader>
                      Added Products ({formData.products.length})
                    </ProductsHeader>
                    {formData.products.map((item, index) => (
                      <ProductItem key={index}>
                        <ProductInfo>
                          <ProductName>{item.productName}</ProductName>
                          <ProductDetails>
                            {item.quantity} {item.unit} × LKR {item.unitPrice} =
                            LKR {(item.quantity * item.unitPrice).toFixed(2)}
                          </ProductDetails>
                        </ProductInfo>
                        <RemoveButton
                          type="button"
                          onClick={() => removeProduct(index)}
                        >
                          <FaTimes />
                        </RemoveButton>
                      </ProductItem>
                    ))}
                    <TotalRow>
                      <TotalLabel>Total Amount:</TotalLabel>
                      <TotalValue>LKR {calculateTotal().toFixed(2)}</TotalValue>
                    </TotalRow>
                  </ProductsList>
                )}
              </FormSection>

              <ButtonGroup>
                <SubmitButton type="submit" disabled={loading}>
                  {loading ? "Creating..." : "Create Order"}
                </SubmitButton>
                <CancelButton type="button" onClick={resetForm}>
                  Cancel
                </CancelButton>
              </ButtonGroup>
            </form>
          </FormCard>
        )}

        <OrdersSection>
          <SectionTitle>Today's En-Route Orders</SectionTitle>
          {orders.length === 0 ? (
            <EmptyState>
              <EmptyText>No en-route orders created today</EmptyText>
            </EmptyState>
          ) : (
            <OrdersGrid>
              {orders.map((order) => (
                <OrderCard key={order._id}>
                  <OrderHeader>
                    <OrderId>#{order._id.slice(-6).toUpperCase()}</OrderId>
                    <StatusBadge status={order.status}>
                      {order.status}
                    </StatusBadge>
                  </OrderHeader>

                  <OrderInfo>
                    <InfoRow>
                      <InfoIcon>
                        <FaMapMarkerAlt />
                      </InfoIcon>
                      <InfoText>{order.customerLocation}</InfoText>
                    </InfoRow>
                    <InfoRow>
                      <InfoIcon>
                        <FaPhone />
                      </InfoIcon>
                      <InfoText>{order.contactNum}</InfoText>
                    </InfoRow>
                    <InfoRow>
                      <InfoIcon>
                        <FaDollarSign />
                      </InfoIcon>
                      <InfoText>LKR {order.totalAmount?.toFixed(2)}</InfoText>
                    </InfoRow>
                  </OrderInfo>

                  <ProductCount>
                    {order.products?.length || 0} items
                  </ProductCount>
                  <PaymentBadge>{order.paymentMethod}</PaymentBadge>

                  <ProductsToggle
                    onClick={() => toggleProductsExpand(order._id)}
                  >
                    {expandedOrderId === order._id ? (
                      <>
                        <FaChevronUp /> Hide Products
                      </>
                    ) : (
                      <>
                        <FaChevronDown /> Show Products
                      </>
                    )}
                  </ProductsToggle>

                  {expandedOrderId === order._id && (
                    <ProductsExpandedList>
                      {order.products?.map((product, idx) => (
                        <ExpandedProductItem key={idx}>
                          <ExpandedProductName>
                            {product.productID?.productName || "Product"}
                          </ExpandedProductName>
                          <ExpandedProductQty>
                            {product.quantity} {product.unit}
                          </ExpandedProductQty>
                        </ExpandedProductItem>
                      ))}
                    </ProductsExpandedList>
                  )}

                  <DeliveredButton
                    disabled={order.status === "Completed"}
                    $delivered={order.status === "Completed"}
                    onClick={() =>
                      order.status !== "Completed" &&
                      handleMarkDelivered(order._id)
                    }
                  >
                    <FaCheck />
                    {order.status === "Completed"
                      ? "Delivered"
                      : "Mark Delivered"}
                  </DeliveredButton>
                </OrderCard>
              ))}
            </OrdersGrid>
          )}
        </OrdersSection>
      </MainContent>
    </PageContainer>
  );
};

// Styled Components
const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
`;

const Header = styled.header`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const BackButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const MainContent = styled.main`
  max-width: 1400px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const PageHeader = styled.div`
  margin-bottom: ${theme.spacing.xl};
`;

const PageTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0 0 ${theme.spacing.xs};
`;

const PageSubtitle = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
  margin: 0;
`;

const AddButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.xl};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const FormCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  margin-bottom: ${theme.spacing.xl};
`;

const FormHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.lg};
`;

const FormTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0;
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  color: ${theme.colors.textSecondary};
  font-size: 24px;
  cursor: pointer;
  transition: color ${theme.transitions.fast};

  &:hover {
    color: ${theme.colors.textPrimary};
  }
`;

const FormSection = styled.div`
  margin-bottom: ${theme.spacing.xl};
`;

const SectionTitle = styled.h4`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.md};
`;

const FormGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${theme.spacing.lg};
`;

const ProductGrid = styled.div`
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.md};

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.sm};
`;

const Input = styled.input`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};

  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }
`;

const Select = styled.select`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};
  background: ${theme.colors.white};
  cursor: pointer;

  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }
`;

const Divider = styled.div`
  height: 1px;
  background: ${theme.colors.border};
  margin: ${theme.spacing.xl} 0;
`;

const AddProductButton = styled.button`
  background: ${theme.colors.secondary};
  color: ${theme.colors.textPrimary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: inline-flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  &:hover {
    background: ${theme.colors.secondaryDark};
    transform: translateY(-2px);
  }
`;

const ProductsList = styled.div`
  margin-top: ${theme.spacing.lg};
  background: ${theme.colors.background};
  border-radius: ${theme.borderRadius.md};
  padding: ${theme.spacing.md};
`;

const ProductsHeader = styled.h5`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.base};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.md};
`;

const ProductItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${theme.spacing.md};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.md};
  margin-bottom: ${theme.spacing.sm};
`;

const ProductInfo = styled.div`
  flex: 1;
`;

const ProductName = styled.div`
  color: ${theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.xs};
`;

const ProductDetails = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const RemoveButton = styled.button`
  background: ${theme.colors.error};
  color: white;
  border: none;
  width: 32px;
  height: 32px;
  border-radius: ${theme.borderRadius.md};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all ${theme.transitions.fast};

  &:hover {
    background: #d32f2f;
  }
`;

const TotalRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${theme.spacing.md};
  margin-top: ${theme.spacing.md};
  border-top: 2px solid ${theme.colors.border};
`;

const TotalLabel = styled.span`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.bold};
`;

const TotalValue = styled.span`
  color: ${theme.colors.primary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.bold};
`;

const ButtonGroup = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: ${theme.spacing.md};
`;

const SubmitButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: white;
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const CancelButton = styled.button`
  background: ${theme.colors.background};
  color: ${theme.colors.textPrimary};
  border: 1px solid ${theme.colors.border};
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    background: ${theme.colors.backgroundDark};
  }
`;

const OrdersSection = styled.div`
  margin-top: ${theme.spacing.xxl};
`;

const EmptyState = styled.div`
  text-align: center;
  padding: ${theme.spacing.xxl};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
`;

const EmptyText = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
`;

const OrdersGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: ${theme.spacing.lg};
`;

const OrderCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.lg};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px ${theme.colors.shadowMedium};
  }
`;

const OrderHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.md};
  padding-bottom: ${theme.spacing.md};
  border-bottom: 1px solid ${theme.colors.border};
`;

const OrderId = styled.h4`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.base};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0;
`;

const StatusBadge = styled.span`
  padding: ${theme.spacing.xs} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.full};
  font-size: ${theme.typography.fontSize.xs};
  font-weight: ${theme.typography.fontWeight.semibold};
  text-transform: capitalize;
  background: ${(props) => {
    switch (props.status) {
      case "delivered":
        return "#E8F5E9";
      case "pending":
        return "#FFF3E0";
      case "failed":
        return "#FFEBEE";
      default:
        return "#F5F5F5";
    }
  }};
  color: ${(props) => {
    switch (props.status) {
      case "delivered":
        return "#4CAF50";
      case "pending":
        return "#FF9800";
      case "failed":
        return "#F44336";
      default:
        return "#757575";
    }
  }};
`;

const OrderInfo = styled.div`
  margin-bottom: ${theme.spacing.md};
`;

const InfoRow = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.sm};
`;

const InfoIcon = styled.div`
  color: ${theme.colors.primary};
  font-size: 14px;
`;

const InfoText = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const ProductCount = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  margin-top: ${theme.spacing.sm};
`;

const PaymentBadge = styled.div`
  display: inline-block;
  margin-top: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.lg};
  padding: ${theme.spacing.xs} ${theme.spacing.sm};
  background: ${theme.colors.secondary};
  color: ${theme.colors.textPrimary};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.xs};
  font-weight: ${theme.typography.fontWeight.semibold};
  text-transform: uppercase;
`;

const ReadOnlySelect = styled.div`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  background: ${theme.colors.background};
  color: ${theme.colors.textSecondary};
  display: flex;
  align-items: center;
  font-weight: ${theme.typography.fontWeight.medium};
`;

const ProductsToggle = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.textPrimary};
  border: 1px solid ${theme.colors.border};
  padding: ${theme.spacing.sm} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${theme.spacing.xs};
  margin-top: ${theme.spacing.md};
  margin-bottom: ${theme.spacing.md};
  width: 100%;
  transition: all ${theme.transitions.normal};

  &:hover {
    background: ${theme.colors.background};
  }
`;

const ProductsExpandedList = styled.div`
  background: ${theme.colors.background};
  border-radius: ${theme.borderRadius.md};
  padding: ${theme.spacing.md};
  margin-bottom: ${theme.spacing.md};
  border-left: 3px solid ${theme.colors.secondary};
`;

const ExpandedProductItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${theme.spacing.sm};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.md};
  margin-bottom: ${theme.spacing.xs};
  font-size: ${theme.typography.fontSize.sm};

  &:last-child {
    margin-bottom: 0;
  }
`;

const ExpandedProductName = styled.div`
  color: ${theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.medium};
  flex: 1;
`;

const ExpandedProductQty = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.xs};
  background: ${theme.colors.background};
  padding: ${theme.spacing.xs} ${theme.spacing.sm};
  border-radius: ${theme.borderRadius.md};
`;

const DeliveredButton = styled.button`
  width: 100%;
  background: ${(props) => (props.$delivered ? "#E0E0E0" : "#4CAF50")};
  color: ${(props) => (props.$delivered ? "#757575" : "white")};
  border: none;
  padding: ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: ${(props) => (props.$delivered ? "not-allowed" : "pointer")};
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${theme.spacing.sm};
  transition: all ${theme.transitions.normal};
  margin-top: ${theme.spacing.md};

  &:hover:not(:disabled) {
    background: #45a049;
    transform: translateY(-2px);
    box-shadow: 0 2px 8px ${theme.colors.shadow};
  }

  &:disabled {
    cursor: not-allowed;
  }
`;

const ConfirmationDialogOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`;

const ConfirmationDialogContent = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 4px 16px ${theme.colors.shadowMedium};
  max-width: 400px;
  width: 90%;
`;

const DialogTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.md} 0;
`;

const DialogMessage = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
  margin: 0 0 ${theme.spacing.lg} 0;
  line-height: 1.5;
`;

const DialogButtonGroup = styled.div`
  display: flex;
  gap: ${theme.spacing.md};
`;

const DialogConfirmButton = styled.button`
  flex: 1;
  background: #4caf50;
  color: white;
  border: none;
  padding: ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${theme.spacing.sm};
  transition: all ${theme.transitions.normal};

  &:hover {
    background: #45a049;
    transform: translateY(-2px);
  }
`;

const DialogCancelButton = styled.button`
  flex: 1;
  background: ${theme.colors.background};
  color: ${theme.colors.textPrimary};
  border: 1px solid ${theme.colors.border};
  padding: ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    background: ${theme.colors.textSecondary};
    color: white;
  }
`;

export default EnRouteOrders;
