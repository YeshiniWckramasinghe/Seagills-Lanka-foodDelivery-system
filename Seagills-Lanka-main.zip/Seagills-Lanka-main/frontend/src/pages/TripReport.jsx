// frontend/src/pages/TripReport.jsx
import React, { useState, useEffect } from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate, useParams } from "react-router-dom";
import {
  FaTruck,
  FaArrowLeft,
  FaDownload,
  FaDollarSign,
  FaCheckCircle,
  FaExclamationTriangle,
  FaClock,
  FaMapMarkerAlt,
} from "react-icons/fa";
import { tripSummaryAPI } from "../services/api";
import Modal from "../Component/Modal";
import LoadingState from "../Component/common/LoadingState";

const TripReport = () => {
  const navigate = useNavigate();
  const { tripSummaryId } = useParams();
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const [tripData, setTripData] = useState(null);
  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  useEffect(() => {
    document.body.style.paddingTop = "0";
    fetchTripReport();
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, [tripSummaryId]);

  const fetchTripReport = async () => {
    try {
      setLoading(true);
      const response = await tripSummaryAPI.getTripSummaryById(tripSummaryId);
      setTripData(response.data.tripSummary || response.data);
    } catch (err) {
      console.error("Error:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Error Loading Report",
        message: err.response?.data?.message || "Failed to load trip report",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDF = async () => {
    try {
      setDownloading(true);
      const response = await fetch(
        `http://localhost:5000/api/trip-summaries/${tripSummaryId}/pdf`,
        {
          method: "GET",
        }
      );

      if (!response.ok) {
        throw new Error("Failed to download PDF");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `trip-report-${tripSummaryId}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      setModal({
        isOpen: true,
        type: "success",
        title: "Download Complete",
        message: "Trip report PDF downloaded successfully!",
      });
    } catch (err) {
      console.error("Error downloading PDF:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Download Error",
        message: "Failed to download trip report PDF",
      });
    } finally {
      setDownloading(false);
    }
  };

  if (loading) {
    return <LoadingState text="Loading trip report..." />;
  }

  if (!tripData) {
    return (
      <PageContainer>
        <ErrorContainer>
          <ErrorText>Trip report not found</ErrorText>
        </ErrorContainer>
      </PageContainer>
    );
  }

  const tripDate = new Date(tripData.tripDate).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const tripStartTime = tripData.tripStartTime
    ? new Date(tripData.tripStartTime).toLocaleTimeString()
    : "N/A";

  const tripEndTime = tripData.tripEndTime
    ? new Date(tripData.tripEndTime).toLocaleTimeString()
    : "N/A";

  return (
    <PageContainer>
      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      <Header>
        <LogoSection onClick={() => navigate("/coordinator-dashboard")}>
          <Logo>
            <FaTruck />
          </Logo>
          <BrandInfo>
            <BrandName>Seagills Lanka</BrandName>
            <BrandTagline>Trip Report</BrandTagline>
          </BrandInfo>
        </LogoSection>

        <ActionButtons>
          <BackButton onClick={() => navigate("/coordinator-dashboard")}>
            <FaArrowLeft /> Back
          </BackButton>
          <DownloadButton onClick={handleDownloadPDF} disabled={downloading}>
            <FaDownload /> {downloading ? "Downloading..." : "Download PDF"}
          </DownloadButton>
        </ActionButtons>
      </Header>

      <MainContent>
        {/* Trip Details Header */}
        <ReportHeader>
          <ReportTitle>Trip Report</ReportTitle>
          <ReportSubtitle>{tripDate}</ReportSubtitle>
        </ReportHeader>

        {/* Trip Details Card */}
        <Section>
          <SectionTitle>Trip Details</SectionTitle>
          <DetailsGrid>
            <DetailItem>
              <DetailLabel>Truck Plate No</DetailLabel>
              <DetailValue>{tripData.truckID?.plateNo || "N/A"}</DetailValue>
            </DetailItem>
            <DetailItem>
              <DetailLabel>Truck Number</DetailLabel>
              <DetailValue>
                {tripData.truckID?.truckNumber || "N/A"}
              </DetailValue>
            </DetailItem>
            <DetailItem>
              <DetailLabel>Coordinator</DetailLabel>
              <DetailValue>
                {tripData.coordinatorID?.firstName}{" "}
                {tripData.coordinatorID?.lastName}
              </DetailValue>
            </DetailItem>
            <DetailItem>
              <DetailLabel>Driver</DetailLabel>
              <DetailValue>
                {tripData.driverID?.firstName} {tripData.driverID?.lastName}
              </DetailValue>
            </DetailItem>
            <DetailItem>
              <DetailLabel>Route</DetailLabel>
              <DetailValue>
                {tripData.routeID?.start?.name} to {tripData.routeID?.end?.name}
              </DetailValue>
            </DetailItem>
            <DetailItem>
              <DetailLabel>Trip Status</DetailLabel>
              <StatusBadge $status={tripData.tripStatus}>
                {tripData.tripStatus.toUpperCase()}
              </StatusBadge>
            </DetailItem>
            <DetailItem>
              <DetailLabel>Start Time</DetailLabel>
              <DetailValue>{tripStartTime}</DetailValue>
            </DetailItem>
            <DetailItem>
              <DetailLabel>End Time</DetailLabel>
              <DetailValue>{tripEndTime}</DetailValue>
            </DetailItem>
            <DetailItem>
              <DetailLabel>Duration</DetailLabel>
              <DetailValue>
                {tripData.tripDurationMinutes
                  ? `${tripData.tripDurationMinutes} minutes`
                  : "N/A"}
              </DetailValue>
            </DetailItem>
          </DetailsGrid>
        </Section>

        {/* Pre-Orders Summary */}
        <Section>
          <SectionTitle>Pre-Orders Summary</SectionTitle>
          <StatsGrid>
            <StatCard $type="total">
              <StatIcon>
                <FaTruck />
              </StatIcon>
              <StatContent>
                <StatLabel>Total Pre-Orders</StatLabel>
                <StatValue>
                  {tripData.deliveryStats?.totalPreorders || 0}
                </StatValue>
              </StatContent>
            </StatCard>
            <StatCard $type="success">
              <StatIcon>
                <FaCheckCircle />
              </StatIcon>
              <StatContent>
                <StatLabel>Delivered</StatLabel>
                <StatValue>
                  {tripData.deliveryStats?.deliveredPreorders || 0}
                </StatValue>
              </StatContent>
            </StatCard>
            <StatCard $type="warning">
              <StatIcon>
                <FaClock />
              </StatIcon>
              <StatContent>
                <StatLabel>Pending</StatLabel>
                <StatValue>
                  {tripData.deliveryStats?.pendingPreorders || 0}
                </StatValue>
              </StatContent>
            </StatCard>
            <StatCard $type="error">
              <StatIcon>
                <FaExclamationTriangle />
              </StatIcon>
              <StatContent>
                <StatLabel>Failed</StatLabel>
                <StatValue>
                  {tripData.deliveryStats?.failedPreorders || 0}
                </StatValue>
              </StatContent>
            </StatCard>
          </StatsGrid>

          <PaymentInfo>
            <PaymentRow>
              <PaymentLabel>Total Amount:</PaymentLabel>
              <PaymentValue>
                LKR {tripData.deliveryStats?.totalPreorderAmount || 0}
              </PaymentValue>
            </PaymentRow>
            <PaymentRow>
              <PaymentLabel>Collected:</PaymentLabel>
              <PaymentValue $success>
                LKR {tripData.deliveryStats?.collectedPreorderAmount || 0}
              </PaymentValue>
            </PaymentRow>
            <PaymentRow>
              <PaymentLabel>Pending:</PaymentLabel>
              <PaymentValue $warning>
                LKR {tripData.deliveryStats?.pendingPreorderAmount || 0}
              </PaymentValue>
            </PaymentRow>
          </PaymentInfo>
        </Section>

        {/* En-Route Orders Summary */}
        <Section>
          <SectionTitle>En-Route Orders Summary</SectionTitle>
          <StatsGrid>
            <StatCard $type="total">
              <StatIcon>
                <FaTruck />
              </StatIcon>
              <StatContent>
                <StatLabel>Total En-Route Orders</StatLabel>
                <StatValue>
                  {tripData.deliveryStats?.totalEnrouteOrders || 0}
                </StatValue>
              </StatContent>
            </StatCard>
            <StatCard $type="success">
              <StatIcon>
                <FaCheckCircle />
              </StatIcon>
              <StatContent>
                <StatLabel>Delivered</StatLabel>
                <StatValue>
                  {tripData.deliveryStats?.deliveredEnrouteOrders || 0}
                </StatValue>
              </StatContent>
            </StatCard>
            <StatCard $type="warning">
              <StatIcon>
                <FaClock />
              </StatIcon>
              <StatContent>
                <StatLabel>Pending</StatLabel>
                <StatValue>
                  {tripData.deliveryStats?.pendingEnrouteOrders || 0}
                </StatValue>
              </StatContent>
            </StatCard>
          </StatsGrid>

          <PaymentInfo>
            <PaymentRow>
              <PaymentLabel>Total Amount:</PaymentLabel>
              <PaymentValue>
                LKR {tripData.deliveryStats?.totalEnrouteAmount || 0}
              </PaymentValue>
            </PaymentRow>
            <PaymentRow>
              <PaymentLabel>Collected:</PaymentLabel>
              <PaymentValue $success>
                LKR {tripData.deliveryStats?.collectedEnrouteAmount || 0}
              </PaymentValue>
            </PaymentRow>
          </PaymentInfo>
        </Section>

        {/* Payment Summary */}
        <Section>
          <SectionTitle>Payment Summary</SectionTitle>
          <PaymentSummaryGrid>
            <PaymentSummaryCard>
              <PaymentSummaryIcon $type="cash">
                <FaDollarSign />
              </PaymentSummaryIcon>
              <PaymentSummaryContent>
                <PaymentSummaryLabel>Cash Collected</PaymentSummaryLabel>
                <PaymentSummaryValue>
                  LKR {tripData.paymentSummary?.cashCollected || 0}
                </PaymentSummaryValue>
              </PaymentSummaryContent>
            </PaymentSummaryCard>

            <PaymentSummaryCard>
              <PaymentSummaryIcon $type="card">
                <FaDollarSign />
              </PaymentSummaryIcon>
              <PaymentSummaryContent>
                <PaymentSummaryLabel>Card Collected</PaymentSummaryLabel>
                <PaymentSummaryValue>
                  LKR {tripData.paymentSummary?.cardCollected || 0}
                </PaymentSummaryValue>
              </PaymentSummaryContent>
            </PaymentSummaryCard>

            <PaymentSummaryCard>
              <PaymentSummaryIcon $type="total">
                <FaDollarSign />
              </PaymentSummaryIcon>
              <PaymentSummaryContent>
                <PaymentSummaryLabel>Total Collected</PaymentSummaryLabel>
                <PaymentSummaryValue>
                  LKR {tripData.paymentSummary?.totalCollected || 0}
                </PaymentSummaryValue>
              </PaymentSummaryContent>
            </PaymentSummaryCard>
          </PaymentSummaryGrid>
        </Section>

        {/* Incidents Section */}
        {tripData.incidentIds && tripData.incidentIds.length > 0 && (
          <Section>
            <SectionTitle>Incidents Recorded</SectionTitle>
            <IncidentsContainer>
              {tripData.incidentIds.map((incident, index) => (
                <IncidentCard key={index} $severity={incident.severity}>
                  <IncidentHeader>
                    <IncidentType>
                      {incident.incidentType.toUpperCase()}
                    </IncidentType>
                    <SeverityBadge $severity={incident.severity}>
                      {incident.severity.toUpperCase()}
                    </SeverityBadge>
                  </IncidentHeader>
                  <IncidentDetail>
                    <DetailLabel>Description:</DetailLabel>
                    <DetailValue>{incident.description}</DetailValue>
                  </IncidentDetail>
                  <IncidentDetail>
                    <DetailLabel>Location:</DetailLabel>
                    <DetailValue>{incident.location}</DetailValue>
                  </IncidentDetail>
                  <IncidentDetail>
                    <DetailLabel>Time:</DetailLabel>
                    <DetailValue>
                      {new Date(incident.incidentTime).toLocaleTimeString()}
                    </DetailValue>
                  </IncidentDetail>
                  {incident.durationInMinutes && (
                    <IncidentDetail>
                      <DetailLabel>Duration:</DetailLabel>
                      <DetailValue>
                        {incident.durationInMinutes} minutes
                      </DetailValue>
                    </IncidentDetail>
                  )}
                  {incident.cause && (
                    <IncidentDetail>
                      <DetailLabel>Cause:</DetailLabel>
                      <DetailValue>{incident.cause}</DetailValue>
                    </IncidentDetail>
                  )}
                  {incident.resolutionAction && (
                    <IncidentDetail>
                      <DetailLabel>Resolution:</DetailLabel>
                      <DetailValue>{incident.resolutionAction}</DetailValue>
                    </IncidentDetail>
                  )}
                </IncidentCard>
              ))}
            </IncidentsContainer>
          </Section>
        )}

        {/* Coordinator Notes */}
        {tripData.coordinatorNotes && (
          <Section>
            <SectionTitle>Coordinator Notes</SectionTitle>
            <NotesBox>{tripData.coordinatorNotes}</NotesBox>
          </Section>
        )}
      </MainContent>
    </PageContainer>
  );
};

// Styled Components
const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
`;

const Header = styled.header`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const ActionButtons = styled.div`
  display: flex;
  gap: ${theme.spacing.md};
`;

const BackButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const DownloadButton = styled.button`
  background: #4caf50;
  color: white;
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  transition: all ${theme.transitions.normal};

  &:hover:not(:disabled) {
    background: #45a049;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const MainContent = styled.main`
  max-width: 1200px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const ReportHeader = styled.div`
  margin-bottom: ${theme.spacing.xl};
`;

const ReportTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0 0 ${theme.spacing.xs};
`;

const ReportSubtitle = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.lg};
  margin: 0;
`;

const Section = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  margin-bottom: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const SectionTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
`;

const DetailsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${theme.spacing.lg};
`;

const DetailItem = styled.div`
  display: flex;
  flex-direction: column;
`;

const DetailLabel = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin-bottom: ${theme.spacing.xs};
`;

const DetailValue = styled.span`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.base};
  font-weight: ${theme.typography.fontWeight.medium};
`;

const StatusBadge = styled.span`
  padding: ${theme.spacing.xs} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.full};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
  background: ${(props) => {
    switch (props.$status) {
      case "completed":
        return "#d4edda";
      case "partial":
        return "#fff3cd";
      case "failed":
        return "#f8d7da";
      default:
        return "#e2e3e5";
    }
  }};
  color: ${(props) => {
    switch (props.$status) {
      case "completed":
        return "#155724";
      case "partial":
        return "#856404";
      case "failed":
        return "#721c24";
      default:
        return "#383d41";
    }
  }};
  width: fit-content;
`;

const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.lg};
`;

const StatCard = styled.div`
  background: linear-gradient(135deg, #f5f5f5 0%, #e8e8e8 100%);
  border-radius: ${theme.borderRadius.lg};
  padding: ${theme.spacing.lg};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  border-left: 4px solid
    ${(props) => {
      switch (props.$type) {
        case "success":
          return "#4caf50";
        case "warning":
          return "#ff9800";
        case "error":
          return "#f44336";
        default:
          return "#1abc9c";
      }
    }};
`;

const StatIcon = styled.div`
  font-size: 28px;
  color: ${theme.colors.primary};
`;

const StatContent = styled.div`
  display: flex;
  flex-direction: column;
`;

const StatLabel = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
`;

const StatValue = styled.span`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.bold};
`;

const PaymentInfo = styled.div`
  margin-top: ${theme.spacing.lg};
  padding-top: ${theme.spacing.lg};
  border-top: 1px solid ${theme.colors.border};
`;

const PaymentRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${theme.spacing.sm} 0;
  font-size: ${theme.typography.fontSize.base};
`;

const PaymentLabel = styled.span`
  color: ${theme.colors.textSecondary};
  font-weight: ${theme.typography.fontWeight.medium};
`;

const PaymentValue = styled.span`
  color: ${(props) =>
    props.$success
      ? "#4caf50"
      : props.$warning
      ? "#ff9800"
      : theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.bold};
  font-size: ${theme.typography.fontSize.lg};
`;

const PaymentSummaryGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: ${theme.spacing.lg};
`;

const PaymentSummaryCard = styled.div`
  background: linear-gradient(135deg, #f5f5f5 0%, #e8e8e8 100%);
  border-radius: ${theme.borderRadius.lg};
  padding: ${theme.spacing.lg};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
`;

const PaymentSummaryIcon = styled.div`
  width: 60px;
  height: 60px;
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  color: white;
  background: ${(props) => {
    switch (props.$type) {
      case "cash":
        return "#4caf50";
      case "card":
        return "#2196f3";
      case "total":
        return "#ff9800";
      default:
        return theme.colors.primary;
    }
  }};
`;

const PaymentSummaryContent = styled.div`
  display: flex;
  flex-direction: column;
`;

const PaymentSummaryLabel = styled.span`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
`;

const PaymentSummaryValue = styled.span`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.bold};
`;

const IncidentsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${theme.spacing.lg};
`;

const IncidentCard = styled.div`
  border: 2px solid
    ${(props) => {
      switch (props.$severity) {
        case "critical":
          return "#f44336";
        case "high":
          return "#ff9800";
        case "medium":
          return "#ffc107";
        default:
          return "#4caf50";
      }
    }};
  border-radius: ${theme.borderRadius.lg};
  padding: ${theme.spacing.lg};
  background: ${(props) => {
    switch (props.$severity) {
      case "critical":
        return "#ffebee";
      case "high":
        return "#fff3e0";
      case "medium":
        return "#fffde7";
      default:
        return "#e8f5e9";
    }
  }};
`;

const IncidentHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.md};
`;

const IncidentType = styled.span`
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.bold};
  color: ${theme.colors.textPrimary};
  text-transform: uppercase;
`;

const SeverityBadge = styled.span`
  padding: ${theme.spacing.xs} ${theme.spacing.sm};
  border-radius: ${theme.borderRadius.full};
  font-size: ${theme.typography.fontSize.xs};
  font-weight: ${theme.typography.fontWeight.bold};
  background: ${(props) => {
    switch (props.$severity) {
      case "critical":
        return "#f44336";
      case "high":
        return "#ff9800";
      case "medium":
        return "#ffc107";
      default:
        return "#4caf50";
    }
  }};
  color: white;
`;

const IncidentDetail = styled.div`
  margin-bottom: ${theme.spacing.sm};
`;

const NotesBox = styled.div`
  background: ${theme.colors.background};
  border-radius: ${theme.borderRadius.lg};
  padding: ${theme.spacing.lg};
  color: ${theme.colors.textPrimary};
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-word;
`;

const ErrorContainer = styled.div`
  text-align: center;
  padding: ${theme.spacing.xxl};
`;

const ErrorText = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.lg};
`;

export default TripReport;
