// src/pages/UpdatePayments.jsx
import React, { useState, useEffect } from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import {
  FaTruck,
  FaArrowLeft,
  FaCheck,
  FaChevronDown,
  FaChevronUp,
  FaDollarSign,
} from "react-icons/fa";
import { preorderAPI, assignedTruckAPI, paymentAPI } from "../services/api";
import Modal from "../Component/Modal";

const UpdatePayments = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [orders, setOrders] = useState([]);
  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });
  const [expandedOrderId, setExpandedOrderId] = useState(null);
  const [confirmDialog, setConfirmDialog] = useState({
    isOpen: false,
    orderId: null,
  });
  const [runNotStartedModal, setRunNotStartedModal] = useState(false);

  useEffect(() => {
    document.body.style.paddingTop = "0";
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, []);

  useEffect(() => {
    checkIfRunStarted();
  }, []);

  const checkIfRunStarted = async () => {
    try {
      const userStr = localStorage.getItem("user");
      if (!userStr) {
        navigate("/login");
        return;
      }

      const user = JSON.parse(userStr);
      const today = new Date().toISOString().split("T")[0];

      const response = await assignedTruckAPI.getCoordinatorDailySchedule(
        user.id,
        today
      );

      if (response.data.success && response.data.schedule) {
        const schedule = response.data.schedule;

        // Check if trip has been started
        if (!schedule.tripStartedAt) {
          setRunNotStartedModal(true);
        }
      }
    } catch (err) {
      console.error("Error checking run status:", err);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const userStr = localStorage.getItem("user");
      const user = JSON.parse(userStr);
      const today = new Date().toISOString().split("T")[0];

      console.log("🔍 DEBUG: Starting fetchOrders");
      console.log("📋 User ID:", user.id);
      console.log("📋 Today's date:", today);

      // Get user's truck assignment for today
      const assignmentRes = await assignedTruckAPI.getAssignmentsByDate(today);
      console.log("📋 Assignment Response:", assignmentRes.data);

      if (
        assignmentRes.data.success &&
        assignmentRes.data.assignments.length > 0
      ) {
        const myAssignment = assignmentRes.data.assignments.find(
          (a) => a.deliveryCoordinatorID._id === user.id
        );
        console.log("📋 My Assignment:", myAssignment);

        if (myAssignment) {
          console.log("🔍 Truck ID being used:", myAssignment.truckID);
          console.log("🔍 Truck ID type:", typeof myAssignment.truckID);
          console.log("🔍 Date being passed:", today);

          const truckId =
            typeof myAssignment.truckID === "object"
              ? myAssignment.truckID._id
              : myAssignment.truckID;

          console.log("🔍 Truck ID being used:", truckId);

          // Fetch preorders by truck
          const preordersRes = await preorderAPI
            .getPreordersByTruck(truckId, today)
            .catch((err) => {
              console.log("❌ Error fetching preorders:", err.message);
              console.log("❌ Error status:", err.response?.status);
              console.log("❌ Error data:", err.response?.data);
              console.log("❌ Request URL:", err.config?.url);
              console.log("❌ Request params:", err.config?.params);
              return { data: { preorders: [] } };
            });

          console.log("📋 Preorders Response:", preordersRes.data);
          console.log(
            "📋 Total preorders returned:",
            preordersRes.data.preorders?.length || 0
          );

          if (
            preordersRes.data.preorders &&
            preordersRes.data.preorders.length > 0
          ) {
            preordersRes.data.preorders.forEach((order, idx) => {
              console.log(`📋 Preorder ${idx}:`, {
                id: order._id,
                orderStatus: order.orderStatus,
                paymentStatus: order.paymentStatus,
              });
            });
          }

          // Filter only verified preorders
          const allOrders = (preordersRes.data.preorders || [])
            .filter((o) => o.orderStatus === "verified")
            .map((o) => ({
              ...o,
              type: "preorder",
            }));

          console.log("📋 Filtered orders (verified only):", allOrders.length);
          setOrders(allOrders);
        } else {
          console.log("❌ No assignment found for this coordinator");
          setOrders([]);
        }
      } else {
        console.log("❌ No assignments found for today");
        setOrders([]);
      }
    } catch (err) {
      console.error("❌ Error in fetchOrders:", err);
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkDelivered = (orderId) => {
    setConfirmDialog({
      isOpen: true,
      orderId: orderId,
    });
  };

  const confirmMarkDelivered = async () => {
    try {
      const userStr = localStorage.getItem("user");
      const user = JSON.parse(userStr);

      await paymentAPI.updatePayment(confirmDialog.orderId, {
        paymentStatus: "Completed",
        coordinatorID: user.id,
      });

      setModal({
        isOpen: true,
        type: "success",
        title: "Order Delivered",
        message: "Preorder marked as delivered successfully!",
      });

      setConfirmDialog({ isOpen: false, orderId: null });
      fetchOrders();
    } catch (err) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Error",
        message:
          err.response?.data?.message || "Failed to mark order as delivered",
      });
    }
  };

  const toggleProductsExpand = (orderId) => {
    setExpandedOrderId(expandedOrderId === orderId ? null : orderId);
  };

  const handleUpdatePayment = async (orderId, status) => {
    try {
      const userStr = localStorage.getItem("user");
      const user = JSON.parse(userStr);

      await paymentAPI.updatePayment(orderId, {
        paymentStatus: status,
        coordinatorID: user.id,
      });

      setModal({
        isOpen: true,
        type: "success",
        title: "Payment Updated",
        message: `Payment status updated to ${status}`,
      });

      fetchOrders();
    } catch (err) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Error",
        message: err.response?.data?.message || "Failed to update payment",
      });
    }
  };

  return (
    <PageContainer>
      <Modal
        isOpen={runNotStartedModal}
        onClose={() => {
          setRunNotStartedModal(false);
          navigate("/coordinator-dashboard");
        }}
        type="warning"
        title="Run Not Started"
        message="Please ensure the 'Start Daily Run' button was clicked on the dashboard before updating payments."
      />

      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      {confirmDialog.isOpen && (
        <ConfirmationDialogOverlay>
          <ConfirmationDialogContent>
            <DialogTitle>Confirm Delivery</DialogTitle>
            <DialogMessage>
              Are you sure you want to mark this order as delivered?
            </DialogMessage>
            <DialogButtonGroup>
              <DialogConfirmButton onClick={confirmMarkDelivered}>
                <FaCheck /> Yes, Mark Delivered
              </DialogConfirmButton>
              <DialogCancelButton
                onClick={() =>
                  setConfirmDialog({ isOpen: false, orderId: null })
                }
              >
                Cancel
              </DialogCancelButton>
            </DialogButtonGroup>
          </ConfirmationDialogContent>
        </ConfirmationDialogOverlay>
      )}

      <Header>
        <LogoSection onClick={() => navigate("/coordinator-dashboard")}>
          <Logo>
            <FaTruck />
          </Logo>
          <BrandInfo>
            <BrandName>Seagills Lanka</BrandName>
            <BrandTagline>Delivery Management</BrandTagline>
          </BrandInfo>
        </LogoSection>
        <UserSection>
          <UserInfo>
            <UserName>
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </UserName>
            <UserRole>Coordinator</UserRole>
          </UserInfo>
          <BackButton onClick={() => navigate("/coordinator-dashboard")}>
            <FaArrowLeft /> Back
          </BackButton>
        </UserSection>
      </Header>

      <MainContent>
        <PageTitle>Update Payments</PageTitle>
        <PageSubtitle>Update payment status for orders</PageSubtitle>

        {loading ? (
          <LoadingText>Loading orders...</LoadingText>
        ) : orders.length === 0 ? (
          <EmptyState>
            <EmptyText>No pending orders found</EmptyText>
          </EmptyState>
        ) : (
          <OrdersGrid>
            {orders.map((order) => (
              <OrderCard key={order._id}>
                <OrderHeader>
                  <OrderId>#{order._id.slice(-6).toUpperCase()}</OrderId>
                  <TypeBadge type={order.type}>{order.type}</TypeBadge>
                </OrderHeader>
                <OrderAmount>
                  <FaDollarSign /> LKR {order.totalAmount?.toFixed(2)}
                </OrderAmount>
                <PaymentMethod>Payment: {order.paymentMethod}</PaymentMethod>

                <ProductsToggle onClick={() => toggleProductsExpand(order._id)}>
                  {expandedOrderId === order._id ? (
                    <>
                      <FaChevronUp /> Hide Products
                    </>
                  ) : (
                    <>
                      <FaChevronDown /> Show Products
                    </>
                  )}
                </ProductsToggle>

                {expandedOrderId === order._id && (
                  <ProductsExpandedList>
                    {(order.preorderProducts || order.products || []).map(
                      (product, idx) => (
                        <ExpandedProductItem key={idx}>
                          <ExpandedProductName>
                            {product.productName || "Product"}
                          </ExpandedProductName>
                          <ExpandedProductQty>
                            {product.quantity} {product.unit}
                          </ExpandedProductQty>
                        </ExpandedProductItem>
                      )
                    )}
                  </ProductsExpandedList>
                )}

                <ButtonGroup>
                  <DeliveredButton
                    disabled={order.paymentStatus === "Completed"}
                    $delivered={order.paymentStatus === "Completed"}
                    onClick={() =>
                      order.paymentStatus !== "Completed" &&
                      handleMarkDelivered(order._id)
                    }
                  >
                    <FaCheck />
                    {order.paymentStatus === "Completed"
                      ? "Delivered"
                      : "Mark Delivered"}
                  </DeliveredButton>
                </ButtonGroup>
              </OrderCard>
            ))}
          </OrdersGrid>
        )}
      </MainContent>
    </PageContainer>
  );
};

// Styled Components (simplified)
const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
`;
const Header = styled.header`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;
const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;
const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;
const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;
const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;
const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;
const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;
const UserInfo = styled.div`
  text-align: right;
`;
const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
`;
const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;
const BackButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  transition: all ${theme.transitions.normal};
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;
const MainContent = styled.main`
  max-width: 1400px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;
const PageTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0 0 ${theme.spacing.xs};
`;
const PageSubtitle = styled.p`
  color: ${theme.colors.textSecondary};
  margin: 0 0 ${theme.spacing.xl};
`;
const LoadingText = styled.p`
  color: ${theme.colors.textSecondary};
  text-align: center;
  padding: ${theme.spacing.xl};
`;
const EmptyState = styled.div`
  text-align: center;
  padding: ${theme.spacing.xxl};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
`;
const EmptyText = styled.p`
  color: ${theme.colors.textSecondary};
`;
const OrdersGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: ${theme.spacing.lg};
`;
const OrderCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.lg};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;
const OrderHeader = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: ${theme.spacing.md};
  padding-bottom: ${theme.spacing.md};
  border-bottom: 1px solid ${theme.colors.border};
`;
const OrderId = styled.h4`
  color: ${theme.colors.textPrimary};
  margin: 0;
`;

const OrderAmount = styled.div`
  color: ${theme.colors.primary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.bold};
  margin-bottom: ${theme.spacing.sm};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.xs};
`;
const PaymentMethod = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  margin-bottom: ${theme.spacing.md};
`;
const ButtonGroup = styled.div`
  display: flex;
  gap: ${theme.spacing.sm};
`;

const ProductsToggle = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.textPrimary};
  border: 1px solid ${theme.colors.border};
  padding: ${theme.spacing.sm} ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${theme.spacing.xs};
  margin-top: ${theme.spacing.md};
  margin-bottom: ${theme.spacing.md};
  width: 100%;
  transition: all ${theme.transitions.normal};

  &:hover {
    background: ${theme.colors.background};
  }
`;

const ProductsExpandedList = styled.div`
  background: ${theme.colors.background};
  border-radius: ${theme.borderRadius.md};
  padding: ${theme.spacing.md};
  margin-bottom: ${theme.spacing.md};
  border-left: 3px solid ${theme.colors.secondary};
`;

const ExpandedProductItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${theme.spacing.sm};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.md};
  margin-bottom: ${theme.spacing.xs};
  font-size: ${theme.typography.fontSize.sm};

  &:last-child {
    margin-bottom: 0;
  }
`;

const ExpandedProductName = styled.div`
  color: ${theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.medium};
  flex: 1;
`;

const ExpandedProductQty = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.xs};
  background: ${theme.colors.background};
  padding: ${theme.spacing.xs} ${theme.spacing.sm};
  border-radius: ${theme.borderRadius.md};
`;

const DeliveredButton = styled.button`
  flex: 1;
  background: ${(props) => (props.$delivered ? "#E0E0E0" : "#4CAF50")};
  color: ${(props) => (props.$delivered ? "#757575" : "white")};
  border: none;
  padding: ${theme.spacing.sm};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: ${(props) => (props.$delivered ? "not-allowed" : "pointer")};
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${theme.spacing.sm};
  transition: all ${theme.transitions.normal};

  &:hover:not(:disabled) {
    background: #45a049;
    transform: translateY(-2px);
  }

  &:disabled {
    cursor: not-allowed;
  }
`;

const ConfirmationDialogOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`;

const ConfirmationDialogContent = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 4px 16px ${theme.colors.shadowMedium};
  max-width: 400px;
  width: 90%;
`;

const DialogTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.md} 0;
`;

const DialogMessage = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
  margin: 0 0 ${theme.spacing.lg} 0;
  line-height: 1.5;
`;

const DialogButtonGroup = styled.div`
  display: flex;
  gap: ${theme.spacing.md};
`;

const DialogConfirmButton = styled.button`
  flex: 1;
  background: #4caf50;
  color: white;
  border: none;
  padding: ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${theme.spacing.sm};
  transition: all ${theme.transitions.normal};

  &:hover {
    background: #45a049;
    transform: translateY(-2px);
  }
`;

const DialogCancelButton = styled.button`
  flex: 1;
  background: ${theme.colors.background};
  color: ${theme.colors.textPrimary};
  border: 1px solid ${theme.colors.border};
  padding: ${theme.spacing.md};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    background: ${theme.colors.textSecondary};
    color: white;
  }
`;

const TypeBadge = styled.span`
  padding: ${theme.spacing.xs} ${theme.spacing.sm};
  background: ${(props) => (props.type === "preorder" ? "#E3F2FD" : "#FFF3E0")};
  color: ${(props) => (props.type === "preorder" ? "#1976D2" : "#F57C00")};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.xs};
  font-weight: ${theme.typography.fontWeight.semibold};
`;

export default UpdatePayments;
