//
import React, { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";
//import Nav from "../Nav/Nav";
import { RiEdit2Fill, RiFilePdf2Line, RiGlobalLine } from "react-icons/ri";
import { MdDelete, MdAdd, MdSearch, MdEmail, MdPhone } from "react-icons/md";
import { FiFilter, FiUser } from "react-icons/fi";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import { FaTruck } from "react-icons/fa";

// Modal Component
const SupplierModal = ({ isOpen, onClose, onSave, supplier }) => {
  const [formData, setFormData] = useState({
    supplierName: "",
    contactNum: "",
    email: "",
    websiteLink: "",
  });

  useEffect(() => {
    if (supplier) {
      setFormData({
        supplierName: supplier.supplierName,
        contactNum: supplier.contactNum,
        email: supplier.email,
        websiteLink: supplier.websiteLink || "",
      });
    } else {
      setFormData({ 
        supplierName: "", 
        contactNum: "", 
        email: "", 
        websiteLink: "" 
      });
    }
  }, [supplier]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  if (!isOpen) return null;

  return (
    
    <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-96 p-6 transform transition-all duration-300 scale-100">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">
            {supplier ? "Edit Supplier" : "Add New Supplier"}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors duration-200"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Supplier Name</label>
            <div className="relative">
              <FiUser className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="text"
                name="supplierName"
                placeholder="Enter supplier name"
                value={formData.supplierName}
                onChange={handleChange}
                required
                className="w-full border border-gray-300 p-3 pl-10 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Contact Number</label>
            <div className="relative">
              <MdPhone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="text"
                name="contactNum"
                placeholder="Enter contact number"
                value={formData.contactNum}
                onChange={handleChange}
                required
                className="w-full border border-gray-300 p-3 pl-10 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
            <div className="relative">
              <MdEmail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="email"
                name="email"
                placeholder="Enter email address"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full border border-gray-300 p-3 pl-10 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Website Link</label>
            <div className="relative">
              <RiGlobalLine className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="text"
                name="websiteLink"
                placeholder="Enter website URL"
                value={formData.websiteLink}
                onChange={handleChange}
                className="w-full border border-gray-300 p-3 pl-10 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors duration-200 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all duration-200 font-medium shadow-lg shadow-blue-500/25"
            >
              {supplier ? "Update Supplier" : "Add Supplier"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Filter Component
const FilterBar = ({ filters, onFilterChange, onSearch }) => {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <MdSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search suppliers..."
            onChange={(e) => onSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        
        <select
          value={filters.sortBy}
          onChange={(e) => onFilterChange('sortBy', e.target.value)}
          className="border border-gray-300 p-3 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="name">Sort by Name</option>
          <option value="contact">Sort by Contact</option>
          <option value="email">Sort by Email</option>
        </select>
      </div>
    </div>
  );
};

function Supplier() {
  const navigate = useNavigate();
  const [suppliers, setSuppliers] = useState([]);
  const [filteredSuppliers, setFilteredSuppliers] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [filters, setFilters] = useState({
    search: "",
    sortBy: "name"
  });
  const [loading, setLoading] = useState(true);

      const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  // Fetch suppliers
  const fetchSuppliers = async () => {
    try {
      setLoading(true);
      const res = await axios.get("http://localhost:5000/api/suppliers");
      setSuppliers(res.data);
      setFilteredSuppliers(res.data);
    } catch (error) {
      toast.error("Error fetching suppliers");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSuppliers();
  }, []);

  // Filter and sort suppliers
  useEffect(() => {
    let result = suppliers;

    // Search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(supplier =>
        supplier.supplierName.toLowerCase().includes(searchLower) ||
        supplier.contactNum.toLowerCase().includes(searchLower) ||
        supplier.email.toLowerCase().includes(searchLower) ||
        (supplier.websiteLink && supplier.websiteLink.toLowerCase().includes(searchLower))
      );
    }

    // Sorting
    switch (filters.sortBy) {
      case 'contact':
        result = [...result].sort((a, b) => a.contactNum.localeCompare(b.contactNum));
        break;
      case 'email':
        result = [...result].sort((a, b) => a.email.localeCompare(b.email));
        break;
      default:
        result = [...result].sort((a, b) => a.supplierName.localeCompare(b.supplierName));
    }

    setFilteredSuppliers(result);
  }, [suppliers, filters]);

  // Add or Update Supplier
  const handleSave = async (data) => {
    try {
      if (editingSupplier) {
        await axios.put(
          `http://localhost:5000/api/suppliers/${editingSupplier._id}`,
          data
        );
        toast.success("Supplier updated successfully!");
      } else {
        await axios.post("http://localhost:5000/api/suppliers", data);
        toast.success("Supplier added successfully!");
      }
      setIsModalOpen(false);
      setEditingSupplier(null);
      fetchSuppliers();
    } catch (error) {
      toast.error("Error saving supplier");
    }
  };

  // Delete Supplier
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this supplier?")) {
      try {
        await axios.delete(`http://localhost:5000/api/suppliers/${id}`);
        toast.success("Supplier deleted successfully!");
        fetchSuppliers();
      } catch (error) {
        toast.error("Error deleting supplier");
      }
    }
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleSearch = (searchTerm) => {
    setFilters(prev => ({ ...prev, search: searchTerm }));
  };

  // PDF Download Function
  const downloadPDF = async () => {
    try {
      const { jsPDF } = await import('jspdf');
      
      const doc = new jsPDF();
      
      // Title
      doc.setFontSize(20);
      doc.setTextColor(40, 40, 40);
      doc.text('Supplier List Report', 105, 20, { align: 'center' });
      
      // Date
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 105, 30, { align: 'center' });
      
      // Simple table implementation
      const headers = ['Supplier Name', 'Contact', 'Email', 'Website'];
      const data = filteredSuppliers.map(supplier => [
        supplier.supplierName,
        supplier.contactNum,
        supplier.email,
        supplier.websiteLink || 'N/A'
      ]);
      
      // Manual table drawing
      let yPosition = 50;
      const rowHeight = 10;
      const pageHeight = doc.internal.pageSize.height;
      const margin = 15;
      const columnWidths = [50, 40, 60, 40];
      
      // Draw headers
      doc.setFillColor(59, 130, 246);
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont(undefined, 'bold');
      
      let xPosition = margin;
      headers.forEach((header, index) => {
        doc.rect(xPosition, yPosition - 5, columnWidths[index], rowHeight, 'F');
        doc.text(header, xPosition + 2, yPosition + 2);
        xPosition += columnWidths[index];
      });
      
      // Draw rows
      doc.setFont(undefined, 'normal');
      doc.setFontSize(10);
      doc.setTextColor(0, 0, 0);
      
      data.forEach((row, rowIndex) => {
        // Check if we need a new page
        if (yPosition > pageHeight - 20) {
          doc.addPage();
          yPosition = 20;
          
          // Redraw headers on new page
          doc.setFillColor(59, 130, 246);
          doc.setTextColor(255, 255, 255);
          doc.setFontSize(12);
          doc.setFont(undefined, 'bold');
          
          xPosition = margin;
          headers.forEach((header, index) => {
            doc.rect(xPosition, yPosition - 5, columnWidths[index], rowHeight, 'F');
            doc.text(header, xPosition + 2, yPosition + 2);
            xPosition += columnWidths[index];
          });
          
          yPosition += rowHeight + 5;
          doc.setFont(undefined, 'normal');
          doc.setFontSize(10);
          doc.setTextColor(0, 0, 0);
        }
        
        // Alternate row colors
        if (rowIndex % 2 === 0) {
          doc.setFillColor(240, 240, 240);
          xPosition = margin;
          columnWidths.forEach(width => {
            doc.rect(xPosition, yPosition - 5, width, rowHeight, 'F');
            xPosition += width;
          });
        }
        
        // Draw row data
        xPosition = margin;
        row.forEach((cell, cellIndex) => {
          const text = cell.length > 25 ? cell.substring(0, 22) + '...' : cell;
          doc.text(text, xPosition + 2, yPosition + 2);
          xPosition += columnWidths[cellIndex];
        });
        
        yPosition += rowHeight + 5;
      });
      
      // Footer
      doc.setFontSize(8);
      doc.setTextColor(150, 150, 150);
      doc.text(`Total Suppliers: ${filteredSuppliers.length}`, margin, yPosition + 10);
      
      doc.save(`suppliers-report-${new Date().toISOString().split('T')[0]}.pdf`);
      toast.success("PDF report downloaded successfully!");
      
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error("Error generating PDF report");
    }
  };

  const formatWebsiteLink = (link) => {
    if (!link) return "-";
    const cleanLink = link.replace(/^https?:\/\//, '');
    return cleanLink.length > 30 ? cleanLink.substring(0, 30) + '...' : cleanLink;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="max-w-7xl mx-auto p-6">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <PageContainer>
          <Header>
            <LogoSection onClick={() => navigate("/admin-dashboard")}>
              <Logo>
                <FaTruck color={theme.colors.primary} />
              </Logo>
              <BrandInfo>
                <BrandName>Seagills Lanka</BrandName>
                <BrandTagline>Inventory Management</BrandTagline>
              </BrandInfo>
            </LogoSection>

            <UserSection>
          <UserInfo>
            <UserName>
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </UserName>
            <UserRole>Admin</UserRole>
          </UserInfo>
          <DateText>{today}</DateText>
          <BackButton onClick={() => navigate("/admin-dashboard")}>Back</BackButton>
        </UserSection>
      </Header>
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      
      <div className="max-w-7xl mx-auto p-6">
        {/* Header Section */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Supplier Management</h1>
            <p className="text-gray-600">Manage your supplier relationships efficiently</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 mt-4 lg:mt-0">
            <button
              onClick={downloadPDF}
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-green-400 to-green-600 text-white px-6 py-3 rounded-xl hover:from-green-500 hover:to-green-700 transition-all duration-200 font-medium shadow-lg shadow-green-500/25"
            >
              <RiFilePdf2Line size={18} /> Download PDF
            </button>
            
            <button
              onClick={() => {
                setEditingSupplier(null);
                setIsModalOpen(true);
              }}
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all duration-200 font-medium shadow-lg shadow-blue-500/25"
            >
              <MdAdd size={18} /> Add Supplier
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Suppliers</p>
                <p className="text-2xl font-bold text-gray-900">{suppliers.length}</p>
              </div>
              <div className="p-3 bg-blue-100 rounded-xl">
                <FiUser className="text-blue-600" size={24} />
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Contacts</p>
                <p className="text-2xl font-bold text-gray-900">{suppliers.length}</p>
              </div>
              <div className="p-3 bg-green-100 rounded-xl">
                <MdPhone className="text-green-600" size={24} />
              </div>
            </div>
          </div>
          
          
          
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-600">Filtered</p>
                <p className="text-2xl font-bold text-gray-900">{filteredSuppliers.length}</p>
              </div>
              <div className="p-3 bg-orange-100 rounded-xl">
                <FiFilter className="text-orange-600" size={24} />
              </div>
            </div>
          </div>
        </div>

        {/* Filter Bar */}
        <FilterBar filters={filters} onFilterChange={handleFilterChange} onSearch={handleSearch} />

        {/* Suppliers Table */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-to-r from-gray-50 to-gray-100">
                <tr>
                  <th className="p-4 text-left font-semibold text-gray-700">Supplier</th>
                  <th className="p-4 text-left font-semibold text-gray-700">Contact</th>
                  <th className="p-4 text-left font-semibold text-gray-700">Email</th>
                  <th className="p-4 text-left font-semibold text-gray-700">Website</th>
                  <th className="p-4 text-center font-semibold text-gray-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredSuppliers.map((supplier) => (
                  <tr key={supplier._id} className="hover:bg-gray-50 transition-colors duration-150">
                    <td className="p-4">
                      <div className="font-medium text-gray-900">{supplier.supplierName}</div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2 text-gray-600">
                        <MdPhone size={16} className="text-green-600" />
                        {supplier.contactNum}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2 text-gray-600">
                        <MdEmail size={16} className="text-blue-600" />
                        {supplier.email}
                      </div>
                    </td>
                    <td className="p-4">
                      {supplier.websiteLink ? (
                        <a 
                          href={supplier.websiteLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-blue-600 hover:text-blue-800 transition-colors duration-200"
                        >
                          <RiGlobalLine size={16} />
                          {formatWebsiteLink(supplier.websiteLink)}
                        </a>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="p-4">
                      <div className="flex justify-center gap-2">
                        <button
                          onClick={() => {
                            setEditingSupplier(supplier);
                            setIsModalOpen(true);
                          }}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-200"
                          title="Edit Supplier"
                        >
                          <RiEdit2Fill size={18} />
                        </button>
                        <button
                          onClick={() => handleDelete(supplier._id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-200"
                          title="Delete Supplier"
                        >
                          <MdDelete size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredSuppliers.length === 0 && (
                  <tr>
                    <td colSpan="5" className="p-8 text-center">
                      <div className="text-gray-500">
                        <svg className="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                        <p className="text-lg font-medium">No suppliers found</p>
                        <p className="text-sm">Try adjusting your search or add a new supplier</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modal */}
      <SupplierModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSave}
        supplier={editingSupplier}
      />
        <ToastContainer position="top-right" autoClose={3000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnFocusLoss draggable pauseOnHover theme="light" />
    </div>
    </PageContainer>
  );
};

// Styled Components
const PageContainer = styled.div`
  
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
  
`;

const Header = styled.header`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  z-index: 1000;
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const DateText = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
`;

const BackButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;


export default Supplier;