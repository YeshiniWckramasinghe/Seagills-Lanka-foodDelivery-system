// src/pages/CoordinatorDashboard.jsx
import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { useNavigate } from "react-router-dom";
import theme from "../styles/theme";
import { FaClock, FaPlay, FaCheckCircle } from "react-icons/fa";
import {
  assignedTruckAPI,
  dailyLoadingAPI,
  authAPI,
  truckRouteAPI,
  coordinatorSummaryAPI,
  preorderAPI,
  tripSummaryAPI,
} from "../services/api";

// Import Reusable Components
import Header from "../Component/Layout/Header";
import LoadingState from "../Component/common/LoadingState";
import ErrorBanner from "../Component/common/ErrorBanner";
import AssignmentCard from "../Component/dashboard/AssignmentCard";
import SummaryCard from "../Component/dashboard/SummaryCard";
import ActionsSection from "../Component/dashboard/ActionsSection";
import ActionCard from "../Component/dashboard/ActionCard";

// Import Feature Data
import { actionCards } from "../features/coordinator/CoordinatorQuickActionsData";

const CoordinatorDashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [startingRun, setStartingRun] = useState(false);

  const [dashboardData, setDashboardData] = useState({
    user: {
      name: "Loading...",
      role: "Delivery Coordinator",
    },
    assignment: {
      truck: "Not Assigned",
      route: "Not Assigned",
      driver: "Not Assigned",
      time: "Not Scheduled",
      scheduledStartTime: "Not Set",
      truckId: null,
    },
    summary: {
      completed: 0,
      total: 0,
      revenue: 0,
    },
    tripStatus: "not_assigned",
    runStarted: false,
  });

  // NEW STATUS STATES
  const [statusData, setStatusData] = useState({
    dailyLoadingCompleted: false,
    preordersExist: false,
    preordersVerified: false,
    loadingCheckInProgress: true,
  });

  // --- Side Effects and Lifecycle ---
  useEffect(() => {
    document.body.style.paddingTop = "0";
    fetchDashboardData();
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // --- Handlers and Data Fetching ---
  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);

      const userStr = localStorage.getItem("user");
      if (!userStr) {
        navigate("/login");
        return;
      }

      const user = JSON.parse(userStr);
      const coordinatorId = user.id;

      setDashboardData((prev) => ({
        ...prev,
        user: {
          name:
            `${user.firstName || ""} ${user.lastName || ""}`.trim() ||
            user.username,
          role: "Delivery Coordinator",
        },
      }));

      const today = new Date().toISOString().split("T")[0];

      // 1. Fetch combined schedule/assignment data
      const [scheduleResponse, loadingResponse] = await Promise.all([
        assignedTruckAPI
          .getCoordinatorDailySchedule(coordinatorId, today)
          .catch((err) => {
            console.error("Schedule fetch failed:", err);
            return { data: { success: false, schedule: null } };
          }),
        dailyLoadingAPI
          .getTodayLoadings()
          .catch(() => ({ data: { success: false, loadings: [] } })),
      ]);

      const dailySchedule = scheduleResponse.data.schedule;
      let currentTripStatus = "not_assigned";
      let currentTruckId = null;
      let runStarted = false;

      if (scheduleResponse.data.success && dailySchedule) {
        const rawRoute = dailySchedule.route || "No Route Set";
        const formattedRoute = rawRoute.replace(" to ", " to \n");

        currentTruckId = dailySchedule.truckId;

        // Check trip status from schedule
        if (dailySchedule.tripStatus === "completed") {
          currentTripStatus = "completed";
        } else if (
          dailySchedule.tripStatus === "in_progress" ||
          dailySchedule.tripStartedAt
        ) {
          currentTripStatus = "in_progress";
          runStarted = true;
        } else {
          currentTripStatus = "scheduled";
        }

        setDashboardData((prev) => ({
          ...prev,
          assignment: {
            truck: dailySchedule.truck || "No Truck Assigned",
            route: formattedRoute,
            driver: dailySchedule.driver || "No Driver Assigned",
            time: dailySchedule.startTime
              ? `${dailySchedule.startTime}${
                  dailySchedule.endTime
                    ? ` - ${dailySchedule.endTime}`
                    : " (Run Pending)"
                }`
              : "No Time Set",
            scheduledStartTime: dailySchedule.startTime || "Not Set",
            truckId: currentTruckId,
          },
          tripStatus: currentTripStatus,
          runStarted: runStarted,
        }));

        // NEW: Fetch status data for daily loading and preorders
        await fetchStatusData(currentTruckId, today);

        // Fetch real summary data
        try {
          const summaryResponse = await coordinatorSummaryAPI.getDailySummary(
            coordinatorId,
            today
          );

          if (summaryResponse.data.success) {
            setDashboardData((prev) => ({
              ...prev,
              summary: summaryResponse.data.summary,
            }));
          }
        } catch (summaryError) {
          console.error("Error fetching summary:", summaryError);
        }
      } else {
        setDashboardData((prev) => ({
          ...prev,
          assignment: {
            truck: "None Today",
            route: "None Today",
            driver: "None Today",
            time: "Not Scheduled",
            scheduledStartTime: "Not Set",
            truckId: null,
          },
          tripStatus: "not_assigned",
          runStarted: false,
        }));
      }
    } catch (err) {
      console.error("Error fetching dashboard data:", err);
      setError(
        err.response?.data?.message ||
          "Failed to load dashboard data. Please retry."
      );
    } finally {
      setLoading(false);
    }
  };

  const fetchStatusData = async (truckId, date) => {
    try {
      setStatusData((prev) => ({ ...prev, loadingCheckInProgress: true }));

      // Check if daily loading is completed
      const loadingResponse = await dailyLoadingAPI
        .getLoadingsByTruck(truckId)
        .catch(() => ({ data: { loadings: [] } }));

      const todayLoading = (loadingResponse.data.loadings || []).find(
        (loading) => loading.date && loading.date.split("T")[0] === date
      );

      // Check if preorders exist and their verification status
      const preorderResponse = await preorderAPI
        .getPreordersByTruck(truckId, date)
        .catch(() => ({ data: { preorders: [] } }));

      const preorders = preorderResponse.data.preorders || [];
      const preordersExist = preorders.length > 0;
      const allPreordersVerified = preordersExist
        ? preorders.every((p) => p.orderStatus === "verified")
        : true; // If no preorders, consider it verified

      setStatusData({
        dailyLoadingCompleted: !!todayLoading,
        preordersExist: preordersExist,
        preordersVerified: allPreordersVerified,
        loadingCheckInProgress: false,
      });
    } catch (err) {
      console.error("Error fetching status data:", err);
      setStatusData((prev) => ({ ...prev, loadingCheckInProgress: false }));
    }
  };

  // Handle Start Daily Run
  const handleStartDailyRun = async () => {
    if (!dashboardData.assignment.truckId) {
      alert("No truck assignment found. Please contact administrator.");
      return;
    }

    if (dashboardData.runStarted) {
      alert("Daily run has already been started.");
      return;
    }

    try {
      setStartingRun(true);
      const today = new Date().toISOString().split("T")[0];

      const response = await truckRouteAPI.startDailyRun({
        truckID: dashboardData.assignment.truckId,
        date: today,
      });

      if (response.data.success) {
        alert("Daily run started successfully!");
        await fetchDashboardData();
      }
    } catch (err) {
      console.error("Error starting daily run:", err);
      alert(
        err.response?.data?.message ||
          "Failed to start daily run. Please try again."
      );
    } finally {
      setStartingRun(false);
    }
  };

  const handleSignOut = () => {
    authAPI.logout();
    navigate("/login");
  };

  const handleActionClick = async (path) => {
    // Check for trip assignment
    if (!dashboardData.assignment.truckId) {
      alert(
        "You must be assigned a truck for today's run to perform trip actions. If assigned, please refresh."
      );
      return;
    }

    // Daily Loading can only be completed after preorders are verified (if any exist)
    if (path === "/coordinator/daily-loading") {
      if (statusData.preordersExist && !statusData.preordersVerified) {
        alert(
          "Please verify all pre-orders first before completing daily loading."
        );
        return;
      }
      navigate(path);
      return;
    }

    // Start Daily Run button can be clicked only after daily loading is completed
    if (
      path === "/coordinator/en-route-orders" ||
      path === "/coordinator/pre-orders" ||
      path === "/coordinator/record-incident"
    ) {
      if (!statusData.dailyLoadingCompleted) {
        alert("Please complete daily loading first.");
        return;
      }

      if (!dashboardData.runStarted) {
        alert(
          "Please start the daily run first by clicking the 'Start Daily Run' button."
        );
        return;
      }

      navigate(path);
      return;
    }

    // Close trip can only be opened if daily run is started
    if (path === "/coordinator/close-trip") {
      if (dashboardData.tripStatus === "completed") {
        alert(
          "The trip for today is already closed. Please view the Trip Report."
        );
        return;
      }

      if (!dashboardData.runStarted) {
        alert(
          "Please start the daily run first by clicking the 'Start Daily Run' button."
        );
        return;
      }

      navigate(path);
      return;
    }

    // Verify Pre-Orders page
    if (path === "/coordinator/verify-orders") {
      navigate(path);
      return;
    }

    // Trip Report - Fetch the trip summary and navigate with ID
    if (path === "/coordinator/trip-report") {
      if (dashboardData.tripStatus !== "completed") {
        alert(
          "The trip is still in progress. The final report is available only after closing the trip."
        );
        return;
      }

      try {
        const today = new Date().toISOString().split("T")[0];
        const response = await tripSummaryAPI.getTripSummaryByTruckAndDate(
          dashboardData.assignment.truckId,
          today
        );

        if (response.data.tripSummary && response.data.tripSummary._id) {
          navigate(`/trip-report/${response.data.tripSummary._id}`);
        } else {
          alert("Trip summary not found. Please try again.");
        }
      } catch (err) {
        alert(
          "Error loading trip report: " + err.response?.data?.message ||
            err.message
        );
      }
      return;
    }

    // Default action
    navigate(path);
  };

  // Utility for time formatting
  const formattedTime = currentTime.toLocaleString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  // Helper function to determine if Start Daily Run button should be enabled
  const isStartDailyRunDisabled = () => {
    return (
      !statusData.dailyLoadingCompleted ||
      dashboardData.runStarted ||
      startingRun ||
      statusData.loadingCheckInProgress
    );
  };

  // Helper function to get Start Daily Run button tooltip/message
  const getStartDailyRunMessage = () => {
    if (statusData.loadingCheckInProgress) {
      return "Loading status...";
    }
    if (!statusData.dailyLoadingCompleted) {
      return "Complete daily loading first";
    }
    if (dashboardData.runStarted) {
      return "Daily run already started";
    }
    return "Start Daily Run";
  };

  // --- Render Functions ---
  if (loading) {
    return <LoadingState text="Loading coordinator dashboard..." />;
  }

  return (
    <DashboardContainer>
      <Header onSignOut={handleSignOut} />

      <MainContent>
        {error && <ErrorBanner message={error} onRetry={fetchDashboardData} />}

        {/* Welcome and Time Section */}
        <WelcomeSection>
          <WelcomeText>
            <WelcomeTitle>Welcome, {dashboardData.user.name}</WelcomeTitle>
            <WelcomeSubtitle>{dashboardData.user.role}</WelcomeSubtitle>
          </WelcomeText>
          <TimeDisplay>
            <FaClock />
            <TimeText>{formattedTime}</TimeText>
          </TimeDisplay>
        </WelcomeSection>

        {/* Trip Status Banner */}
        {dashboardData.tripStatus === "completed" && (
          <StatusBanner $type="success">
            <FaCheckCircle />
            <span>
              Daily run completed successfully! View your trip report in Actions
              below.
            </span>
          </StatusBanner>
        )}

        <AssignmentCard
          assignment={dashboardData.assignment}
          scheduledStartTime={dashboardData.assignment.scheduledStartTime}
        />

        {/* Status Information */}
        <StatusInfoSection>
          <StatusItem $completed={statusData.preordersVerified}>
            <StatusIndicator $completed={statusData.preordersVerified} />
            <StatusText>
              {statusData.preordersExist
                ? statusData.preordersVerified
                  ? "✓ Pre-orders Verified"
                  : "⚠ Pre-orders Pending Verification"
                : "- No Pre-orders Today"}
            </StatusText>
          </StatusItem>
          <StatusItem $completed={statusData.dailyLoadingCompleted}>
            <StatusIndicator $completed={statusData.dailyLoadingCompleted} />
            <StatusText>
              {statusData.dailyLoadingCompleted
                ? "✓ Daily Loading Completed"
                : "⚠ Daily Loading Pending"}
            </StatusText>
          </StatusItem>
        </StatusInfoSection>

        {/* Start Daily Run Button */}
        {dashboardData.tripStatus !== "not_assigned" &&
          dashboardData.tripStatus !== "completed" && (
            <StartRunSection>
              <StartRunButton
                onClick={handleStartDailyRun}
                disabled={isStartDailyRunDisabled()}
                $started={dashboardData.runStarted}
                title={getStartDailyRunMessage()}
              >
                {startingRun ? (
                  "Starting..."
                ) : dashboardData.runStarted ? (
                  <>
                    <FaCheckCircle /> Daily Run Started
                  </>
                ) : (
                  <>
                    <FaPlay /> Start Daily Run
                  </>
                )}
              </StartRunButton>
              {!statusData.dailyLoadingCompleted && (
                <StartRunNote $disabled={true}>
                  Daily loading must be completed before starting the run.
                </StartRunNote>
              )}
              {dashboardData.runStarted && (
                <StartRunNote>
                  Run started successfully. You can now proceed with deliveries
                  and close the trip when complete.
                </StartRunNote>
              )}
            </StartRunSection>
          )}

        <ActionsContainer>
          <SectionTitle>Actions</SectionTitle>
          <ActionsGrid>
            {actionCards.map((action, index) => (
              <ActionCard
                key={index}
                icon={action.icon}
                title={action.title}
                onClick={() => handleActionClick(action.path)}
                color={action.color}
              />
            ))}
          </ActionsGrid>
        </ActionsContainer>

        <SummaryCard summary={dashboardData.summary} />
      </MainContent>
    </DashboardContainer>
  );
};

// Styled Components
const DashboardContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
  padding-top: 0 !important;
  margin-top: 0 !important;
`;

const MainContent = styled.main`
  max-width: 1400px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const WelcomeSection = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${theme.spacing.xl};

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: flex-start;
    gap: ${theme.spacing.md};
  }
`;

const WelcomeText = styled.div``;

const WelcomeTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0 0 ${theme.spacing.xs};
`;

const WelcomeSubtitle = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.lg};
  margin: 0;
`;

const TimeDisplay = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};

  svg {
    color: ${theme.colors.primary};
  }
`;

const TimeText = styled.span`
  font-weight: ${theme.typography.fontWeight.medium};
`;

const StatusBanner = styled.div`
  background: ${(props) =>
    props.$type === "success"
      ? "linear-gradient(135deg, #4caf50 0%, #66bb6a 100%)"
      : "linear-gradient(135deg, #ff9800 0%, #ffa726 100%)"};
  color: white;
  padding: ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.lg};
  margin-bottom: ${theme.spacing.xl};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);

  svg {
    font-size: ${theme.typography.fontSize.xl};
  }
`;

const StatusInfoSection = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${theme.spacing.md};
  margin-bottom: ${theme.spacing.xl};
`;

const StatusItem = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  padding: ${theme.spacing.md} ${theme.spacing.lg};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  border-left: 4px solid
    ${(props) => (props.$completed ? "#4CAF50" : "#FF9800")};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const StatusIndicator = styled.div`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: ${(props) => (props.$completed ? "#4CAF50" : "#FF9800")};
  flex-shrink: 0;
`;

const StatusText = styled.span`
  color: ${theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.medium};
  font-size: ${theme.typography.fontSize.base};
`;

const StartRunSection = styled.div`
  margin-bottom: ${theme.spacing.xl};
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: ${theme.spacing.md};
`;

const StartRunButton = styled.button`
  background: ${(props) =>
    props.$started
      ? "linear-gradient(135deg, #4caf50 0%, #66bb6a 100%)"
      : "linear-gradient(135deg, #FF5722 0%, #FF7043 100%)"};
  color: ${theme.colors.white};
  border: none;
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.lg};
  font-weight: ${theme.typography.fontWeight.bold};
  font-size: ${theme.typography.fontSize.lg};
  cursor: ${(props) => (props.disabled ? "not-allowed" : "pointer")};
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  opacity: ${(props) => (props.disabled && !props.$started ? 0.6 : 1)};

  &:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px ${theme.colors.shadowMedium};
  }

  svg {
    font-size: ${theme.typography.fontSize.xl};
  }
`;

const StartRunNote = styled.p`
  color: ${(props) => (props.$disabled ? "#FF9800" : "#4CAF50")};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
  text-align: center;
  margin: 0;
`;

const ActionsContainer = styled.div`
  margin-bottom: ${theme.spacing.xl};
`;

const SectionTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
`;

const ActionsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: ${theme.spacing.lg};
`;

export default CoordinatorDashboard;
