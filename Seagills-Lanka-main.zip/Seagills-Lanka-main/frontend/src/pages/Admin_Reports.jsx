// src/pages/Admin_Reports.jsx

import React, { useEffect } from "react";
import styled from "styled-components";
import { useNavigate } from "react-router-dom";
import theme from "../styles/theme";
import { FileText, TruckIcon, ClipboardList } from "lucide-react";
import { FaTruck } from "react-icons/fa";

const AdminReports = () => {
  const navigate = useNavigate();

  useEffect(() => {
    document.body.style.paddingTop = "0";
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, []);

  const reportCategories = [
    {
      id: "daily-truck",
      title: "Daily Truck Assignment Report",
      description:
        "View trucks assigned today, their routes, and statuses with PDF export",
      icon: TruckIcon,
      color: theme.colors.primary,
      onClick: () => navigate("/admin-reports/daily-truck"),
    },
    {
      id: "enroute",
      title: "Enroute Order Report",
      description:
        "View real-time status and details of orders currently in transit",
      icon: TruckIcon,
      color: theme.colors.primary,
      onClick: () => navigate("/admin-reports/enroute"),
    },
    {
      id: "preorder",
      title: "Preorder Report",
      description:
        "Analyze scheduled orders and upcoming delivery requirements",
      icon: ClipboardList,
      color: theme.colors.success,
      onClick: () => navigate("/admin-reports/preorder"),
    },
  ];

  return (
    <PageContainer>
      <Header>
        <LogoSection onClick={() => navigate("/admin-dashboard")}>
          <Logo>
            <FaTruck />
          </Logo>
          <BrandInfo>
            <BrandName>Seagills Lanka</BrandName>
            <BrandTagline>Delivery Management</BrandTagline>
          </BrandInfo>
        </LogoSection>

        <UserSection>
          <UserInfo>
            <UserName>
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </UserName>
            <UserRole>Admin</UserRole>
          </UserInfo>
          <BackButton onClick={() => navigate("/admin-dashboard")}>
            Back
          </BackButton>
        </UserSection>
      </Header>

      <MainContent>
        <PageHeader>
          <div>
            <PageTitle>Reports</PageTitle>
            <PageSubtitle>
              Access comprehensive reports and analytics for your delivery
              operations
            </PageSubtitle>
          </div>
        </PageHeader>

        <ReportsGrid>
          {reportCategories.map((report) => {
            const Icon = report.icon;
            return (
              <ReportCard key={report.id} onClick={report.onClick}>
                <IconWrapper color={report.color}>
                  <Icon size={32} />
                </IconWrapper>
                <ReportContent>
                  <ReportTitle>{report.title}</ReportTitle>
                  <ReportDescription>{report.description}</ReportDescription>
                </ReportContent>
                <ViewButton
                  onClick={() => {
                    if (report.id === "preorder") {
                      navigate("/admin/preorder-report"); // Preorder Report page
                    } else if (report.id === "enroute") {
                      navigate("/admin/enroute-report"); // Enroute Orders page
                    } else if (report.id === "truck-route") {
                      navigate("/admin/truck-route-report"); // Truck Route Report page
                    }
                  }}
                >
                View Report →
                </ViewButton>
              </ReportCard>
            );
          })}
        </ReportsGrid>
      </MainContent>
    </PageContainer>
  );
};

// Styled Components
const PageContainer = styled.div`
  min-height: 100vh;
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
`;

const Header = styled.header`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${theme.colors.primary};
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const BackButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const MainContent = styled.main`
  max-width: 1400px;
  margin: 0 auto;
  padding: ${theme.spacing.xl};
`;

const PageHeader = styled.div`
  margin-bottom: ${theme.spacing.xl};
`;

const PageTitle = styled.h2`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize["3xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0 0 ${theme.spacing.xs};
`;

const PageSubtitle = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
  margin: 0;
  max-width: 600px;
`;

const ReportsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: ${theme.spacing.lg};
  margin-top: ${theme.spacing.xl};

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const ReportCard = styled.div`
  background: ${theme.colors.white};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.lg};
  padding: ${theme.spacing.xl};
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  gap: ${theme.spacing.md};

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 10px 25px ${theme.colors.shadowMedium};
    border-color: ${theme.colors.primary};
  }
`;

const IconWrapper = styled.div`
  width: 64px;
  height: 64px;
  border-radius: ${theme.borderRadius.lg};
  background: ${(props) => `${props.color}15`};
  color: ${(props) => props.color};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: ${theme.spacing.sm};
`;

const ReportContent = styled.div`
  flex: 1;
`;

const ReportTitle = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.sm};
`;

const ReportDescription = styled.p`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
  line-height: 1.5;
`;

const ViewButton = styled.div`
  color: ${theme.colors.primary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.xs};
  margin-top: ${theme.spacing.sm};
`;

export default AdminReports;
