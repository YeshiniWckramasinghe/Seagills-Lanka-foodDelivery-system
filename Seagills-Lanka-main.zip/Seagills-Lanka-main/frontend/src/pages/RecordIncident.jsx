// frontend/src/pages/RecordIncident.jsx
import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { useNavigate } from "react-router-dom";
import {
  FaExclamationTriangle,
  FaCheckCircle,
  FaTruck,
  FaUser,
  FaCalendarAlt,
} from "react-icons/fa";
import theme from "../styles/theme";
import Modal from "../Component/Modal";
import LoadingState from "../Component/common/LoadingState";
import PageLayout from "../Component/Layout/PageLayout";
import { assignedTruckAPI, incidentAPI } from "../services/api";

const SEVERITY_OPTIONS = ["low", "medium", "high", "critical"];
const INCIDENT_TYPE_OPTIONS = ["breakdown", "delay", "accident", "other"];

const RecordIncident = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [assignment, setAssignment] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [runNotStartedModal, setRunNotStartedModal] = useState(false);

  const [formData, setFormData] = useState({
    incidentType: INCIDENT_TYPE_OPTIONS[0],
    description: "",
    location: "",
    incidentTime: new Date().toISOString().substring(0, 16), // YYYY-MM-DDTHH:MM
    durationInMinutes: "",
    cause: "",
    severity: SEVERITY_OPTIONS[1],
  });

  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  // Data Fetching Logic
  useEffect(() => {
    fetchAssignmentData();
  }, []);

  useEffect(() => {
    document.body.style.paddingTop = "0";
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, []);

  const fetchAssignmentData = async () => {
    const userStr = localStorage.getItem("user");
    if (!userStr) {
      navigate("/login");
      return;
    }
    const user = JSON.parse(userStr);
    const coordinatorId = user.id;
    const today = new Date().toISOString().split("T")[0];

    try {
      setLoading(true);
      const response = await assignedTruckAPI.getCoordinatorDailySchedule(
        coordinatorId,
        today
      );

      if (response.data.success && response.data.schedule) {
        const schedule = response.data.schedule;

        if (!schedule.truckId) {
          throw new Error(
            "Truck ID missing from assignment data. Cannot record incident."
          );
        }

        setAssignment({
          truckID: schedule.truckId,
          coordinatorID: coordinatorId,
          tripDate: today,
          truckPlate: schedule.truck,
          driverName: schedule.driver,
        });

        // ADD THIS CHECK HERE - in the success path
        if (!schedule.tripStartedAt) {
          setRunNotStartedModal(true);
        }
      } else {
        setModal({
          isOpen: true,
          type: "error",
          title: "No Active Assignment",
          message:
            "You must have an assigned truck for today to record an incident.",
        });
        setAssignment(null);
      }
    } catch (err) {
      console.error("Error fetching assignment:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Data Error",
        message: err.message || "Failed to load truck assignment details.",
      });
      setAssignment(null);
    } finally {
      setLoading(false);
    }
  };

  // --- Form Handlers ---
  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!assignment) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Missing Data",
        message: "Cannot submit: No active truck assignment found.",
      });
      return;
    }

    if (isSubmitting) return;
    setIsSubmitting(true);

    const submissionData = {
      truckID: assignment.truckID,
      coordinatorID: assignment.coordinatorID,
      tripDate: assignment.tripDate,
      ...formData,
      incidentTime: new Date(formData.incidentTime).toISOString(),
      durationInMinutes: formData.durationInMinutes
        ? parseInt(formData.durationInMinutes)
        : undefined,
    };

    try {
      const response = await incidentAPI.recordIncident(submissionData);

      if (response.data.success) {
        setModal({
          isOpen: true,
          type: "success",
          title: "Incident Recorded",
          message:
            "The incident has been successfully reported to the administration.",
        });
        setFormData({
          incidentType: INCIDENT_TYPE_OPTIONS[0],
          description: "",
          location: "",
          incidentTime: new Date().toISOString().substring(0, 16),
          durationInMinutes: "",
          cause: "",
          severity: SEVERITY_OPTIONS[1],
        });
        // Optional: Redirect back to dashboard after success
        // setTimeout(() => navigate("/coordinator-dashboard"), 1500);
      } else {
        throw new Error(response.data.message || "Failed to record incident.");
      }
    } catch (err) {
      console.error("Submission Error:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Submission Failed",
        message:
          err.response?.data?.message ||
          err.message ||
          "An unexpected error occurred while recording the incident.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return <LoadingState text="Checking active assignment..." />;
  }

  return (
    <PageLayout
      pageTitle="Record Trip Incident"
      pageSubtitle="Report breakdowns, delays, or accidents during the run"
      icon={<FaExclamationTriangle />}
    >
      <Modal
        isOpen={runNotStartedModal}
        onClose={() => {
          setRunNotStartedModal(false);
          navigate("/coordinator-dashboard");
        }}
        type="warning"
        title="Run Not Started"
        message="Please ensure the 'Start Daily Run' button was clicked on the dashboard before recording an incident."
      />

      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      <AssignmentInfoCard $assigned={!!assignment}>
        <InfoItem>
          <FaTruck /> Truck: <span>{assignment?.truckPlate || "N/A"}</span>
        </InfoItem>
        <InfoItem>
          <FaUser /> Driver: <span>{assignment?.driverName || "N/A"}</span>
        </InfoItem>
        <InfoItem>
          <FaCalendarAlt /> Trip Date:{" "}
          <span>{assignment?.tripDate || "N/A"}</span>
        </InfoItem>
      </AssignmentInfoCard>

      {assignment ? (
        <FormCard onSubmit={handleSubmit}>
          <SectionHeader>
            <FaExclamationTriangle /> Incident Details
          </SectionHeader>

          <FormGrid>
            <FormGroup>
              <Label htmlFor="incidentType">
                Incident Type <Required>*</Required>
              </Label>
              <Select
                id="incidentType"
                name="incidentType"
                value={formData.incidentType}
                onChange={handleInputChange}
                required
              >
                {INCIDENT_TYPE_OPTIONS.map((type) => (
                  <option key={type} value={type}>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </option>
                ))}
              </Select>
            </FormGroup>

            <FormGroup>
              <Label htmlFor="incidentTime">
                Time of Incident <Required>*</Required>
              </Label>
              <Input
                id="incidentTime"
                type="datetime-local"
                name="incidentTime"
                value={formData.incidentTime}
                onChange={handleInputChange}
                max={new Date().toISOString().substring(0, 16)}
                required
              />
            </FormGroup>

            <FullWidthGroup>
              <Label htmlFor="location">
                Location / Road Name <Required>*</Required>
              </Label>
              <Input
                id="location"
                type="text"
                name="location"
                value={formData.location}
                onChange={handleInputChange}
                required
              />
            </FullWidthGroup>

            <FormGroup>
              <Label htmlFor="durationInMinutes">Duration (Minutes)</Label>
              <Input
                id="durationInMinutes"
                type="number"
                name="durationInMinutes"
                value={formData.durationInMinutes}
                onChange={handleInputChange}
                min="1"
                placeholder="Time lost due to incident"
              />
            </FormGroup>

            <FormGroup>
              <Label htmlFor="severity">Severity</Label>
              <Select
                id="severity"
                name="severity"
                value={formData.severity}
                onChange={handleInputChange}
              >
                {SEVERITY_OPTIONS.map((sev) => (
                  <option key={sev} value={sev}>
                    {sev.charAt(0).toUpperCase() + sev.slice(1)}
                  </option>
                ))}
              </Select>
            </FormGroup>

            <FullWidthGroup>
              <Label htmlFor="cause">Immediate Cause</Label>
              <Textarea
                id="cause"
                name="cause"
                value={formData.cause}
                onChange={handleInputChange}
                placeholder="E.g., Engine overheating, tire puncture, heavy traffic."
                rows="2"
              />
            </FullWidthGroup>

            <FullWidthGroup>
              <Label htmlFor="description">
                Detailed Description <Required>*</Required>
              </Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                required
                rows="4"
                placeholder="Provide a detailed account of what happened and any actions taken."
              />
            </FullWidthGroup>
          </FormGrid>

          <ButtonGroup>
            <SubmitButton type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                "Recording..."
              ) : (
                <>
                  <FaCheckCircle /> Record Incident
                </>
              )}
            </SubmitButton>
          </ButtonGroup>
        </FormCard>
      ) : (
        <EmptyState>
          <p>
            Incident recording is disabled without an active daily assignment.
          </p>
        </EmptyState>
      )}
    </PageLayout>
  );
};

// --- Styled Components ---

const FormCard = styled.form`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  margin-top: ${theme.spacing.xl};
`;

const SectionHeader = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  svg {
    color: ${theme.colors.error};
  }
`;

const FormGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(
    auto-fit,
    minmax(250px, 1fr)
  ); /* Adjusted minmax for flexible layout */
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.lg};
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
`;

const FullWidthGroup = styled(FormGroup)`
  grid-column: 1 / -1;
`;

const Label = styled.label`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.sm};
  display: flex;
  align-items: center;
`;

const Required = styled.span`
  color: ${theme.colors.error};
  margin-left: 4px;
`;

const Input = styled.input`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};

  &:focus {
    outline: none;
    border-color: ${theme.colors.error};
    box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.1);
  }
`;

const Select = styled(Input).attrs({ as: "select" })``;

const Textarea = styled(Input).attrs({ as: "textarea" })`
  resize: vertical;
  min-height: 80px;
`;

const ButtonGroup = styled.div`
  /* Match DailyLoading ButtonGroup style */
  display: flex;
  justify-content: flex-end;
  gap: ${theme.spacing.md};
  margin-top: ${theme.spacing.xl};
`;

const SubmitButton = styled.button`
  background: ${theme.colors.error};
  color: ${theme.colors.white};
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  &:hover:not(:disabled) {
    background: #d32f2f;
    transform: translateY(-2px);
    box-shadow: 0 8px 16px ${theme.colors.shadowMedium};
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

// --- Assignment Info Card Styles ---

const AssignmentInfoCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  padding: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.xl};
  box-shadow: 0 1px 4px ${theme.colors.shadow};
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  gap: ${theme.spacing.md};
`;

const InfoItem = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.base};
  font-weight: ${theme.typography.fontWeight.medium};

  svg {
    color: ${theme.colors.primary};
  }
  span {
    font-weight: ${theme.typography.fontWeight.semibold};
  }
`;

const EmptyState = styled.div`
  text-align: center;
  padding: ${theme.spacing.xl};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  color: ${theme.colors.textSecondary};
`;

export default RecordIncident;
