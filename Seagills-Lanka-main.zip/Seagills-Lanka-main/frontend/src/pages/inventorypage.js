// src/pages/Inventory.js

import React, { useState, useEffect } from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { FaTruck } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import {
  MdInventory,
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdCategory,
  MdAttachMoney,
  MdNumbers,
  MdContentCopy,
  MdQrCode,
  MdDownload,
} from "react-icons/md";
import { FaBarcode } from "react-icons/fa6";
import { toast } from "react-toastify";
import axios from "axios";
import { ToastContainer } from "react-toastify";
import JsBarcode from "jsbarcode";
import html2canvas from "html2canvas";

const Inventory = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [isGeneratingSKU, setIsGeneratingSKU] = useState(false);
  const [isGeneratingBarcode, setIsGeneratingBarcode] = useState(false);
  const [formData, setFormData] = useState({
    productName: "",
    category: "",
    price: "",
    description: "",
    sku: "",
  });

  // Fetch products
  const fetchProducts = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/inventory");
      setProducts(response.data);
      setFilteredProducts(response.data);
    } catch (error) {
      toast.error("Error fetching products");
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  // Generate SKU automatically
  const generateSKU = async () => {
    if (!formData.productName || !formData.category) {
      toast.error("Please enter product name and category first");
      return;
    }

    setIsGeneratingSKU(true);
    try {
      const response = await axios.get(
        "http://localhost:5000/api/inventory/generate-sku",
        {
          params: {
            productName: formData.productName,
            category: formData.category,
          },
        }
      );
      setFormData((prev) => ({
        ...prev,
        sku: response.data.sku,
      }));
      toast.success("SKU generated successfully!");
    } catch (error) {
      toast.error("Error generating SKU");
    } finally {
      setIsGeneratingSKU(false);
    }
  };

  // Generate and download barcode
  const generateBarcode = async (product) => {
    setIsGeneratingBarcode(true);
    try {
      // Create a temporary canvas for barcode generation
      const canvas = document.createElement("canvas");
      JsBarcode(canvas, product.sku, {
        format: "CODE128",
        width: 2,
        height: 60,
        displayValue: true,
        fontSize: 14,
        margin: 10,
      });

      // Create barcode sticker container
      const stickerContainer = document.createElement("div");
      stickerContainer.style.cssText = `
        width: 300px;
        padding: 20px;
        background: white;
        border: 2px solid #000;
        border-radius: 8px;
        text-align: center;
        font-family: Arial, sans-serif;
        box-sizing: border-box;
      `;

      // Company/Store header
      const header = document.createElement("div");
      header.style.cssText = `
        font-size: 16px;
        font-weight: bold;
        margin-bottom: 10px;
        color: #333;
      `;
      header.textContent = "SEAGILLS LANKA";

      // Product name
      const productName = document.createElement("div");
      productName.style.cssText = `
        font-size: 14px;
        font-weight: bold;
        margin-bottom: 8px;
        color: #555;
      `;
      productName.textContent = product.productName;

      // Category
      const category = document.createElement("div");
      category.style.cssText = `
        font-size: 12px;
        margin-bottom: 8px;
        color: #666;
      `;
      category.textContent = product.category;

      // Price
      const price = document.createElement("div");
      price.style.cssText = `
        font-size: 14px;
        font-weight: bold;
        margin-bottom: 10px;
        color: #e53e3e;
      `;

      // Barcode image
      const barcodeImg = document.createElement("img");
      barcodeImg.src = canvas.toDataURL();
      barcodeImg.style.cssText = `
        max-width: 100%;
        height: auto;
        margin: 5px 0;
      `;

      // SKU text
      const skuText = document.createElement("div");
      skuText.style.cssText = `
        font-size: 12px;
        margin-top: 5px;
        color: #333;
        font-family: monospace;
      `;
      skuText.textContent = `SKU: ${product.sku}`;

      // Assemble the sticker
      stickerContainer.appendChild(header);
      stickerContainer.appendChild(productName);
      stickerContainer.appendChild(category);
      stickerContainer.appendChild(price);
      stickerContainer.appendChild(barcodeImg);
      stickerContainer.appendChild(skuText);

      // Add to DOM temporarily
      document.body.appendChild(stickerContainer);

      // Convert to image and download
      const stickerCanvas = await html2canvas(stickerContainer, {
        scale: 2,
        backgroundColor: "#ffffff",
      });

      // Create download link
      const link = document.createElement("a");
      link.download = `barcode-${product.sku}.png`;
      link.href = stickerCanvas.toDataURL("image/png");
      link.click();

      // Clean up
      document.body.removeChild(stickerContainer);

      toast.success("Barcode sticker downloaded successfully!");
    } catch (error) {
      console.error("Error generating barcode:", error);
      toast.error("Error generating barcode sticker");
    } finally {
      setIsGeneratingBarcode(false);
    }
  };

  // Generate barcode for new product after adding
  const generateBarcodeForNewProduct = async (
    sku,
    productName,
    category,
    price
  ) => {
    try {
      const product = { sku, productName, category, price };
      await generateBarcode(product);
    } catch (error) {
      console.error("Error generating barcode for new product:", error);
    }
  };

  // Copy SKU to clipboard
  const copyToClipboard = (sku) => {
    navigator.clipboard.writeText(sku);
    toast.success("SKU copied to clipboard!");
  };

  // Search functionality
  useEffect(() => {
    const filtered = products.filter(
      (product) =>
        product.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredProducts(filtered);
  }, [searchTerm, products]);

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    // Auto-generate SKU when product name or category changes
    if (
      (name === "productName" || name === "category") &&
      value &&
      !editingProduct
    ) {
      // Debounce the SKU generation
      setTimeout(() => {
        if (formData.productName && formData.category && !formData.sku) {
          generateSKU();
        }
      }, 1000);
    }
  };

  // Add new product
  const handleAddProduct = async (e) => {
    e.preventDefault();
    if (!formData.sku) {
      toast.error("Please generate SKU first");
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost:5000/api/inventory",
        formData
      );
      toast.success("Product added successfully!");

      // Generate barcode for the new product
      await generateBarcodeForNewProduct(
        formData.sku,
        formData.productName,
        formData.category,
        formData.price
      );

      setIsModalOpen(false);
      resetForm();
      fetchProducts();
    } catch (error) {
      if (error.response?.data?.message === "SKU already exists") {
        toast.error("SKU already exists. Please generate a new one.");
      } else {
        toast.error("Error adding product");
      }
    }
  };

  // Update product
  const handleUpdateProduct = async (e) => {
    e.preventDefault();
    try {
      await axios.put(
        `http://localhost:5000/api/inventory/${editingProduct._id}`,
        formData
      );
      toast.success("Product updated successfully!");
      setIsModalOpen(false);
      resetForm();
      fetchProducts();
    } catch (error) {
      toast.error("Error updating product");
    }
  };

  // Delete product
  const handleDeleteProduct = async (id) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      try {
        await axios.delete(`http://localhost:5000/api/inventory/${id}`);
        toast.success("Product deleted successfully!");
        fetchProducts();
      } catch (error) {
        toast.error("Error deleting product");
      }
    }
  };

  // Edit product
  const handleEdit = (product) => {
    setEditingProduct(product);
    setFormData({
      productName: product.productName,
      category: product.category,
      price: product.price,
      description: product.description,
      sku: product.sku,
    });
    setIsModalOpen(true);
  };

    const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  // Reset form
  const resetForm = () => {
    setFormData({
      productName: "",
      category: "",
      price: "",
      description: "",
      sku: "",
    });
    setEditingProduct(null);
    setIsGeneratingSKU(false);
  };

  // Calculate total value
  const totalValue = products.reduce(
    (total, product) => total + product.price * (product.quantity || 0),
    0
  );

  return (
    <PageContainer>
          <Header>
            <LogoSection onClick={() => navigate("/admin-dashboard")}>
              <Logo>
                <FaTruck color={theme.colors.primary} />
              </Logo>
              <BrandInfo>
                <BrandName>Seagills Lanka</BrandName>
                <BrandTagline>Inventory Management</BrandTagline>
              </BrandInfo>
            </LogoSection>

            <UserSection>
          <UserInfo>
            <UserName>
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </UserName>
            <UserRole>Admin</UserRole>
          </UserInfo>
          <DateText>{today}</DateText>
          <BackButton onClick={() => navigate("/admin-dashboard")}>Back</BackButton>
        </UserSection>
      </Header>
    
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">
              Inventory Management
            </h1>
            <p className="text-gray-600">
              Manage your Company's items inventory
            </p>
          </div>
          
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Total Items</p>
              <p className="text-2xl font-bold text-gray-800">
                {products.length}
              </p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <MdInventory className="text-blue-600 text-xl" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            
            <div>
              <p className="text-gray-600 text-sm">Total Categories</p>
              <p className="text-2xl font-bold text-gray-800">
                {[...new Set(products.map((p) => p.category))].length}
              </p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <MdCategory className="text-green-600 text-xl" />
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
        <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
          <div className="relative flex-1 max-w-md">
            <MdSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search products by name, category, or SKU..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div className="-mr-96">
          
          </div>
          <div className="flex gap-2">
            
            <button
            onClick={() => {
              resetForm();
              setIsModalOpen(true);
            }}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <MdAdd size={20} />
            Add New Item
          </button>
          </div>
          
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Item Name
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  SKU
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Category
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Price
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredProducts.map((product) => (
                <tr
                  key={product._id}
                  className="hover:bg-gray-50 transition-colors"
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {product.productName}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded border">
                        {product.sku}
                      </code>
                      <button
                        onClick={() => copyToClipboard(product.sku)}
                        className="text-gray-400 hover:text-gray-600 transition-colors"
                        title="Copy SKU"
                      >
                        <MdContentCopy size={14} />
                      </button>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {product.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    Rs . {product.price}
                  </td>
                  <td className="px-6 py-4  text-sm font-medium items-center">
                    <div
                      className="flex   gap-3 "
                    >
                      <button
                        onClick={() => generateBarcode(product)}
                        disabled={isGeneratingBarcode}
                        className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-green-600 
               bg-green-200 hover:bg-green-400 hover:shadow-md hover:text-white active:scale-95 
               transition-all rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                        title="Download Barcode Sticker"
                      >
                        <FaBarcode size={18} />
                        <span>Barcode</span>
                      </button>

                      <button
                        onClick={() => handleEdit(product)}
                        className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-blue-600 
               bg-blue-200 hover:bg-blue-400 hover:shadow-md hover:text-white active:scale-95 
               transition-all rounded-lg"
                        title="Edit Product"
                      >
                        <MdEdit size={18} />
                        <span>Edit</span>
                      </button>

                      <button
                        onClick={() => handleDeleteProduct(product._id)}
                        className="flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-red-600 
               bg-red-200 hover:bg-red-400 hover:shadow-md hover:text-white active:scale-95 
               transition-all rounded-lg"
                        title="Delete Product"
                      >
                        <MdDelete size={18} />
                        <span>Delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <MdInventory className="mx-auto text-4xl text-gray-300 mb-4" />
              <p className="text-gray-500 text-lg">No Items found</p>
              <p className="text-gray-400 text-sm mt-2">
                {searchTerm
                  ? "Try adjusting your search terms"
                  : "Add your first product to get started"}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800">
                {editingProduct ? "Edit Product" : "Add New Product"}
              </h2>
            </div>
            <form
              onSubmit={editingProduct ? handleUpdateProduct : handleAddProduct}
              className="p-6 space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Item Name *
                  </label>
                  <input
                    type="text"
                    name="productName"
                    value={formData.productName}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter product name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Category *
                  </label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select Category</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Clothing">Clothing</option>
                    <option value="Computers">Computers</option>
                    <option value="Home & Garden">Home & Garden</option>
                    <option value="Furnitures">Furnitures</option>
                    <option value="Stationary">Stationary</option>
                    <option value="Automotive">Automotive</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    SKU *
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      name="sku"
                      value={formData.sku}
                      onChange={handleInputChange}
                      required
                      readOnly={!!editingProduct}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-50"
                      placeholder="SKU will be auto-generated"
                    />
                    {!editingProduct && (
                      <button
                        type="button"
                        onClick={generateSKU}
                        disabled={
                          isGeneratingSKU ||
                          !formData.productName ||
                          !formData.category
                        }
                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2"
                      >
                        {isGeneratingSKU ? "Generating..." : "Generate"}
                      </button>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {editingProduct
                      ? "SKU cannot be changed for existing products"
                      : "SKU will be automatically generated based on product name and category"}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Price ( Rs ) *
                  </label>
                  <input
                    type="number"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    required
                    min="0"
                    step="0.01"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows="3"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div className="flex justify-end gap-4 pt-6 border-t border-gray-200">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    resetForm();
                  }}
                  className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                >
                  {editingProduct
                    ? "Update Product"
                    : "Add Product & Download Barcode"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      <ToastContainer position="top-right" />
    </div>
    </PageContainer>
  );
};

// Styled Components
const PageContainer = styled.div`
  
  background: ${theme.colors.background};
  font-family: ${theme.typography.fontFamily};
  
`;

const Header = styled.header`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.primaryDark} 100%
  );
  padding: ${theme.spacing.lg} ${theme.spacing.xl};
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  z-index: 1000;
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
  cursor: pointer;
`;

const Logo = styled.div`
  width: 50px;
  height: 50px;
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
`;

const BrandInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const BrandName = styled.h1`
  color: ${theme.colors.white};
  font-size: ${theme.typography.fontSize["2xl"]};
  font-weight: ${theme.typography.fontWeight.bold};
  margin: 0;
`;

const BrandTagline = styled.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${theme.typography.fontSize.sm};
  margin: 0;
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.lg};
`;

const UserInfo = styled.div`
  text-align: right;
`;

const UserName = styled.div`
  color: ${theme.colors.white};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
`;

const UserRole = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
`;

const DateText = styled.div`
  color: rgba(255, 255, 255, 0.85);
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
`;

const BackButton = styled.button`
  background: ${theme.colors.white};
  color: ${theme.colors.primary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;




export default Inventory;
