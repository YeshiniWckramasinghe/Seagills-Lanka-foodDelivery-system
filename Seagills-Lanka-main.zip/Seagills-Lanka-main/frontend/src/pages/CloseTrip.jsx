import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { useNavigate } from "react-router-dom";
import {
  FaLock,
  FaCheckCircle,
  FaTruck,
  FaUser,
  FaCalendarAlt,
  FaClock,
} from "react-icons/fa";
import theme from "../styles/theme";
import Modal from "../Component/Modal";
import LoadingState from "../Component/common/LoadingState";
import PageLayout from "../Component/Layout/PageLayout";
import { assignedTruckAPI, tripSummaryAPI } from "../services/api";

// Helper function to get current time formatted for datetime-local input
const getCurrentTimeInput = () => {
  const now = new Date();
  const offset = now.getTimezoneOffset() * 60000;
  const localIso = new Date(now - offset).toISOString().slice(0, 16);
  return localIso;
};

const CloseTrip = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [assignment, setAssignment] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionTime, setSubmissionTime] = useState(getCurrentTimeInput());

  const [formData, setFormData] = useState({
    tripStartTime: "",
    tripEndTime: "",
    coordinatorNotes: "",
    scheduledStartTime: "",
  });

  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  const [runNotStartedModal, setRunNotStartedModal] = useState(false);

  useEffect(() => {
    fetchAssignmentData();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setSubmissionTime(getCurrentTimeInput());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const fetchAssignmentData = async () => {
    const userStr = localStorage.getItem("user");
    if (!userStr) {
      navigate("/login");
      return;
    }
    const user = JSON.parse(userStr);
    const coordinatorId = user.id;
    const today = new Date().toISOString().split("T")[0];

    try {
      setLoading(true);

      // Fetch the combined assignment and schedule data
      const response = await assignedTruckAPI.getCoordinatorDailySchedule(
        coordinatorId,
        today
      );

      if (!response.data.success || !response.data.schedule) {
        setModal({
          isOpen: true,
          type: "error",
          title: "No Active Assignment",
          message: "No assigned truck found for today. Cannot close trip.",
        });
        setAssignment(null);
        setLoading(false);
        return;
      }

      const schedule = response.data.schedule;

      if (!schedule.truckId) {
        throw new Error("Truck ID missing from assignment data.");
      }

      // Extract the trip started time from the schedule
      const tripStartTimeISO = schedule.tripStartedAt || "";

      // Convert ISO string to datetime-local format (YYYY-MM-DDTHH:MM)
      let formattedTripStartTime = "";
      if (tripStartTimeISO) {
        const date = new Date(tripStartTimeISO);
        const offset = date.getTimezoneOffset() * 60000;
        formattedTripStartTime = new Date(date - offset)
          .toISOString()
          .slice(0, 16);
      }

      setAssignment({
        truckID: schedule.truckId,
        coordinatorID: coordinatorId,
        tripDate: today,
        truckPlate: schedule.truck,
        driverName: schedule.driver,
      });

      setFormData((prev) => ({
        ...prev,
        tripStartTime: formattedTripStartTime,
        scheduledStartTime: schedule.startTime || "N/A",
      }));

      // Show warning if trip hasn't been started
      if (!tripStartTimeISO) {
        setModal({
          isOpen: true,
          type: "warning",
          title: "Run Not Started",
          message:
            "Please ensure the 'Start Daily Run' button was clicked on the dashboard before closing the trip.",
        });
      }
    } catch (err) {
      console.error("Error fetching assignment:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Data Error",
        message: err.message || "Failed to load truck assignment details.",
      });
      setAssignment(null);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!assignment || !formData.tripStartTime) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Missing Data",
        message:
          "Cannot close trip without a valid start time. Please ensure you clicked 'Start Daily Run' on the dashboard.",
      });
      return;
    }

    if (isSubmitting) return;
    setIsSubmitting(true);

    const submissionData = {
      truckID: assignment.truckID,
      coordinatorID: assignment.coordinatorID,
      tripDate: assignment.tripDate,
      coordinatorNotes: formData.coordinatorNotes,
      tripStartTime: formData.tripStartTime,
      tripEndTime: submissionTime,
    };

    if (
      new Date(submissionData.tripStartTime) >=
      new Date(submissionData.tripEndTime)
    ) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Invalid Time",
        message: "Trip End Time must be strictly after the Trip Start Time.",
      });
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await tripSummaryAPI.closeTrip(submissionData);

      if (response.data.success) {
        setModal({
          isOpen: true,
          type: "success",
          title: "Trip Closed Successfully",
          message:
            "The trip summary has been generated and the run is officially closed.",
        });
        setTimeout(() => navigate("/coordinator-dashboard"), 1500);
      } else {
        throw new Error(response.data.message || "Failed to close trip.");
      }
    } catch (err) {
      console.error("Submission Error:", err);
      setModal({
        isOpen: true,
        type: "error",
        title: "Closure Failed",
        message:
          err.response?.data?.message ||
          err.message ||
          "An unexpected error occurred during trip closure.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return <LoadingState text="Checking trip status..." />;
  }

  return (
    <PageLayout
      pageTitle="Close Trip Summary"
      pageSubtitle="Submit final details to officially close today's run"
      icon={<FaLock />}
    >
      <Modal
        isOpen={runNotStartedModal}
        onClose={() => {
          setRunNotStartedModal(false);
          navigate("/coordinator-dashboard");
        }}
        type="warning"
        title="Run Not Started"
        message="Please ensure the 'Start Daily Run' button was clicked on the dashboard before closing the trip."
      />

      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      <AssignmentInfoCard $assigned={!!assignment}>
        <InfoItem>
          <FaTruck /> Truck: <span>{assignment?.truckPlate || "N/A"}</span>
        </InfoItem>
        <InfoItem>
          <FaUser /> Driver: <span>{assignment?.driverName || "N/A"}</span>
        </InfoItem>
        <InfoItem>
          <FaCalendarAlt /> Trip Date:{" "}
          <span>{assignment?.tripDate || "N/A"}</span>
        </InfoItem>
      </AssignmentInfoCard>

      {assignment ? (
        <FormCard onSubmit={handleSubmit}>
          <SectionHeader>
            <FaClock /> Final Trip Details
          </SectionHeader>

          <FormGrid>
            <FormGroup>
              <Label>Scheduled Start Time</Label>
              <DisplayValue>{formData.scheduledStartTime}</DisplayValue>
            </FormGroup>

            <FormGroup>
              <Label htmlFor="tripStartTime">Trip Started Time (Actual)</Label>
              <Input
                id="tripStartTime"
                type="datetime-local"
                name="tripStartTime"
                value={formData.tripStartTime || ""}
                readOnly
                required
                style={{ cursor: "default", opacity: 0.8 }}
              />
            </FormGroup>

            <FormGroup>
              <Label htmlFor="tripEndTime">
                Trip End Time (System Time) <Required>*</Required>
              </Label>
              <Input
                id="tripEndTime"
                type="datetime-local"
                name="tripEndTime"
                value={submissionTime}
                readOnly
                required
                style={{ cursor: "default", opacity: 0.8 }}
              />
            </FormGroup>

            <FullWidthGroup>
              <Label htmlFor="coordinatorNotes">Coordinator Notes</Label>
              <Textarea
                id="coordinatorNotes"
                name="coordinatorNotes"
                value={formData.coordinatorNotes}
                onChange={handleInputChange}
                placeholder="Summary of day's events, issues, or key observations."
                rows="4"
              />
            </FullWidthGroup>
          </FormGrid>

          <ButtonGroup>
            <SubmitButton type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                "Closing Trip..."
              ) : (
                <>
                  <FaCheckCircle /> Close Trip & Generate Summary
                </>
              )}
            </SubmitButton>
          </ButtonGroup>
        </FormCard>
      ) : (
        <EmptyState>
          <p>Trip closure is disabled without an active daily assignment.</p>
        </EmptyState>
      )}
    </PageLayout>
  );
};

// Styled Components
const DisplayValue = styled.p`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  color: ${theme.colors.textSecondary};
  background: ${theme.colors.backgroundDark};
  margin: 0;
  font-weight: ${theme.typography.fontWeight.semibold};
`;

const FormCard = styled.form`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  margin-top: ${theme.spacing.xl};
`;

const SectionHeader = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  svg {
    color: ${theme.colors.primary};
  }
`;

const FormGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.lg};
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
`;

const FullWidthGroup = styled(FormGroup)`
  grid-column: 1 / -1;
`;

const Label = styled.label`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.sm};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.sm};
  display: flex;
  align-items: center;
`;

const Required = styled.span`
  color: ${theme.colors.error};
  margin-left: 4px;
`;

const Input = styled.input`
  padding: ${theme.spacing.md};
  border: 1px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  font-size: ${theme.typography.fontSize.base};
  transition: all ${theme.transitions.fast};

  &:focus {
    outline: none;
    border-color: ${theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(55, 186, 190, 0.1);
  }
`;

const Textarea = styled(Input).attrs({ as: "textarea" })`
  resize: vertical;
  min-height: 80px;
`;

const ButtonGroup = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: ${theme.spacing.md};
  margin-top: ${theme.spacing.xl};
`;

const SubmitButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: ${theme.colors.white};
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  &:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 16px ${theme.colors.shadowMedium};
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const AssignmentInfoCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.lg};
  padding: ${theme.spacing.lg};
  margin-top: ${theme.spacing.md};
  margin-bottom: ${theme.spacing.xl};
  box-shadow: 0 1px 4px ${theme.colors.shadow};
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  gap: ${theme.spacing.md};
`;

const InfoItem = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.base};
  font-weight: ${theme.typography.fontWeight.medium};

  svg {
    color: ${theme.colors.primary};
  }
  span {
    font-weight: ${theme.typography.fontWeight.semibold};
  }
`;

const EmptyState = styled.div`
  text-align: center;
  padding: ${theme.spacing.xl};
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
  color: ${theme.colors.textSecondary};
`;

export default CloseTrip;
