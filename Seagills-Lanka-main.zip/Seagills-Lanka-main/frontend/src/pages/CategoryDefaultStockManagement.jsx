// src/pages/CategoryDefaultStockManagement.jsx
import React, { useState, useEffect, useCallback } from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import { FaSave, FaEdit, FaEye } from "react-icons/fa";
import { categoryDefaultStockAPI, productAPI } from "../services/api";
import Modal from "../Component/Modal";
import PageLayout from "../Component/Layout/PageLayout";
import FormGroup from "../Component/form/FormGroup";

const categories = ["fish", "meat", "veg & spices", "fruits"];

const CategoryDefaultStockManagement = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("fish");
  const [products, setProducts] = useState([]);
  const [defaultStockItems, setDefaultStockItems] = useState([]);
  const [currentProduct, setCurrentProduct] = useState({
    productID: "",
    productName: "",
    quantity: "",
    unit: "pcs",
  });
  const [view, setView] = useState("edit"); // 'edit' or 'view'
  const [existingDefault, setExistingDefault] = useState(null);

  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  const filteredProducts = products.filter((product) => {
    const productCategory = product.category
      ? product.category.replace(/\s+/g, "").toLowerCase().trim()
      : "";
    const selected = selectedCategory.replace(/\s+/g, "").toLowerCase().trim();
    return productCategory === selected;
  });

  const fetchAllProducts = useCallback(async () => {
    try {
      const response = await productAPI.getAllProducts();
      let productData = response.data;

      if (productData && !Array.isArray(productData) && productData.products) {
        productData = productData.products;
      }

      if (Array.isArray(productData)) {
        setProducts(productData);
      } else {
        setProducts([]);
      }
    } catch (err) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Failed to Load Products",
        message: err.response?.data?.message || err.message,
      });
    }
  }, []);

  const fetchDefaultStock = useCallback(async () => {
    try {
      const response = await categoryDefaultStockAPI.getByCategory(
        selectedCategory
      );
      if (response.data.success) {
        setExistingDefault(response.data.data);
        setDefaultStockItems(response.data.data.products || []);
        setView("view");
      }
    } catch (err) {
      if (err.response?.status !== 404) {
        console.error("Error fetching default stock:", err);
      }
      setExistingDefault(null);
      setDefaultStockItems([]);
      setView("edit");
    }
  }, [selectedCategory]);

  useEffect(() => {
    document.body.style.paddingTop = "0";
    fetchAllProducts();
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, [fetchAllProducts]);

  useEffect(() => {
    fetchDefaultStock();
  }, [fetchDefaultStock]);

  const handleProductChange = (e) => {
    const { name, value } = e.target;

    if (name === "productID") {
      const selectedProduct = filteredProducts.find((p) => p._id === value);
      setCurrentProduct((prev) => ({
        ...prev,
        productID: value,
        productName: selectedProduct ? selectedProduct.productName : "",
      }));
    } else {
      setCurrentProduct((prev) => ({ ...prev, [name]: value }));
    }
  };

  const addProduct = () => {
    if (!currentProduct.productID || !currentProduct.quantity) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Missing Information",
        message: "Please select a product and enter quantity",
      });
      return;
    }

    if (
      defaultStockItems.some(
        (item) =>
          (item.productID._id || item.productID) === currentProduct.productID
      )
    ) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Product Already Added",
        message: "This product is already in the default stock list",
      });
      return;
    }

    setDefaultStockItems((prev) => [
      ...prev,
      {
        productID: {
          _id: currentProduct.productID,
          productName: currentProduct.productName,
        },
        productName: currentProduct.productName,
        quantity: parseFloat(currentProduct.quantity),
        unit: currentProduct.unit,
      },
    ]);

    setCurrentProduct({
      productID: "",
      productName: "",
      quantity: "",
      unit: "pcs",
    });
  };

  const updateProductQuantity = (index, newQuantity, newUnit) => {
    setDefaultStockItems((prev) => {
      const updated = [...prev];
      updated[index].quantity = parseFloat(newQuantity);
      updated[index].unit = newUnit;
      return updated;
    });
  };

  const removeProduct = (index) => {
    setDefaultStockItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSave = async (e) => {
    e.preventDefault();

    if (defaultStockItems.length === 0) {
      setModal({
        isOpen: true,
        type: "error",
        title: "No Products",
        message: `Please add at least one product to ${selectedCategory} default stock`,
      });
      return;
    }

    try {
      setLoading(true);
      const dataToSend = {
        category: selectedCategory,
        products: defaultStockItems.map((item) => ({
          productID: item.productID._id || item.productID,
          quantity: item.quantity,
          unit: item.unit,
        })),
      };

      const response = await categoryDefaultStockAPI.upsert(dataToSend);

      if (response.data.success) {
        setModal({
          isOpen: true,
          type: "success",
          title: "Success!",
          message: `Default stock for ${selectedCategory} saved successfully!`,
        });

        // Clear and refresh after 1.5 seconds
        setTimeout(() => {
          setDefaultStockItems([]);
          setCurrentProduct({
            productID: "",
            productName: "",
            quantity: "",
            unit: "pcs",
          });
          fetchDefaultStock();
        }, 1500);
      }
    } catch (err) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Failed to Save",
        message: err.response?.data?.message || err.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = () => {
    setView("edit");
  };

  const handleDeleteAll = async () => {
    if (!window.confirm(`Delete all default stock for ${selectedCategory}?`)) {
      return;
    }

    try {
      setLoading(true);
      // Delete by removing all items
      const response = await categoryDefaultStockAPI.upsert({
        category: selectedCategory,
        products: [],
      });

      // Actually we need to delete the document, let me use a different approach
      // For now, we'll need a delete endpoint or clear all
      setModal({
        isOpen: true,
        type: "success",
        title: "Deleted",
        message: "Default stock deleted successfully",
      });

      setExistingDefault(null);
      setDefaultStockItems([]);
      setView("edit");
    } catch (err) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Failed to Delete",
        message: err.response?.data?.message || err.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCategoryChange = (cat) => {
    setSelectedCategory(cat);
    setView("view");
  };

  return (
    <PageLayout
      pageTitle="Category Default Stock"
      pageSubtitle="Manage default quantities for products by category"
    >
      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      <FormCard>
        <SectionHeader>Select Category</SectionHeader>
        <CategoryGrid>
          {categories.map((cat) => (
            <CategoryButton
              key={cat}
              type="button"
              isActive={selectedCategory === cat}
              onClick={() => handleCategoryChange(cat)}
            >
              {cat.charAt(0).toUpperCase() + cat.slice(1)}
            </CategoryButton>
          ))}
        </CategoryGrid>

        <SectionDivider />

        {/* VIEW MODE */}
        {view === "view" && (
          <>
            <SectionHeader>
              Current Default Stock - {selectedCategory}
            </SectionHeader>

            {existingDefault && defaultStockItems.length > 0 ? (
              <>
                <ItemsListContainer>
                  {defaultStockItems.map((item, index) => (
                    <StockItemRow key={index}>
                      <ItemInfo>
                        <ItemName>{item.productName}</ItemName>
                        <ItemDetails>
                          Quantity: {item.quantity} {item.unit}
                        </ItemDetails>
                      </ItemInfo>
                    </StockItemRow>
                  ))}
                </ItemsListContainer>

                <ActionButtonsGroup>
                  <EditButton type="button" onClick={handleEdit}>
                    <FaEdit /> Edit Default Stock
                  </EditButton>
                  <DeleteButton type="button" onClick={handleDeleteAll}>
                    Delete & Start Over
                  </DeleteButton>
                </ActionButtonsGroup>
              </>
            ) : (
              <NoDataMessage>
                No default stock set for {selectedCategory} yet.
              </NoDataMessage>
            )}
          </>
        )}

        {/* EDIT MODE */}
        {view === "edit" && (
          <form onSubmit={handleSave}>
            <SectionHeader>Add Products to {selectedCategory}</SectionHeader>

            <ProductInputGrid>
              <FormGroup
                label="Product *"
                type="select"
                name="productID"
                value={currentProduct.productID}
                onChange={handleProductChange}
                disabled={filteredProducts.length === 0}
                note={
                  filteredProducts.length === 0
                    ? "No products found for this category"
                    : null
                }
              >
                <option value="">Select product...</option>
                {filteredProducts.map((product) => (
                  <option key={product._id} value={product._id}>
                    {product.productName} - LKR {product.price}
                  </option>
                ))}
              </FormGroup>

              <FormGroup
                label="Default Quantity *"
                type="input"
                inputType="number"
                name="quantity"
                value={currentProduct.quantity}
                onChange={handleProductChange}
                placeholder="Enter quantity..."
                min="0"
                step="0.01"
              />

              <FormGroup
                label="Unit *"
                type="select"
                name="unit"
                value={currentProduct.unit}
                onChange={handleProductChange}
              >
                <option value="pcs">pcs</option>
                <option value="kg">kg</option>
                <option value="g">g</option>
                <option value="nos">nos</option>
                <option value="bunch">bunch</option>
              </FormGroup>
            </ProductInputGrid>

            <AddProductButton type="button" onClick={addProduct}>
              + Add Product
            </AddProductButton>

            <SectionDivider />

            {defaultStockItems.length > 0 && (
              <>
                <SectionHeader>
                  Stock Items ({defaultStockItems.length})
                </SectionHeader>
                <ItemsListContainer>
                  {defaultStockItems.map((item, index) => (
                    <EditableStockItemRow key={index}>
                      <ItemInfo>
                        <ItemName>{item.productName}</ItemName>
                        <ItemDetails>
                          Current: {item.quantity} {item.unit}
                        </ItemDetails>
                      </ItemInfo>
                      <EditableQuantity>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={item.quantity}
                          onChange={(e) =>
                            updateProductQuantity(
                              index,
                              e.target.value,
                              item.unit
                            )
                          }
                        />
                        <select
                          value={item.unit}
                          onChange={(e) =>
                            updateProductQuantity(
                              index,
                              item.quantity,
                              e.target.value
                            )
                          }
                        >
                          <option value="pcs">pcs</option>
                          <option value="kg">kg</option>
                          <option value="g">g</option>
                          <option value="nos">nos</option>
                          <option value="bunch">bunch</option>
                        </select>
                        <RemoveButton
                          type="button"
                          onClick={() => removeProduct(index)}
                        >
                          ×
                        </RemoveButton>
                      </EditableQuantity>
                    </EditableStockItemRow>
                  ))}
                </ItemsListContainer>

                <SectionDivider />
              </>
            )}

            <ButtonGroup>
              <SaveButton type="submit" disabled={loading}>
                <FaSave /> {loading ? "Saving..." : "Save Default Stock"}
              </SaveButton>
            </ButtonGroup>
          </form>
        )}
      </FormCard>
    </PageLayout>
  );
};

const FormCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const SectionHeader = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
`;

const CategoryGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: ${theme.spacing.md};
  margin-bottom: ${theme.spacing.lg};
`;

const CategoryButton = styled.button`
  padding: ${theme.spacing.md} ${theme.spacing.lg};
  border: 2px solid ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  background: ${(props) =>
    props.isActive ? theme.colors.primary : theme.colors.white};
  color: ${(props) =>
    props.isActive ? theme.colors.white : theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};

  &:hover {
    border-color: ${theme.colors.primary};
  }
`;

const ProductInputGrid = styled.div`
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.md};

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const AddProductButton = styled.button`
  background: ${theme.colors.secondary};
  color: ${theme.colors.textPrimary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  margin-bottom: ${theme.spacing.lg};

  &:hover {
    background: ${theme.colors.secondaryDark};
  }
`;

const SectionDivider = styled.div`
  height: 1px;
  background: ${theme.colors.border};
  margin: ${theme.spacing.xl} 0;
`;

const ItemsListContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${theme.spacing.md};
  margin-bottom: ${theme.spacing.lg};
`;

const StockItemRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${theme.spacing.md};
  background: ${theme.colors.background};
  border-radius: ${theme.borderRadius.md};
  border-left: 4px solid ${theme.colors.primary};
`;

const EditableStockItemRow = styled(StockItemRow)`
  justify-content: space-between;
`;

const ItemInfo = styled.div`
  flex: 1;
`;

const ItemName = styled.div`
  color: ${theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.xs};
`;

const ItemDetails = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const EditableQuantity = styled.div`
  display: flex;
  gap: ${theme.spacing.sm};
  align-items: center;

  input,
  select {
    padding: ${theme.spacing.sm} ${theme.spacing.md};
    border: 1px solid ${theme.colors.border};
    border-radius: ${theme.borderRadius.sm};
    font-size: ${theme.typography.fontSize.sm};
  }

  input {
    width: 80px;
  }

  select {
    width: 70px;
  }
`;

const RemoveButton = styled.button`
  background: ${theme.colors.error};
  color: white;
  border: none;
  width: 32px;
  height: 32px;
  border-radius: ${theme.borderRadius.md};
  cursor: pointer;
  font-size: ${theme.typography.fontSize.lg};
  display: flex;
  align-items: center;
  justify-content: center;

  &:hover {
    background: #d32f2f;
  }
`;

const ActionButtonsGroup = styled.div`
  display: flex;
  gap: ${theme.spacing.md};
  margin-top: ${theme.spacing.lg};
`;

const EditButton = styled.button`
  background: ${theme.colors.primary};
  color: white;
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  transition: all ${theme.transitions.normal};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px ${theme.colors.shadowMedium};
  }
`;

const DeleteButton = styled(EditButton)`
  background: ${theme.colors.error};

  &:hover {
    background: #d32f2f;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: ${theme.spacing.md};
  margin-top: ${theme.spacing.xl};
`;

const SaveButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: ${theme.colors.white};
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  &:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 16px ${theme.colors.shadowMedium};
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const NoDataMessage = styled.div`
  background: ${theme.colors.background};
  border: 2px dashed ${theme.colors.border};
  border-radius: ${theme.borderRadius.md};
  padding: ${theme.spacing.xl};
  text-align: center;
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.base};
`;

export default CategoryDefaultStockManagement;
