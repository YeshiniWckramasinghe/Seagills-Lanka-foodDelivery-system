// src/pages/DailyLoading.jsx
import React, { useState, useEffect, useCallback, useMemo } from "react";
import styled from "styled-components";
import theme from "../styles/theme";
import { useNavigate } from "react-router-dom";
import { FaTruck, FaSave, FaPlus, FaTimes } from "react-icons/fa";
import {
  dailyLoadingAPI,
  assignedTruckAPI,
  productAPI,
  categoryDefaultStockAPI,
  preorderAPI,
} from "../services/api";
import Modal from "../Component/Modal";
import PageLayout from "../Component/Layout/PageLayout";
import FormGroup from "../Component/form/FormGroup";
import PreorderProductsList from "../Component/form/PreorderProductsList";

const units = ["kg", "g", "nos", "pcs", "bunch"];

const DailyLoading = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [preorderProducts, setPreorderProducts] = useState([]);
  const [fixedStockItems, setFixedStockItems] = useState([]);
  const [products, setProducts] = useState([]);
  const [todayAssignment, setTodayAssignment] = useState(null);

  const [modal, setModal] = useState({
    isOpen: false,
    type: "success",
    title: "",
    message: "",
  });

  const [formData, setFormData] = useState({
    truckID: "",
    coordinatorID: "",
    date: new Date().toISOString().split("T")[0],
    truckCategory: "",
  });

  const [currentProduct, setCurrentProduct] = useState({
    productID: "",
    productName: "",
    quantity: "",
    unit: "pcs",
  });

  // Filter products by selected category
  const filteredProducts = useMemo(() => {
    if (!formData.truckCategory || products.length === 0) {
      return [];
    }

    return products.filter((product) => {
      const productCategory = product.category
        ? product.category.toLowerCase().trim()
        : "";
      const selectedCategory = formData.truckCategory.toLowerCase().trim();
      return productCategory === selectedCategory;
    });
  }, [formData.truckCategory, products]);

  // Reset product selection when category changes
  useEffect(() => {
    setCurrentProduct((prev) => ({
      ...prev,
      productID: "",
      productName: "",
      quantity: "",
    }));
  }, [formData.truckCategory]);

  // Fetch all products
  const fetchAllProducts = useCallback(async () => {
    try {
      const response = await productAPI.getAllProducts();
      let productData = response.data;

      if (productData && !Array.isArray(productData) && productData.products) {
        productData = productData.products;
      }

      if (Array.isArray(productData)) {
        setProducts(productData);
      } else {
        setProducts([]);
      }
    } catch (err) {
      setProducts([]);
      setModal({
        isOpen: true,
        type: "error",
        title: "Failed to Load Products",
        message: err.response?.data?.message || err.message,
      });
    }
  }, []);

  // Fetch today's assignment
  const fetchTodayAssignment = useCallback(async () => {
    try {
      const userStr = localStorage.getItem("user");
      if (!userStr) {
        navigate("/login");
        return;
      }

      const user = JSON.parse(userStr);
      const today = new Date().toISOString().split("T")[0];

      const response = await assignedTruckAPI.getAssignmentsByDate(today);

      if (response.data.success && response.data.assignments.length > 0) {
        const myAssignment = response.data.assignments.find(
          (a) => a.deliveryCoordinatorID._id === user.id
        );

        if (myAssignment) {
          setTodayAssignment(myAssignment);
          setFormData((prev) => ({
            ...prev,
            truckID: myAssignment.truckID._id,
            coordinatorID: user.id,
            truckCategory: myAssignment.category || "",
          }));
        } else {
          setModal({
            isOpen: true,
            type: "error",
            title: "No Assignment Found",
            message: "No truck has been assigned to you for today",
          });
        }
      }
    } catch (err) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Failed to Load Assignment",
        message: err.response?.data?.message || err.message,
      });
    }
  }, [navigate]);

  // Fetch preorder products for today's truck
  const fetchPreorderProducts = useCallback(async () => {
    if (!formData.truckID) return;

    try {
      const today = new Date().toISOString().split("T")[0];
      const response = await preorderAPI.getPreordersByTruck(
        formData.truckID,
        today
      );

      // Check for success flag - handle both empty and populated results
      if (response.data.success) {
        if (response.data.preorders && response.data.preorders.length > 0) {
          const allPreorderProducts = [];
          response.data.preorders.forEach((preorder) => {
            if (preorder.preorderProducts) {
              preorder.preorderProducts.forEach((product) => {
                allPreorderProducts.push({
                  productID: product.productID?._id || product.productID,
                  productName:
                    product.productID?.productName || product.productName,
                  quantity: product.quantity,
                  unit: product.unit,
                });
              });
            }
          });
          setPreorderProducts(allPreorderProducts);
        } else {
          // Empty results - this is valid, not an error
          setPreorderProducts([]);
        }
      } else {
        setPreorderProducts([]);
      }
    } catch (err) {
      // Only log non-404 errors as actual errors
      if (err.response?.status !== 404) {
        console.error("Error fetching preorder products:", err);
      }
      setPreorderProducts([]);
    }
  }, [formData.truckID]);

  // Fetch default stock for category
  const fetchDefaultStock = useCallback(async () => {
    if (!formData.truckCategory) return;

    try {
      const response = await categoryDefaultStockAPI.getByCategory(
        formData.truckCategory
      );

      if (response.data.success && response.data.data.products) {
        setFixedStockItems(response.data.data.products);
      } else {
        setFixedStockItems([]);
      }
    } catch (err) {
      // 404 means no default stock set yet - this is okay
      if (err.response?.status === 404) {
        console.log(
          `No default stock configured for category: ${formData.truckCategory}`
        );
        setFixedStockItems([]);
      } else if (err.response?.status !== 404) {
        console.error("Error fetching default stock:", err);
        setFixedStockItems([]);
      }
    }
  }, [formData.truckCategory]);

  useEffect(() => {
    document.body.style.paddingTop = "0";
    return () => {
      document.body.style.paddingTop = "80px";
    };
  }, []);

  useEffect(() => {
    fetchAllProducts();
    fetchTodayAssignment();
  }, [fetchAllProducts, fetchTodayAssignment]);

  useEffect(() => {
    fetchPreorderProducts();
  }, [fetchPreorderProducts]);

  useEffect(() => {
    fetchDefaultStock();
  }, [fetchDefaultStock]);

  const handleProductChange = (e) => {
    const { name, value } = e.target;

    if (name === "productID") {
      const selectedProduct = filteredProducts.find((p) => p._id === value);
      setCurrentProduct((prev) => ({
        ...prev,
        productID: value,
        productName: selectedProduct ? selectedProduct.productName : "",
      }));
    } else {
      setCurrentProduct((prev) => ({ ...prev, [name]: value }));
    }
  };

  const addFixedStockItem = () => {
    if (!currentProduct.productID || !currentProduct.quantity) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Missing Information",
        message: "Please select a product and enter quantity",
      });
      return;
    }

    // Check if already added to custom items
    const customItems = fixedStockItems.filter((item) => !item._id);
    if (
      customItems.some((item) => item.productID === currentProduct.productID)
    ) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Already Added",
        message: "This product is already in the stock list",
      });
      return;
    }

    setFixedStockItems((prev) => [
      ...prev,
      {
        productID: currentProduct.productID,
        productName: currentProduct.productName,
        quantity: parseFloat(currentProduct.quantity),
        unit: currentProduct.unit,
      },
    ]);

    setCurrentProduct({
      productID: "",
      productName: "",
      quantity: "",
      unit: "pcs",
    });
  };

  const updateFixedStockQuantity = (index, newQuantity, newUnit) => {
    setFixedStockItems((prev) => {
      const updated = [...prev];
      updated[index].quantity = parseFloat(newQuantity);
      updated[index].unit = newUnit;
      return updated;
    });
  };

  const removeFixedStockItem = (index) => {
    setFixedStockItems((prev) => prev.filter((_, i) => i !== index));
  };

  // Calculate totals
  const preorderTotal = preorderProducts.reduce(
    (sum, item) => sum + item.quantity,
    0
  );

  const fixedStockTotal = fixedStockItems.reduce(
    (sum, item) => sum + item.quantity,
    0
  );

  const grandTotal = preorderTotal + fixedStockTotal;

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log("🚚 Data to be sent to backend:", {
      truckID: formData.truckID,
      coordinatorID: formData.coordinatorID,
      date: formData.date,
      truckCategory: formData.truckCategory,
      defaultStockItems: fixedStockItems,
    });

    if (
      !formData.truckID ||
      !formData.coordinatorID ||
      !formData.truckCategory
    ) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Missing Information",
        message: "Truck, Coordinator, and Category information is required.",
      });
      return;
    }

    if (fixedStockItems.length === 0) {
      setModal({
        isOpen: true,
        type: "error",
        title: "No Fixed Stock",
        message: "Please add at least one fixed stock item",
      });
      return;
    }

    try {
      setLoading(true);

      const dataToSend = {
        truckID: formData.truckID,
        coordinatorID: formData.coordinatorID,
        date: formData.date,
        truckCategory: formData.truckCategory,
        defaultStockItems: fixedStockItems.map((item) => ({
          productID: item.productID?._id || item.productID,
          quantity: item.quantity,
          unit: item.unit,
        })),
      };

      // 👇 Log final payload before request
      console.log("📦 Final payload:", dataToSend);

      const response = await dailyLoadingAPI.createLoading(dataToSend);

      if (response.data.success) {
        setModal({
          isOpen: true,
          type: "success",
          title: "Success!",
          message:
            "Daily loading manifest created successfully! Redirecting...",
        });
        setTimeout(() => navigate("/coordinator-dashboard"), 2000);
      }
    } catch (err) {
      setModal({
        isOpen: true,
        type: "error",
        title: "Failed to Create Loading",
        message:
          err.response?.data?.message ||
          "An error occurred while creating the loading manifest",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageLayout
      pageTitle="Daily Loading"
      pageSubtitle="Record products loaded for today's delivery"
    >
      <Modal
        isOpen={modal.isOpen}
        onClose={() => setModal({ ...modal, isOpen: false })}
        type={modal.type}
        title={modal.title}
        message={modal.message}
      />

      <FormCard>
        <form onSubmit={handleSubmit}>
          {/* Loading Information Section */}
          <SectionHeader>
            <FaTruck /> Loading Information
          </SectionHeader>

          <FormGrid>
            <FormGroup label="Truck" type="display" note="Plate Number">
              {todayAssignment?.truckID?.plateNo || "Loading..."}
            </FormGroup>

            <FormGroup label="Coordinator" type="display" note="Your Username">
              {JSON.parse(localStorage.getItem("user") || "{}").username}
            </FormGroup>

            <FormGroup label="Date" type="display" note="Today's Date">
              {new Date(formData.date).toLocaleDateString("en-US", {
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </FormGroup>

            <FormGroup label="Category" type="display" note="Assigned by Admin">
              {formData.truckCategory
                ? formData.truckCategory.charAt(0).toUpperCase() +
                  formData.truckCategory.slice(1)
                : "Loading..."}
            </FormGroup>
          </FormGrid>

          <SectionDivider />

          {/* Preorder Products Section */}
          <PreorderProductsList items={preorderProducts} />

          <SectionDivider />

          <SectionDivider />

          {/* Fixed Stock Items Section */}
          <SectionHeader>Fixed Stock Loading</SectionHeader>

          {/* Fixed Stock Items List */}
          {fixedStockItems.length > 0 && (
            <>
              <SectionHeader>
                Fixed Stock Items ({fixedStockItems.length})
              </SectionHeader>
              <StockItemsContainer>
                {fixedStockItems.map((item, index) => (
                  <StockItemRow key={index}>
                    <ItemInfo>
                      <ItemName>{item.productName}</ItemName>
                      <ItemDetails>
                        Current: {item.quantity} {item.unit}
                      </ItemDetails>
                    </ItemInfo>
                    <ItemActions>
                      <EditableQuantity>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={item.quantity}
                          onChange={(e) =>
                            updateFixedStockQuantity(
                              index,
                              e.target.value,
                              item.unit
                            )
                          }
                        />
                        <select
                          value={item.unit}
                          onChange={(e) =>
                            updateFixedStockQuantity(
                              index,
                              item.quantity,
                              e.target.value
                            )
                          }
                        >
                          {units.map((unit) => (
                            <option key={unit} value={unit}>
                              {unit}
                            </option>
                          ))}
                        </select>
                      </EditableQuantity>
                      <RemoveButton
                        type="button"
                        onClick={() => removeFixedStockItem(index)}
                      >
                        <FaTimes />
                      </RemoveButton>
                    </ItemActions>
                  </StockItemRow>
                ))}
              </StockItemsContainer>

              <SectionDivider />
            </>
          )}

          {/* Summary Section */}
          <SummarySection>
            <SummaryTitle>Loading Summary</SummaryTitle>
            <SummaryRow>
              <SummaryLabel>Preorder Products Total:</SummaryLabel>
              <SummaryValue>{preorderTotal}</SummaryValue>
            </SummaryRow>
            <SummaryRow>
              <SummaryLabel>Fixed Stock Total:</SummaryLabel>
              <SummaryValue>{fixedStockTotal}</SummaryValue>
            </SummaryRow>
            <SummaryRowTotal>
              <SummaryLabel>Grand Total:</SummaryLabel>
              <SummaryValueTotal>{grandTotal}</SummaryValueTotal>
            </SummaryRowTotal>
          </SummarySection>

          <ButtonGroup>
            <SubmitButton type="submit" disabled={loading}>
              <FaSave /> {loading ? "Creating..." : "Complete Loading"}
            </SubmitButton>
          </ButtonGroup>
        </form>
      </FormCard>
    </PageLayout>
  );
};

// Styled Components
const FormCard = styled.div`
  background: ${theme.colors.white};
  border-radius: ${theme.borderRadius.xl};
  padding: ${theme.spacing.xl};
  box-shadow: 0 2px 8px ${theme.colors.shadow};
`;

const SectionHeader = styled.h3`
  color: ${theme.colors.textPrimary};
  font-size: ${theme.typography.fontSize.xl};
  font-weight: ${theme.typography.fontWeight.semibold};
  margin: 0 0 ${theme.spacing.lg};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};
`;

const FormGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.lg};
`;

const ProductInputGrid = styled.div`
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: ${theme.spacing.lg};
  margin-bottom: ${theme.spacing.md};

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const AddButton = styled.button`
  background: ${theme.colors.secondary};
  color: ${theme.colors.textPrimary};
  border: none;
  padding: ${theme.spacing.sm} ${theme.spacing.lg};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: inline-flex;
  align-items: center;
  gap: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.lg};

  &:hover {
    background: ${theme.colors.secondaryDark};
    transform: translateY(-2px);
  }
`;

const SectionDivider = styled.div`
  height: 1px;
  background: ${theme.colors.border};
  margin: ${theme.spacing.xl} 0;
`;

const StockItemsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${theme.spacing.md};
  margin-bottom: ${theme.spacing.lg};
`;

const StockItemRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${theme.spacing.md};
  background: ${theme.colors.background};
  border-radius: ${theme.borderRadius.md};
  border-left: 4px solid ${theme.colors.secondary};
`;

const ItemInfo = styled.div`
  flex: 1;
`;

const ItemName = styled.div`
  color: ${theme.colors.textPrimary};
  font-weight: ${theme.typography.fontWeight.medium};
  margin-bottom: ${theme.spacing.xs};
`;

const ItemDetails = styled.div`
  color: ${theme.colors.textSecondary};
  font-size: ${theme.typography.fontSize.sm};
`;

const ItemActions = styled.div`
  display: flex;
  align-items: center;
  gap: ${theme.spacing.md};
`;

const EditableQuantity = styled.div`
  display: flex;
  gap: ${theme.spacing.sm};
  align-items: center;

  input,
  select {
    padding: ${theme.spacing.sm} ${theme.spacing.md};
    border: 1px solid ${theme.colors.border};
    border-radius: ${theme.borderRadius.sm};
    font-size: ${theme.typography.fontSize.sm};
  }

  input {
    width: 80px;
  }

  select {
    width: 70px;
  }
`;

const RemoveButton = styled.button`
  background: ${theme.colors.error};
  color: white;
  border: none;
  width: 32px;
  height: 32px;
  border-radius: ${theme.borderRadius.md};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all ${theme.transitions.fast};

  &:hover {
    background: #d32f2f;
  }
`;

const SummarySection = styled.div`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.info} 100%
  );
  border-radius: ${theme.borderRadius.lg};
  padding: ${theme.spacing.lg};
  color: ${theme.colors.white};
  margin-bottom: ${theme.spacing.xl};
`;

const SummaryTitle = styled.h4`
  margin: 0 0 ${theme.spacing.md};
  font-size: ${theme.typography.fontSize.lg};
  font-weight: ${theme.typography.fontWeight.semibold};
`;

const SummaryRow = styled.div`
  display: flex;
  justify-content: space-between;
  padding: ${theme.spacing.sm} 0;
  font-size: ${theme.typography.fontSize.base};
`;

const SummaryRowTotal = styled(SummaryRow)`
  border-top: 1px solid rgba(255, 255, 255, 0.3);
  padding-top: ${theme.spacing.md};
  margin-top: ${theme.spacing.md};
  font-weight: ${theme.typography.fontWeight.bold};
  font-size: ${theme.typography.fontSize.lg};
`;

const SummaryLabel = styled.span``;

const SummaryValue = styled.span`
  font-weight: ${theme.typography.fontWeight.semibold};
`;

const SummaryValueTotal = styled(SummaryValue)`
  font-size: ${theme.typography.fontSize.xl};
`;

const ButtonGroup = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: ${theme.spacing.md};
  margin-top: ${theme.spacing.xl};
`;

const SubmitButton = styled.button`
  background: linear-gradient(
    135deg,
    ${theme.colors.primary} 0%,
    ${theme.colors.secondary} 100%
  );
  color: ${theme.colors.white};
  border: none;
  padding: ${theme.spacing.md} ${theme.spacing.xl};
  border-radius: ${theme.borderRadius.md};
  font-weight: ${theme.typography.fontWeight.semibold};
  font-size: ${theme.typography.fontSize.base};
  cursor: pointer;
  transition: all ${theme.transitions.normal};
  display: flex;
  align-items: center;
  gap: ${theme.spacing.sm};

  &:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 16px ${theme.colors.shadowMedium};
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

export default DailyLoading;
