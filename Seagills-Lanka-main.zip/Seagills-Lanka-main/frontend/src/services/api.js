// src/services/api.js
import axios from "axios";

// Base API URL - adjust this based on your backend port
const API_BASE_URL =
  process.env.REACT_APP_API_URL || "http://localhost:5000/api";

// Base URL without /api prefix for certain routes
const BASE_URL_NO_API =
  process.env.REACT_APP_BASE_URL_NO_API || "http://localhost:5000";

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Create a dedicated Axios instance for routes not using the /api prefix
const baseClient = axios.create({
  baseURL: BASE_URL_NO_API,
  headers: {
    "Content-Type": "application/json",
  },
});

// Add token to requests if it exists
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Add token interceptor to the new client
baseClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Handle response errors globally
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Redirect to login if unauthorized
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (credentials) => apiClient.post("/users/login", credentials),
  register: (userData) => apiClient.post("/users/register", userData),
  logout: () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
  },
};

// Trip Summary API
export const tripSummaryAPI = {
  getTripSummaryById: (id) => apiClient.get(`/trip-summaries/${id}`),
  closeTripAndGenerateSummary: (data) =>
    apiClient.post("/trip-summaries/close", data),
  closeTrip: (data) => apiClient.post("/trip-summaries/close", data),
  getTripSummaryByTruckAndDate: (truckId, date) =>
    apiClient.get(`/trip-summaries/truck/${truckId}?date=${date}`),
  getTripSummariesByCoordinator: (coordinatorId, params) =>
    apiClient.get(`/trip-summaries/coordinator/${coordinatorId}`, { params }),
  downloadTripReportPDF: (id) => apiClient.get(`/trip-summaries/${id}/pdf`),
};

// Assigned Truck API
export const assignedTruckAPI = {
  getAllAssignments: () => apiClient.get("/assigned-trucks"),
  getAssignmentsByCoordinator: (coordinatorId) =>
    apiClient.get(`/assigned-trucks/coordinator/${coordinatorId}`),
  getAssignmentsByDate: (date) =>
    apiClient.get(`/assigned-trucks/date/${date}`),
  getCoordinatorDailySchedule: (coordinatorId, date) =>
    apiClient.get(`/assigned-trucks/schedule/${coordinatorId}/${date}`),
  getTripStatus: (truckId, date) =>
    tripSummaryAPI.getSummaryByTruckAndDate(truckId, date),
  createAssignment: (data) => apiClient.post("/assigned-trucks", data),
  updateAssignment: (id, data) => apiClient.put(`/assigned-trucks/${id}`, data),
  deleteAssignment: (id) => apiClient.delete(`/assigned-trucks/${id}`),
};

// Daily Loading API
export const dailyLoadingAPI = {
  getAllLoadings: () => apiClient.get("/daily-loadings"),
  getLoadingById: (id) => apiClient.get(`/daily-loadings/${id}`),
  getTodayLoadings: () => apiClient.get("/daily-loadings/today"),
  getLoadingsByTruck: (truckId) =>
    apiClient.get(`/daily-loadings/truck/${truckId}`),
  getLoadingsByCoordinator: (coordinatorId) =>
    apiClient.get(`/daily-loadings/coordinator/${coordinatorId}`),
  getLoadingsByDate: (date) => apiClient.get(`/daily-loadings/date/${date}`),
  createLoading: (data) => apiClient.post("/daily-loadings", data),
  updateLoading: (id, data) => apiClient.put(`/daily-loadings/${id}`, data),
  deleteLoading: (id) => apiClient.delete(`/daily-loadings/${id}`),
};

// User API
export const userAPI = {
  getAllDeliveryCoordinators: () =>
    apiClient.get("/users/delivery-coordinators"),
  getDeliveryCoordinatorById: (id) =>
    apiClient.get(`/users/delivery-coordinators/${id}`),
  getUsersByRole: (role) => apiClient.get(`/users/role/${role}`),
  getUserById: (id) => apiClient.get(`/users/${id}`),
};

// Branch API
export const branchAPI = {
  getAllBranches: () => apiClient.get("/branches"),
  getBranchById: (id) => apiClient.get(`/branches/${id}`),
  createBranch: (data) => apiClient.post("/branches", data),
  updateBranch: (id, data) => apiClient.put(`/branches/${id}`, data),
  deleteBranch: (id) => apiClient.delete(`/branches/${id}`),
};

// Product API
export const productAPI = {
  getAllProducts: () => apiClient.get("/products"),
  getProductById: (id) => apiClient.get(`/products/${id}`),
  getProductsByCategory: (category) =>
    apiClient.get(`/products/category/${category}`),
  searchProducts: (query) => apiClient.get(`/products/search?query=${query}`),
  getProductCategories: () => apiClient.get("/products/categories"),
  getProductStatistics: () => apiClient.get("/products/statistics"),
  createProduct: (data) => apiClient.post("/products", data),
  updateProduct: (id, data) => apiClient.put(`/products/${id}`, data),
  deleteProduct: (id) => apiClient.delete(`/products/${id}`),
};

// Incident API
export const incidentAPI = {
  recordIncident: (data) => apiClient.post("/incidents", data),
  getIncidentsByTruckAndDate: (truckId, date) =>
    apiClient.get(`/incidents/truck/${truckId}?date=${date}`),
  getIncidentsByCoordinator: (coordinatorId, params) =>
    apiClient.get(`/incidents/coordinator/${coordinatorId}`, { params }),
  getIncidentById: (id) => apiClient.get(`/incidents/${id}`),
  updateIncident: (id, data) => apiClient.put(`/incidents/${id}`, data),
  getAllIncidents: (params) => apiClient.get("/incidents", { params }),
};

// Preorder API
export const preorderAPI = {
  getAllPreorders: (params) => apiClient.get("/preorders", { params }),
  getPreorderById: (id) => apiClient.get(`/preorders/${id}`),
  getPreordersByTruck: (truckId, date) =>
    apiClient.get(`/preorders/truck/${truckId}?date=${date}`),
  verifyPreorder: (id, data) => apiClient.put(`/preorders/${id}/verify`, data),
  updateDeliveryStatus: (id, data) =>
    apiClient.put(`/preorders/${id}/status`, data),
  createPreorder: (data) => apiClient.post("/preorders", data),
};

// Default Stock API
export const categoryDefaultStockAPI = {
  getByCategory: (category) =>
    apiClient.get(
      `/category-default-stock/category/${encodeURIComponent(category)}`
    ),
  getAll: () => apiClient.get("/category-default-stock"),
  upsert: (data) => apiClient.post("/category-default-stock", data),
  updateProduct: (data) =>
    apiClient.put("/category-default-stock/product/update", data),
  deleteProduct: (category, productID) =>
    apiClient.delete(
      `/category-default-stock/${encodeURIComponent(category)}/${productID}`
    ),
};

// Truck API
export const truckAPI = {
  getAllTrucks: () => apiClient.get("/trucks"),
  getTruckById: (id) => apiClient.get(`/trucks/${id}`),
  createTruck: (data) => apiClient.post("/trucks", data),
  updateTruck: (id, data) => apiClient.put(`/trucks/${id}`, data),
  deleteTruck: (id) => apiClient.delete(`/trucks/${id}`),
};

// Driver API
export const driverAPI = {
  getAllDrivers: () => apiClient.get("/users/truck-drivers"), // ensures /api prefix
  getDriverById: (id) => apiClient.get(`/users/truck-drivers/${id}`),
  updateDriver: (id, data) => apiClient.put(`/users/${id}`, data),
  deleteDriver: (id) => apiClient.delete(`/users/${id}`),
};

// Route API
export const routeAPI = {
  getAllRoutes: () => apiClient.get("/routes"),
  createRoute: (data) => apiClient.post("/routes", data),
  updateRoute: (id, data) => apiClient.put(`/routes/${id}`, data),
  deleteRoute: (id) => apiClient.delete(`/routes/${id}`),
};

// Truck Route (Schedule) API
// Replace your truckRouteAPI section with this:

// Truck Route (Schedule) API
export const truckRouteAPI = {
  // Create new truck route schedule
  createTruckRoute: (data) => apiClient.post("/truck-routes", data),
  
  // Get all truck routes
  getAllTruckRoutes: () => apiClient.get("/truck-routes"),
  
  // Get single truck route by ID
  getTruckRouteById: (id) => apiClient.get(`/truck-routes/${id}`),
  
  // Get routes by specific truck
  getSchedulesByTruck: (truckId) =>
    apiClient.get(`/truck-routes/truck/${truckId}`),
  
  // Get routes by specific date
  getSchedulesByDate: (date) => apiClient.get(`/truck-routes/date/${date}`),
  
  // Update truck route
  updateTruckRoute: (id, data) => apiClient.put(`/truck-routes/${id}`, data),
  
  // Delete truck route
  deleteTruckRoute: (id) => apiClient.delete(`/truck-routes/${id}`),
  
  // Start daily run for a truck
  startDailyRun: (data) =>
    apiClient.post("/truck-routes/schedules/start-run", data),
};

// Daily Report API
export const reportAPI = {
  getDailyTruckReport: (date) =>
    apiClient.get(`/reports/daily/${date}`),
};

// En-route Order API
export const enrouteOrderAPI = {
  getAllOrders: (params) => apiClient.get("/enroute-orders", { params }),
  getOrderById: (id) => apiClient.get(`/enroute-orders/${id}`),
  getOrdersByCoordinator: (coordinatorId, params) =>
    apiClient.get(`/enroute-orders/coordinator/${coordinatorId}`, { params }),
  getOrdersByTruck: (truckId, params) =>
    apiClient.get(`/enroute-orders/truck/${truckId}`, { params }),
  createOrder: (data) => apiClient.post("/enroute-orders", data),
  updateOrder: (id, data) => apiClient.patch(`/enroute-orders/${id}`, data),
};

// Payment API
export const paymentAPI = {
  updatePayment: (id, data) => apiClient.patch(`/payments/${id}`, data),
};

// Coordinator Summary API
export const coordinatorSummaryAPI = {
  getDailySummary: (coordinatorId, date) => {
    const dateParam = date || new Date().toISOString().split("T")[0];
    return apiClient.get(
      `/coordinator-summary/${coordinatorId}?date=${dateParam}`
    );
  },
};

// Export everything including apiClient and baseClient
export { apiClient, baseClient };
export default apiClient;
