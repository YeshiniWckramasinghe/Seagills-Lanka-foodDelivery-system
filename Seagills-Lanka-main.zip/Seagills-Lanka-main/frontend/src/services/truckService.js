import axios from "axios";

const API_BASE = "http://localhost:5000/trucks";

export const getAllTrucks = () => axios.get(API_BASE);
export const getTruckById = (id) => axios.get(`${API_BASE}/${id}`);
export const createTruck = (truck) => axios.post(API_BASE, truck);
export const updateTruck = (id, truck) => axios.put(`${API_BASE}/${id}`, truck);
export const deleteTruck = (id) => axios.delete(`${API_BASE}/${id}`);
