// ------------------------
// Initialize Socket.IO connection
// ------------------------
const socket = io("http://localhost:5000");

// ------------------------
// Initialize map
// ------------------------
const map = L.map("map").setView([6.9271, 79.8612], 10);

// Tile layer
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "Seagills Lanka Delivery",
}).addTo(map);

// ------------------------
// Marker & layer storage
// ------------------------
const markers = {};
const branchMarkers = {};
const truckMarkers = {};
const routeLayers = {};
const closestBranchBanner = document.getElementById("closest-branch-banner");
let lastClosestBranchId = null;
let userLocation = null; // Store user location globally

// ------------------------
// Custom icons
// ------------------------
const deviceIcon = L.icon({
  iconUrl: "/images/marker.png",
  iconSize: [50, 50],
  iconAnchor: [25, 25],
});

const branchIcon = L.icon({
  iconUrl: "/images/branch.png",
  iconSize: [50, 50],
  iconAnchor: [25, 50],
});

const truckIcon = L.icon({
  iconUrl: "/images/truck.png",
  iconSize: [50, 50],
  iconAnchor: [25, 25],
});

// ------------------------
// Helper functions
// ------------------------
function getDistance(lat1, lon1, lat2, lon2) {
  return Math.sqrt((lat1 - lat2) ** 2 + (lon1 - lon2) ** 2);
}

function drawORSFeature(feature, style) {
  const coords = feature.geometry.coordinates.map(c => [c[1], c[0]]);
  return L.polyline(coords, style);
}

function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371000; // Earth's radius in meters
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function calculateETA(distanceMeters) {
  // Assuming average truck speed of 40 km/h in urban areas
  const speedKmH = 40;
  const speedMs = speedKmH * 1000 / 3600;
  const timeSeconds = distanceMeters / speedMs;
  const minutes = Math.ceil(timeSeconds / 60);
  return minutes;
}

// ------------------------
// Truck popup content
// ------------------------
function getTruckPopupContent(truck) {
  let content = `
    <b>Truck Number:</b> ${truck.truckNumber || truck._id}<br>
    <b>Colour:</b> ${truck.colour || 'N/A'}<br>
    <b>Status:</b> ${truck.status || 'idle'}<br>
  `;

  if (truck.status && (truck.status.toLowerCase() === "enroute" || truck.status.toLowerCase() === "assigned")) {
    content += `<button class="request-order-btn" data-truck-id="${truck._id}" data-truck-number="${truck.truckNumber || truck._id}">
                  Request Order
                </button>`;
  }

  return content;
}

// ------------------------
// Create and show modern modal
// ------------------------
function showRequestModal(truck, distanceMeters, eta) {
  // Create modal backdrop
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.id = "order-modal-backdrop";

  // Create modal container
  const modal = document.createElement("div");
  modal.className = "order-confirmation-modal";
  modal.id = "order-confirmation-modal";
  
  modal.innerHTML = `
    <div class="modal-content">
      <div class="modal-header">
        <h2>Confirm Order Request</h2>
        <button class="modal-close" id="modal-close-btn">&times;</button>
      </div>
      
      <div class="modal-body">
        <div class="truck-info-card">
          <div class="truck-detail">
            <span class="detail-label">Truck Number:</span>
            <span class="detail-value">${truck.truckNumber || truck._id}</span>
          </div>
          <div class="truck-detail">
            <span class="detail-label">Colour:</span>
            <span class="detail-value">${truck.colour || 'N/A'}</span>
          </div>
        </div>

        <div class="distance-eta-container">
          <div class="info-box distance-box">
            <div class="icon">📍</div>
            <div class="info-content">
              <div class="info-label">Distance</div>
              <div class="info-value">${(distanceMeters / 1000).toFixed(2)} km</div>
              <div class="info-subtext">${distanceMeters.toFixed(0)} m</div>
            </div>
          </div>

          <div class="info-box eta-box">
            <div class="icon">⏱️</div>
            <div class="info-content">
              <div class="info-label">Estimated Arrival</div>
              <div class="info-value">${eta} min</div>
              <div class="info-subtext">At average speed</div>
            </div>
          </div>
        </div>

        <div class="modal-message">
          <p>Ready to proceed with your order request?</p>
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn btn-cancel" id="modal-cancel-btn">Cancel</button>
        <button class="btn btn-next" id="modal-next-btn">Proceed to Request</button>
      </div>
    </div>
  `;

  document.body.appendChild(backdrop);
  document.body.appendChild(modal);

  // Add styles dynamically if not already in CSS
  addModalStyles();

  // Close button handlers
  document.getElementById("modal-close-btn").addEventListener("click", closeModal);
  document.getElementById("modal-cancel-btn").addEventListener("click", closeModal);
  backdrop.addEventListener("click", closeModal);

  // Next button handler
  document.getElementById("modal-next-btn").addEventListener("click", () => {
    sessionStorage.setItem('selectedTruckId', truck._id);
    sessionStorage.setItem('selectedTruckNumber', truck.truckNumber || truck._id);
    closeModal();
    window.location.href = 'http://localhost:3000/customer/request';
  });

  // Prevent backdrop click from closing if clicking on modal itself
  modal.addEventListener("click", (e) => e.stopPropagation());
}

function closeModal() {
  const modal = document.getElementById("order-confirmation-modal");
  const backdrop = document.getElementById("order-modal-backdrop");
  if (modal) modal.remove();
  if (backdrop) backdrop.remove();
}

function addModalStyles() {
  if (document.getElementById("modal-styles")) return;

  const styles = document.createElement("style");
  styles.id = "modal-styles";
  styles.textContent = `
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(4px);
      z-index: 999;
      animation: fadeIn 0.2s ease-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes slideUp {
      from {
        transform: translateY(20px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }

    .order-confirmation-modal {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      border-radius: 16px;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      z-index: 1000;
      max-width: 500px;
      width: 90%;
      animation: slideUp 0.3s ease-out;
    }

    .modal-content {
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 24px;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-header h2 {
      margin: 0;
      font-size: 20px;
      font-weight: 600;
      color: #1f2937;
    }

    .modal-close {
      background: none;
      border: none;
      font-size: 28px;
      color: #9ca3af;
      cursor: pointer;
      transition: color 0.2s;
      padding: 0;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .modal-close:hover {
      color: #1f2937;
    }

    .modal-body {
      padding: 24px;
      flex: 1;
      overflow-y: auto;
    }

    .truck-info-card {
      background: #f9fafb;
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 24px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    .truck-detail {
      display: flex;
      flex-direction: column;
    }

    .detail-label {
      font-size: 12px;
      font-weight: 500;
      color: #6b7280;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 4px;
    }

    .detail-value {
      font-size: 16px;
      font-weight: 600;
      color: #1f2937;
    }

    .distance-eta-container {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-bottom: 24px;
    }

    .info-box {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 16px;
      border-radius: 12px;
      border: 2px solid #e5e7eb;
      transition: all 0.2s;
    }

    .info-box:hover {
      border-color: #d1d5db;
      background: #f9fafb;
    }

    .distance-box {
      border-color: #bfdbfe;
      background: #eff6ff;
    }

    .eta-box {
      border-color: #86efac;
      background: #f0fdf4;
    }

    .info-box .icon {
      font-size: 28px;
      flex-shrink: 0;
    }

    .info-content {
      display: flex;
      flex-direction: column;
    }

    .info-label {
      font-size: 12px;
      font-weight: 500;
      color: #6b7280;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 2px;
    }

    .info-value {
      font-size: 20px;
      font-weight: 700;
      color: #1f2937;
    }

    .info-subtext {
      font-size: 11px;
      color: #9ca3af;
      margin-top: 2px;
    }

    .modal-message {
      text-align: center;
      margin-bottom: 24px;
    }

    .modal-message p {
      margin: 0;
      font-size: 14px;
      color: #6b7280;
    }

    .modal-footer {
      display: flex;
      gap: 12px;
      padding: 16px 24px 24px;
      border-top: 1px solid #e5e7eb;
    }

    .btn {
      flex: 1;
      padding: 12px 16px;
      border: none;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    }

    .btn-cancel {
      background: #e5e7eb;
      color: #1f2937;
    }

    .btn-cancel:hover {
      background: #d1d5db;
    }

    .btn-next {
      background: #007aff;
      color: white;
    }

    .btn-next:hover {
      background: #005fcc;
    }

    .btn-next:active {
      transform: scale(0.98);
    }
  `;

  document.head.appendChild(styles);
}

// ------------------------
// Fetch branches and create clickable markers
// ------------------------
let allBranches = [];
fetch("/api/branches")
  .then(res => res.json())
  .then(branches => {
    allBranches = branches;

    branches.forEach(branch => {
      const [lon, lat] = branch.location.coordinates;
      const marker = L.marker([lat, lon], { icon: branchIcon, title: branch.branchName }).addTo(map);
      branchMarkers[branch._id] = { marker, data: branch, latlng: L.latLng(lat, lon) };

      marker.on("click", () => {
        fetch(`/api/routes?branchID=${branch._id}`)
          .then(res => res.json())
          .then(routes => showBranchRoutes(branch, routes))
          .catch(console.error);
      });
    });

    initGeolocation();
    initTrucks();
  })
  .catch(err => console.error("Error fetching branches:", err));

// ------------------------
// Geolocation
// ------------------------
function initGeolocation() {
  if (!navigator.geolocation) { alert("Geolocation not supported"); return; }

  navigator.geolocation.getCurrentPosition(
    pos => handleUserPositionUpdate(pos.coords),
    err => console.error(err),
    { enableHighAccuracy: true, timeout: 5000 }
  );

  navigator.geolocation.watchPosition(
    pos => handleUserPositionUpdate(pos.coords),
    err => console.error(err),
    { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 }
  );
}

function handleUserPositionUpdate(coords) {
  const { latitude, longitude } = coords;
  const userId = "user";

  // Store user location globally
  userLocation = { latitude, longitude };

  if (markers[userId]) markers[userId].setLatLng([latitude, longitude]);
  else {
    markers[userId] = L.marker([latitude, longitude], { icon: deviceIcon })
      .addTo(map)
      .bindPopup("You are here")
      .openPopup();
  }

  map.setView([latitude, longitude], 13);

  let closest = null, minDist = Infinity;
  allBranches.forEach(branch => {
    const [lon, lat] = branch.location.coordinates;
    const dist = getDistance(latitude, longitude, lat, lon);
    if (dist < minDist) { minDist = dist; closest = { id: branch._id, data: branch, latlng: L.latLng(lat, lon) }; }
  });
  if (!closest) return;

  if (lastClosestBranchId !== closest.id) {
    lastClosestBranchId = closest.id;

    closestBranchBanner.innerHTML = `Closest branch: <b>${closest.data.branchName}</b>`;
    closestBranchBanner.style.display = "block";
    setTimeout(() => closestBranchBanner.style.display = "none", 5000);

    if (routeLayers.userToBranch) { map.removeLayer(routeLayers.userToBranch); delete routeLayers.userToBranch; }
    const start = `${longitude},${latitude}`;
    const end = `${closest.latlng.lng},${closest.latlng.lat}`;
    fetch(`/api/route?start=${start}&end=${end}`)
      .then(r => r.json())
      .then(data => {
        const feat = data.features?.[0]; if (!feat) return;
        routeLayers.userToBranch = drawORSFeature(feat, { color: "blue", weight: 5 }).addTo(map);
        map.fitBounds(routeLayers.userToBranch.getBounds());
      })
      .catch(console.error);
  }
}

// ------------------------
// Fetch and render all trucks
// ------------------------
function initTrucks() {
  fetch("/api/trucks")
    .then(res => res.json())
    .then(trucks => {
      trucks.forEach(truck => {
        let coords = truck.currentLocation?.coordinates;

        if (!coords || coords.length !== 2) {
          const branch = allBranches.find(b => b._id === truck.branchID?._id);
          coords = branch?.location?.coordinates || [79.8612, 6.9271];
        }

        const [lon, lat] = coords;
        const marker = L.marker([lat, lon], { icon: truckIcon })
          .addTo(map)
          .bindPopup(getTruckPopupContent(truck));
        truckMarkers[truck._id] = marker;
      });
    })
    .catch(err => console.error("Error fetching trucks:", err));
}

// ------------------------
// Truck socket updates
// ------------------------
socket.on("update-truck-location", ({ truckID, lat, lon, status, truckNumber, colour }) => {
  const truckData = { _id: truckID, truckNumber, colour, status };

  if (truckMarkers[truckID]) {
    truckMarkers[truckID].setLatLng([lat, lon]);
    const popup = truckMarkers[truckID].getPopup();
    if (popup) popup.setContent(getTruckPopupContent(truckData));
  } else {
    const marker = L.marker([lat, lon], { icon: truckIcon })
      .addTo(map)
      .bindPopup(getTruckPopupContent(truckData));
    truckMarkers[truckID] = marker;
  }
});

// ------------------------
// Handle "Request Order" button clicks - SHOW MODAL
// ------------------------
document.addEventListener("click", (e) => {
  if (e.target && e.target.classList.contains("request-order-btn")) {
    const truckID = e.target.dataset.truckId;
    const truckNumber = e.target.dataset.truckNumber;

    // Get truck data from markers
    const truckMarker = truckMarkers[truckID];
    if (!truckMarker || !userLocation) {
      alert("Unable to calculate distance. Please try again.");
      return;
    }

    const markerLatLng = truckMarker.getLatLng();
    const distanceMeters = calculateHaversineDistance(
      userLocation.latitude,
      userLocation.longitude,
      markerLatLng.lat,
      markerLatLng.lng
    );
    const eta = calculateETA(distanceMeters);

    // Create truck data object
    const truckData = {
      _id: truckID,
      truckNumber: truckNumber,
      colour: 'N/A' // You can enhance this if you store color in markers
    };

    // Show the modal
    showRequestModal(truckData, distanceMeters, eta);
  }
});

// ------------------------
// Branch popup handling
// ------------------------
function showBranchRoutes(branch, routes) {
  const popupBox = document.getElementById("branch-routes-popup");
  const popupTitle = document.getElementById("branch-popup-title");
  const routesContainer = document.getElementById("branch-popup-routes");

  popupTitle.innerText = branch.branchName;
  routesContainer.innerHTML = "";

  if (!routes.length) routesContainer.innerHTML = "<p>No routes available.</p>";
  else routes.forEach(route => {
    const btn = document.createElement("button");
    btn.classList.add("route-btn");
    btn.textContent = `${route.start.name} → ${route.end.name}`;
    btn.onclick = () => {
      if (routeLayers.userToBranch) { map.removeLayer(routeLayers.userToBranch); delete routeLayers.userToBranch; }
      if (routeLayers.branchRoute) { map.removeLayer(routeLayers.branchRoute); delete routeLayers.branchRoute; }

      const start = `${route.start.location.coordinates[0]},${route.start.location.coordinates[1]}`;
      const end = `${route.end.location.coordinates[0]},${route.end.location.coordinates[1]}`;
      fetch(`/api/route?start=${start}&end=${end}`)
        .then(r => r.json())
        .then(data => {
          const feat = data.features?.[0]; if (!feat) return;

          routeLayers.branchRoute = drawORSFeature(feat, { color: "red", weight: 5 }).addTo(map);

          const bounds = routeLayers.branchRoute.getBounds();
          map.flyToBounds(bounds, { padding: [60, 60], maxZoom: 15 });
        })
        .catch(console.error);
    };
    routesContainer.appendChild(btn);
  });

  popupBox.style.display = "block";
}

document.getElementById("branch-popup-close").addEventListener("click", () => {
  const popupBox = document.getElementById("branch-routes-popup");
  popupBox.style.display = "none";
  if (routeLayers.branchRoute) { map.removeLayer(routeLayers.branchRoute); delete routeLayers.branchRoute; }
});