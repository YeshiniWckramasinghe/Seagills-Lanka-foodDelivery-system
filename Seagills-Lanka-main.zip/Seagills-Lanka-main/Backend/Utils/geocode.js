const axios = require("axios");

async function geocodeAddress(address) {
  if (!address || address.trim() === "") return null;

  try {
    const encoded = encodeURIComponent(address);
    const url = `https://nominatim.openstreetmap.org/search?q=${encoded}&format=json&limit=1`;

    const response = await axios.get(url, {
      headers: { "User-Agent": "Seagills-Lanka-App" } // required by Nominatim
    });

    const data = response.data;
    if (!data || !data.length) return null;

    return {
      latitude: parseFloat(data[0].lat),
      longitude: parseFloat(data[0].lon),
    };
  } catch (error) {
    console.error("OSM geocoding error:", error.message);
    return null;
  }
}

module.exports = geocodeAddress;