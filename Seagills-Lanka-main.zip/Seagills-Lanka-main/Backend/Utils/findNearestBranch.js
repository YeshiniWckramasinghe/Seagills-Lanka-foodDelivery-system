const geocodeAddress = require("./geocode");
const Branch = require("../Model/BranchModel");

// Haversine formula
function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Extract city name from address
function extractCity(address) {
  if (!address) return "";
  const parts = address.split(",");
  return parts[parts.length - 1].trim(); // last part after comma
}

// Find nearest branch
async function findNearestBranch(address) {
  let coords = await geocodeAddress(address);

  // If full address fails, try only city
  if (!coords) {
    const city = extractCity(address);
    coords = await geocodeAddress(city);
  }

  if (!coords) throw new Error("Could not find coordinates for this address.");

  const branches = await Branch.find();
  if (!branches.length) throw new Error("No branches found.");

  let nearestBranch = null;
  let minDistance = Infinity;

  for (const branch of branches) {
    const branchCoords = branch.location.coordinates; // [lon, lat]
    if (!branchCoords || branchCoords.length < 2) continue;

    const distance = getDistanceFromLatLonInKm(
      coords.latitude,
      coords.longitude,
      branchCoords[1], // lat
      branchCoords[0]  // lon
    );

    if (distance < minDistance) {
      minDistance = distance;
      nearestBranch = branch;
    }
  }

  if (!nearestBranch) throw new Error("No branch found near this address.");

  return nearestBranch._id;
}

module.exports = findNearestBranch;
