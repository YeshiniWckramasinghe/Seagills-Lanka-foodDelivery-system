// Backend/Model/CategoryDefaultStock.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

const categoryDefaultStockSchema = new Schema(
  {
    category: {
      type: String,
      enum: ["fish", "meat", "veg & spices", "fruits"],
      required: true,
      unique: true, // Only one default stock config per category
    },
    products: [
      {
        productID: {
          type: Schema.Types.ObjectId,
          ref: "Product",
          required: true,
        },
        productName: {
          type: String,
          required: true,
        },
        quantity: {
          type: Number,
          required: true,
          min: 0,
        },
        unit: {
          type: String,
          enum: ["kg", "g", "nos", "pcs", "bunch"],
          default: "pcs",
        },
      },
    ],
    lastUpdatedBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: false, // Admin who last updated
    },
    lastUpdatedAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

const CategoryDefaultStock =
  mongoose.models.CategoryDefaultStock ||
  mongoose.model("CategoryDefaultStock", categoryDefaultStockSchema);

module.exports = CategoryDefaultStock;
