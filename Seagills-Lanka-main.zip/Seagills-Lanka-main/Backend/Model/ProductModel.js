// Backend/Model/ProductModel.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

const productSchema = new Schema(
  {
    productName: { type: String, required: true },
    productDescription: { type: String },
    category: { type: String, required: true },
    price: { type: Number, required: true },
    weightInKg: { type: Number, default: 0 },
    unit: {
      type: String,
      required: true,
      enum: ["kg", "g", "nos", "pcs", "bunch"],
    },
    productImage: { type: String },
  },
  { timestamps: true }
);

const Product =
  mongoose.models.Product || mongoose.model("Product", productSchema);
module.exports = Product;
