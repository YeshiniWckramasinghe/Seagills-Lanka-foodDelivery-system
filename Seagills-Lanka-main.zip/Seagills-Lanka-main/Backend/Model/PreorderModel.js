// Backend/Model/PreorderModel.js
//CONTAINS PREORDER + PREORDERPRODUCT CAZ THEY'RE CLOSELY TIED
const mongoose = require("mongoose");
const { Schema } = mongoose;

// Preorder
const preorderSchema = new Schema(
  {
    orderDate: { type: Date, required: true },
    deliveryDate: { type: Date, required: true },
    orderStatus: { type: String, required: true },
    totalAmount: { type: Number, required: true },
    // validate the role in your CONTROLLER when adding a new record:
    //const user = await User.findById(stockManagerID);
    //if (user.role !== 'RegisteredCustomer') throw new Error('Invalid RegisteredCustomer');
    registeredCustomerID: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    }, // FK -> User
    branchID: { type: Schema.Types.ObjectId, ref: "Branch", required: true }, // FK -> Branch
    // Payment-related fields
    paymentMethod: {
      type: String,
      enum: ["cash", "card"],
      required: true,
      default: "cash",
    },
    paymentStatus: {
      type: String,
      enum: ["Pending", "Completed", "Failed"],
      required: true,
      default: "Pending",
    },

    address: { type: String, required: true },

    lastUpdated: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

const Preorder = mongoose.model("Preorder", preorderSchema);

// PreorderProduct (M:N between Preorder and Product)
const preorderProductSchema = new Schema(
  {
    preorderID: {
      type: Schema.Types.ObjectId,
      ref: "Preorder",
      required: true,
    },
    productID: { type: Schema.Types.ObjectId, ref: "Product", required: true },
    quantity: { type: Number, required: true },
    unit: {
      type: String,
      enum: ["kg", "g", "nos", "pcs", "bunch"],
      required: true,
    },
  },
  { timestamps: true }
);

// Ensure uniqueness for combination
preorderProductSchema.index({ preorderID: 1, productID: 1 }, { unique: true });

const PreorderProduct =
  mongoose.models.PreorderProduct ||
  mongoose.model("PreorderProduct", preorderProductSchema);

module.exports = { Preorder, PreorderProduct };
