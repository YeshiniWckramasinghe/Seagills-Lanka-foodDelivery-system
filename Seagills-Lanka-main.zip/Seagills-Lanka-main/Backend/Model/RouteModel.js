// Model/RouteModel.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

const routeSchema = new Schema({
  start: {
    name: { type: String, required: true },
    location: {
      type: { type: String, enum: ["Point"], default: "Point" },
      coordinates: { type: [Number], required: true } // [lon, lat]
    }
  },
  end: {
    name: { type: String, required: true },
    location: {
      type: { type: String, enum: ["Point"], default: "Point" },
      coordinates: { type: [Number], required: true }
    }
  },
  branchID: { type: Schema.Types.ObjectId, ref: "Branch", required: true }
}, { timestamps: true });

routeSchema.index({ "start.location": "2dsphere" });
routeSchema.index({ "end.location": "2dsphere" });

const Route = mongoose.models.Route || mongoose.model("Route", routeSchema);
module.exports = Route;
