const mongoose = require('mongoose');
const { Schema } = mongoose;

const suppliedProductSchema = new Schema({
  supplierID: { type: Schema.Types.ObjectId, ref: 'Supplier', required: true },
  productID: { type: Schema.Types.ObjectId, ref: 'Product', required: true },
  suppliedDate: { type: Date, required: true }
}, { timestamps: true });

// Ensure uniqueness for combination (a supplier supplies a specific product once per entry)
suppliedProductSchema.index({ supplierID: 1, productID: 1 }, { unique: true });

const SuppliedProduct =  mongoose.models.SuppliedProduct || mongoose.model('SuppliedProduct', suppliedProductSchema);

module.exports = SuppliedProduct;
