// Backend/Model/UserModel.js
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const { Schema } = mongoose;

// Base User Schema
const userSchema = new Schema(
  {
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    firstName: { type: String },
    lastName: { type: String },
    email: { type: String, unique: true },
    telephone: { type: String },
    role: {
      type: String,
      required: true,
      enum: [
        "Admin",
        "RegisteredCustomer",
        "StockManager",
        "DeliveryCoordinator",
        "TruckDriver"
      ],
    },
  },
  { discriminatorKey: "role", timestamps: true }
);

const User = mongoose.models.User || mongoose.model("User", userSchema);

// Discriminators
const Admin = User.discriminators?.Admin || User.discriminator("Admin", new Schema({}));
const RegisteredCustomer = User.discriminators?.RegisteredCustomer || User.discriminator("RegisteredCustomer", new Schema({}));
const StockManager = User.discriminators?.StockManager || User.discriminator("StockManager", new Schema({}));
const DeliveryCoordinator = User.discriminators?.DeliveryCoordinator || User.discriminator(
  "DeliveryCoordinator",
  new Schema({ branchID: { type: Schema.Types.ObjectId, ref: "Branch", required: true } })
);
const TruckDriver = User.discriminators?.TruckDriver || User.discriminator(
  "TruckDriver",
  new Schema({
    licenseNumber: { type: String, required: true },
    assignedTruck: { type: Schema.Types.ObjectId, ref: "Truck", default: null },
  })
);

module.exports = {
  User,
  Admin,
  RegisteredCustomer,
  StockManager,
  DeliveryCoordinator,
  TruckDriver
};
