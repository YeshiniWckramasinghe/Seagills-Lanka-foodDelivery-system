// Backend/Model/EnrouteOrderModel.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

const enrouteOrderSchema = new Schema(
  {
    customerLocation: { type: String, required: true },
    contactNum: { type: String, required: true },
    date: { type: Date, default: Date.now },
    deliveryCoordinatorID: {
      type: Schema.Types.ObjectId,
      ref: "DeliveryCoordinator",
      required: true,
    },
    note: { type: String, default: "" },

    products: [
      {
        productID: {
          type: Schema.Types.ObjectId,
          ref: "Product",
          required: true,
        },
        quantity: { type: Number, required: true, min: 1 },
        unitPrice: { type: Number, required: true, min: 0 },
        unit: {
          type: String,
          enum: ["kg", "g", "nos", "pcs", "bunch"],
          required: true,
        },
      },
    ],
    paymentMethod: {
      type: String,
      enum: ["cash", "card"],
      default: "cash",
      required: true,
    },
    status: {
      type: String,
      enum: [
        "pending",
        "Pending",
        "delivered",
        "Completed",
        "failed",
        "Failed",
      ],
      default: "pending",
    },
    lastUpdated: { type: Date, default: Date.now },
    // Acceptance tracking
    acceptedAt: { type: Date },
    estimatedArrival: { type: Date },
    coordinatorNotes: { type: String, default: "" },

    // Rejection tracking
    rejectedAt: { type: Date },
    rejectionReason: { type: String },

    // Delivery tracking
    deliveredAt: { type: Date },
    // Billing integration (for POS system integration)
    billGenerated: { type: Boolean, default: false },
    totalAmount: { type: Number, default: 0 },
    paymentStatus: {
      type: String,
      enum: [
        "pending",
        "Pending",
        "delivered",
        "Completed",
        "failed",
        "Failed",
      ],
      default: "pending",
    },
    billNumber: { type: String },
  },
  { timestamps: true }
);

const EnrouteOrder =
  mongoose.models.EnrouteOrder ||
  mongoose.model("EnrouteOrder", enrouteOrderSchema);

module.exports = EnrouteOrder;
