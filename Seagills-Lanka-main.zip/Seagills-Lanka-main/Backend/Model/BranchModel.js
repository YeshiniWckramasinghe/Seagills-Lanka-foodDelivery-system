const mongoose = require('mongoose');
const { Schema } = mongoose;

// Branch Schema
const branchSchema = new Schema({
  branchName: { type: String, required: true, unique: true },
  branchAddress: { type: String, required: true },
  location: {
    type: {
      type: String,
      enum: ['Point'],
      required: true,
      default: 'Point'
    },
    coordinates: {
      type: [Number], // [longitude, latitude]
      required: true,
      default: [0, 0] // fallback
    }
  }
}, { timestamps: true });

// Create 2dsphere index for geospatial queries
branchSchema.index({ location: '2dsphere' });
// Safe model creation to prevent OverwriteModelError
const Branch = mongoose.models.Branch || mongoose.model('Branch', branchSchema);
module.exports = Branch;
