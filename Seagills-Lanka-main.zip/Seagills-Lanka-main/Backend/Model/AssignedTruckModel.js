// Backend/Model/AssignedTruckModel.js
const mongoose = require("mongoose");

const assignedTruckSchema = new mongoose.Schema(
  {
    truckID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Truck",
      required: true,
    },
    driverID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    deliveryCoordinatorID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    date: { type: Date, required: true },
  },
  { timestamps: true }
);

// Ensure uniqueness
// assignedTruckSchema.index(
//   { truckID: 1, driverID: 1, deliveryCoordinatorID: 1, date: 1 },
//   { unique: true }
// );

// One truck per day
assignedTruckSchema.index({ truckID: 1, date: 1 }, { unique: true });

// One driver per day
assignedTruckSchema.index({ driverID: 1, date: 1 }, { unique: true });

// One delivery coordinator per day
assignedTruckSchema.index(
  { deliveryCoordinatorID: 1, date: 1 },
  { unique: true }
);

// Use safe model creation to prevent OverwriteModelError
const AssignedTruck =
  mongoose.models.AssignedTruck ||
  mongoose.model("AssignedTruck", assignedTruckSchema);
module.exports = AssignedTruck;
