// Backend/Model/DailyLoadingModel.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

const dailyLoadingSchema = new Schema(
  {
    truckID: { type: Schema.Types.ObjectId, ref: "Truck", required: true },
    coordinatorID: {
      type: Schema.Types.ObjectId,
      ref: "DeliveryCoordinator",
      required: true,
    },
    category: {
      type: String,
      enum: ["fish", "meat", "veg&spices", "fruits"],
      required: true,
    },
    date: { type: Date, required: true },

    // This array holds the products from pre-orders
    loadedPreorderProducts: [
      {
        preorderProductID: {
          type: Schema.Types.ObjectId,
          ref: "PreorderProduct",
          required: true,
        },
      },
    ],

    // This array holds the default stock loaded onto the truck
    loadedStockItems: [
      {
        productID: {
          type: Schema.Types.ObjectId,
          ref: "Product",
          required: true,
        },
        quantity: { type: Number, required: true },
        unit: {
          type: String,
          enum: ["kg", "g", "nos", "pcs", "bunch"],
          default: "pcs",
        },
      },
    ],

    // Auto-calculated total weight from both loadedPreorderProducts and loadedStockItems
    totalWeight: { type: Number, default: 0 },
    loadingStartTime: { type: Date },
    loadingEndTime: { type: Date },
    status: {
      type: String,
      enum: ["loading", "completed", "departed"],
      default: "loading",
    },
  },
  { timestamps: true }
);

// Prevent duplicate truck assignments on same date
dailyLoadingSchema.index({ truckID: 1, date: 1 }, { unique: true });
// Safe model creation
const DailyLoading =
  mongoose.models.DailyLoading ||
  mongoose.model("DailyLoading", dailyLoadingSchema);
module.exports = DailyLoading;
