const mongoose = require('mongoose');
const { Schema } = mongoose;

const paymentSchema = new Schema({
  amount: { type: Number, required: true },
  paymentStatus: { type: String, required: true, enum: ['Pending', 'Completed', 'Failed'] },
  paymentMethod: { type: String, required: true, enum: ['Cash', 'Card', 'Online'] },
  preorderID: { type: Schema.Types.ObjectId, ref: 'Preorder', required: true } // 1:1 with Preorder
}, { timestamps: true });

//enforce 1:1 relationship between preorder + payment 
paymentSchema.index({ preorderID: 1 }, { unique: true });

const Payment = mongoose.models.Payment || mongoose.model('Payment', paymentSchema);

module.exports = Payment;
