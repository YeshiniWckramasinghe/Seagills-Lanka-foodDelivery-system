const mongoose = require('mongoose');
const { Schema } = mongoose;

const reportSchema = new Schema({
  pdfLink: { type: String, required: true }, // Path or cloud storage URL
  title: { type: String, required: true },
  description: { type: String },
  type: { type: String, required: true },
}, { timestamps: { createdAt: 'createdTimestamp', updatedAt: false } }); 
// For Report, I customized timestamps so it only stores createdTimestamp and not updatedAt (since reports usually aren’t “updated,” they’re generated once).

const Report = mongoose.models.Report ||  mongoose.model('Report', reportSchema);

module.exports = Report;
