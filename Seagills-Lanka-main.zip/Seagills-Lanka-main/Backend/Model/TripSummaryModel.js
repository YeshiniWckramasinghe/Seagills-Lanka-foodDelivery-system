// Backend/Model/TripSummaryModel.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

// Summarize daily trip details for trucks
const tripSummarySchema = new Schema(
  {
    // Trip identification
    truckID: {
      type: Schema.Types.ObjectId,
      ref: "Truck",
      required: true,
    },
    coordinatorID: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    driverID: {
      type: Schema.Types.ObjectId,
      ref: "Driver",
      required: true,
    },
    routeID: {
      type: Schema.Types.ObjectId,
      ref: "Route",
    },

    tripDate: {
      type: Date,
      required: true,
    },

    // Loading summary
    loadingSummary: {
      category: String,
      totalWeight: Number,
      loadingStartTime: Date,
      loadingEndTime: Date,
      loadedPreorderCount: Number,
      loadedStockItemsCount: Number,
    },

    // Delivery statistics
    deliveryStats: {
      totalPreorders: { type: Number, default: 0 },
      deliveredPreorders: { type: Number, default: 0 },
      failedPreorders: { type: Number, default: 0 },
      pendingPreorders: { type: Number, default: 0 },

      totalEnrouteOrders: { type: Number, default: 0 },
      deliveredEnrouteOrders: { type: Number, default: 0 },
      pendingEnrouteOrders: { type: Number, default: 0 },
    },

    // Payment summary
    paymentSummary: {
      totalPreorderAmount: { type: Number, default: 0 },
      collectedPreorderAmount: { type: Number, default: 0 },
      pendingPreorderAmount: { type: Number, default: 0 },

      totalEnrouteAmount: { type: Number, default: 0 },
      collectedEnrouteAmount: { type: Number, default: 0 },

      cashCollected: { type: Number, default: 0 },
      cardCollected: { type: Number, default: 0 },
      totalCollected: { type: Number, default: 0 },
    },

    // Incidents during trip
    incidentCount: {
      type: Number,
      default: 0,
    },
    incidentIds: [
      {
        type: Schema.Types.ObjectId,
        ref: "Incident",
      },
    ],

    // Trip timing
    tripStartTime: {
      type: Date,
    },
    tripEndTime: {
      type: Date,
    },
    tripDurationMinutes: {
      type: Number,
    },

    // Status
    tripStatus: {
      type: String,
      enum: ["completed", "partial", "failed"],
      default: "completed",
    },

    // Coordinator notes
    coordinatorNotes: {
      type: String,
    },

    // System notes
    submittedAt: {
      type: Date,
      default: Date.now,
    },

    // Approval workflow
    isApproved: {
      type: Boolean,
      default: false,
    },
    approvedBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
    },
    approvedAt: {
      type: Date,
    },
  },
  { timestamps: true }
);

// Ensure one summary per truck per day
tripSummarySchema.index({ truckID: 1, tripDate: 1 }, { unique: true });

const TripSummary =
  mongoose.models.TripSummary ||
  mongoose.model("TripSummary", tripSummarySchema);
module.exports = TripSummary;
