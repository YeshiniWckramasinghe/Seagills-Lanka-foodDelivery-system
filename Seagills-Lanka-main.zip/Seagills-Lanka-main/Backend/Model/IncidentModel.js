// Backend/Model/IncidentModel.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

// Record breakdowns or delays with details
const incidentSchema = new Schema(
  {
    // Link to the truck and coordinator
    truckID: {
      type: Schema.Types.ObjectId,
      ref: "Truck",
      required: true,
    },
    coordinatorID: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    // Incident details
    incidentType: {
      type: String,
      enum: ["breakdown", "delay", "accident", "other"],
      required: true,
    },

    description: {
      type: String,
      required: true,
    },

    // Location and time
    location: {
      type: String,
      required: true,
    },

    incidentTime: {
      type: Date,
      required: true,
    },

    // Duration of incident (in minutes)
    durationInMinutes: {
      type: Number,
    },

    // What caused it
    cause: {
      type: String,
    },

    // Resolution details
    resolutionAction: {
      type: String,
    },

    resolvedAt: {
      type: Date,
    },

    // Severity
    severity: {
      type: String,
      enum: ["low", "medium", "high", "critical"],
      default: "medium",
    },

    // Status
    status: {
      type: String,
      enum: ["reported", "in-progress", "resolved"],
      default: "reported",
    },

    // Date of the trip this incident belongs to
    tripDate: {
      type: Date,
      required: true,
    },

    // Admin notes for follow-up actions
    adminNotes: {
      type: String,
    },
  },
  { timestamps: true }
);

// Index for efficient querying
incidentSchema.index({ truckID: 1, tripDate: 1 });
incidentSchema.index({ coordinatorID: 1, tripDate: 1 });

const Incident =
  mongoose.models.Incident || mongoose.model("Incident", incidentSchema);
module.exports = Incident;
