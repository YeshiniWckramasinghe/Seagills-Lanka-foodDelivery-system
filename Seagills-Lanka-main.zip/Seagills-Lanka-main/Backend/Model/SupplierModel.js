const mongoose = require('mongoose');
const { Schema } = mongoose;

const supplierSchema = new Schema({
  supplierName: { type: String, required: true },
  contactNum: { type: String, required: true },
  websiteLink: { type: String }
}, { timestamps: true });

const Supplier = mongoose.models.Supplier || mongoose.model('Supplier', supplierSchema);

module.exports = Supplier;
