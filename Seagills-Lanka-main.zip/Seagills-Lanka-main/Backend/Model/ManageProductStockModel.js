//ManageProductStock (ternary relationship between StockManager + Product + Branch
//to track what stock manager

const mongoose = require('mongoose');
const { Schema } = mongoose;

const manageProductStockSchema = new Schema({
  productID: { type: Schema.Types.ObjectId, ref: 'Product', required: true },
  branchID: { type: Schema.Types.ObjectId, ref: 'Branch', required: true },
  // validate the role in your CONTROLLER when adding a new reocrd:
    //const user = await User.findById(stockManagerID);
    //if (user.role !== 'StockManager') throw new Error('Invalid StockManager');
  stockManagerID: { type: Schema.Types.ObjectId, ref: 'User', required: true }, // must be StockManager
  stockLevel: { type: Number, required: true },
  lastRestockedDate: { type: Date }
}, { timestamps: true });

// Unique combo for ternary relationship
manageProductStockSchema.index({ productID: 1, branchID: 1, stockManagerID: 1 }, { unique: true });

const ManageProductStock = mongoose.models.ManageProductStock ||  mongoose.model('ManageProductStock', manageProductStockSchema);
module.exports = ManageProductStock;
