// Backend/Model/TruckRouteModel.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

const truckRouteSchema = new Schema(
  {
    truckID: { type: Schema.Types.ObjectId, ref: "Truck", required: true },
    routeID: { type: Schema.Types.ObjectId, ref: "Route", required: true },
    date: { type: Date, required: true },
    startTime: { type: String, required: true }, // Scheduled start time (HH:MM format)
    endTime: { type: String, required: false }, // Actual end time when trip closes
    tripStartedAt: { type: Date, required: false }, // Timestamp when coordinator clicks "Start Daily Run"
    tripCompletedAt: { type: Date, required: false }, // Timestamp when trip is closed
    tripStatus: {
      type: String,
      enum: ["scheduled", "in_progress", "completed"],
      default: "scheduled",
    },
  },
  { timestamps: true }
);

// Ensure uniqueness (composite PK equivalent)
truckRouteSchema.index(
  { truckID: 1, routeID: 1, date: 1, startTime: 1 },
  { unique: true }
);

const TruckRoute =
  mongoose.models.TruckRoute || mongoose.model("TruckRoute", truckRouteSchema);
module.exports = TruckRoute;
