const mongoose = require("mongoose");

const truckSchema = new mongoose.Schema({
  truckNumber: { type: String, required: true, unique: true },
  plateNo: { type: String },
  colour: { type: String },
  branchID: { type: mongoose.Schema.Types.ObjectId, ref: "Branch", required: true },
  currentLocation: {
    type: { type: String, enum: ["Point"], default: "Point" },
    coordinates: { type: [Number], default: [0, 0] }, // [lng, lat]
  },
  status: {
    type: String,
    enum: ["idle", "assigned", "enroute", "delivered"],
    default: "idle",
  },
}, { timestamps: true });

truckSchema.index({ currentLocation: "2dsphere" });

// Pre-save hook: if truck is new, set currentLocation to branch location
truckSchema.pre("save", async function (next) {
  if (this.isNew && this.branchID) {
    const Branch = mongoose.model("Branch");
    const branch = await Branch.findById(this.branchID);
    if (branch?.location?.coordinates?.length === 2) {
      this.currentLocation.coordinates = branch.location.coordinates;
    }
  }
  next();
});

const Truck = mongoose.models.Truck || mongoose.model("Truck", truckSchema);
module.exports = Truck;
