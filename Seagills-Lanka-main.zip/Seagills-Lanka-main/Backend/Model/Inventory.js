// models/Inventory.js
const mongoose = require('mongoose');
//
const inventorySchema = new mongoose.Schema({
  productName: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true
  },
  sku: {
    type: String,
    required: [true, 'SKU is required'],
    unique: true,
    trim: true
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    trim: true
  },
  price: {
    type: Number,
    required: [true, 'Price is required'],
    min: [0, 'Price cannot be negative']
  },
  
  description: {
    type: String,
    trim: true
  },
  lowStockThreshold: {
    type: Number,
    default: 10
  }
}, {
  timestamps: true
});

// Virtual for stock status
inventorySchema.virtual('stockStatus').get(function() {
  if (this.quantity === 0) return 'out-of-stock';
  if (this.quantity <= this.lowStockThreshold) return 'low-stock';
  return 'in-stock';
});

// Index for better search performance
inventorySchema.index({ productName: 'text', category: 'text', sku: 'text' });

module.exports = mongoose.model('Inventory', inventorySchema);