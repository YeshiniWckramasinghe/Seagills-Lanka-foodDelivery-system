// Backend/Model/DriverModel.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

const driverSchema = new Schema(
  {
    driverName: { type: String, required: true },
    driverTelephone: { type: String, required: true, unique: true },
  },
  { timestamps: true }
);

const Driver = mongoose.models.Driver || mongoose.model("Driver", driverSchema);
module.exports = Driver;
