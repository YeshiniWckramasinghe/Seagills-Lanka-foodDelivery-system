//Mongoose doesn’t support composite PKs natively. 
// We just make productID + offerCode unique together:

const mongoose = require('mongoose');
const { Schema } = mongoose;

const offerSchema = new Schema({
  productID: { type: Schema.Types.ObjectId, ref: 'Product', required: true },
  offerCode: { type: String, required: true },
  offerDescription: { type: String }
}, { timestamps: true });

// Ensure uniqueness for combination (caz partial keys arent supporte,so this enusresthey are unique together)
offerSchema.index({ productID: 1, offerCode: 1 }, { unique: true });

const Offer =  mongoose.models.Offer || mongoose.model('Offer', offerSchema);
module.exports = Offer;
