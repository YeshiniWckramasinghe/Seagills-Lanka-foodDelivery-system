// Backend/app.js

// Dependencies
const express = require("express");
const mongoose = require("mongoose");
const http = require("http");
const socketio = require("socket.io");
const path = require("path");
require("dotenv").config();

const cors = require("cors");

// Models
const Truck = require("./Model/TruckModel");
const AssignedTruck = require("./Model/AssignedTruckModel");
const Branch = require("./Model/BranchModel");

const app = express();

// ------------------------
// Middleware
// ------------------------
app.use(
  cors({
    origin: "http://localhost:3000",
    methods: ["GET", "POST", "PATCH", "PUT", "DELETE"],
    credentials: true,
  })
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "public")));

// ------------------------
// Routers
// ------------------------

// Middleware setup
app.use(cors());

// Body parser middleware
app.use(express.json());

// Middleware to parse URL-encoded data
// Middleware to parse URL-encoded data
app.use(express.urlencoded({ extended: true }));

// *** Add the simple middleware from the 1st version ***
app.use((req, res, next) => {
  console.log("Middleware working...");
  next();
});

// EJS setup
app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "public")));

// Routers

// Routes (import routers)
const userRoutes = require("./Route/UserRoute");
const productRoutes = require("./Route/ProductRoute");

const truckRouter = require("./Route/TruckRoute");
const branchRouter = require("./Route/BranchRoute");
const routeRouter = require("./Route/RouteRoute");
const truckRouteRouter = require("./Route/TruckRouteRoute");
const manageProductStockRoutes = require("./Route/ManageProductStockRoute");
const supplierRoutes = require("./Route/SupplierRoute");
const driverRouter = require("./Route/DriverRoute");
const dailyLoadingRouter = require("./Route/DailyLoadingRoute");
const assignedTruckRouter = require("./Route/AssignedTruckRoute");
const preorderRouter = require("./Route/PreorderRoute");
const enrouteOrderRouter = require("./Route/EnrouteOrderRoute");
const paymentRouter = require("./Route/PaymentRoute");
const incidentRouter = require("./Route/IncidentRoute");
const tripSummaryRouter = require("./Route/TripSummaryRoute");
const orsRoute = require("./Route/ORSRoute"); // OpenRouteService
const reportRoutes = require("./Route/TruckReportRoute"); // Truck reports

const categoryDefaultStockRoutes = require("./Route/CategoryDefaultStockRoute");
const coordinatorSummaryRouter = require("./Route/CoordinatorSummaryRoute");
const inventoryRoutes = require("./Route/inventory"); // Import inventory routes

// Mount routers

app.use("/api/products", productRoutes);
app.use("/api/trucks", truckRouter);
app.use("/api/branches", branchRouter);
app.use("/api/routes", routeRouter);
app.use("/api/truck-routes", truckRouteRouter);
app.use("/api/manage-stock", manageProductStockRoutes);
app.use("/api/suppliers", supplierRoutes);

app.use("/trucks", truckRouter);

// Mount routes with prefixes
app.use("/api/users", userRoutes);
app.use("/api/trucks", truckRouter);

app.use("/branches", branchRouter);
app.use("/routes", routeRouter);
app.use("/truck-routes", truckRouteRouter);

// *** Add the simple routes from 1st version explicitly as well ***
app.use("/api/manage-stock", manageProductStockRoutes);
app.use("/api/suppliers", supplierRoutes);

app.use("/api/inventory", inventoryRoutes); // Use inventory routes

app.use("/api/drivers", driverRouter);
app.use("/api/daily-loadings", dailyLoadingRouter);
app.use("/api/assigned-trucks", assignedTruckRouter);
app.use("/api/preorders", preorderRouter);
app.use("/api/enroute-orders", enrouteOrderRouter);
app.use("/api/payments", paymentRouter);
app.use("/api/incidents", incidentRouter);
app.use("/api/trip-summaries", tripSummaryRouter);
app.use("/api/route", orsRoute);
app.use("/api/category-default-stock", categoryDefaultStockRoutes);
app.use("/api/coordinator-summary", coordinatorSummaryRouter);
app.use("/api/reports", reportRoutes);
// ------------------------
// Routes
// ------------------------
app.get("/", (req, res) => {
  res.render("index");
});

// ------------------------
// Helper: update idle trucks
// ------------------------
const updateTruckLocations = async () => {
  try {
    const trucks = await Truck.find().populate("branchID");
    const today = new Date();
    const startOfDay = new Date(today.setHours(0, 0, 0, 0));
    const endOfDay = new Date(today.setHours(23, 59, 59, 999));

    for (let truck of trucks) {
      const assignment = await AssignedTruck.findOne({
        truckID: truck._id,
        date: { $gte: startOfDay, $lte: endOfDay },
      });

      if (!assignment) {
        truck.status = "idle";
        if (truck.branchID?.location?.coordinates?.length === 2) {
          truck.currentLocation.coordinates =
            truck.branchID.location.coordinates;
        } else {
          truck.currentLocation.coordinates = [79.8612, 6.9271]; // fallback Colombo
        }
      } else {
        truck.status = "assigned";
        // Assigned trucks: location updated via driver socket
      }

      await truck.save();
    }
    console.log("✅ Truck statuses and locations updated");
  } catch (err) {
    console.error("❌ Error updating trucks:", err.message);
  }
};

// ------------------------
// Create HTTP server + socket.io
// ------------------------
const server = http.createServer(app);
const io = socketio(server, {
  cors: { origin: "http://localhost:3000", methods: ["GET", "POST"] },
});

app.use("/api/enroute-orders", enrouteOrderRouter);
app.use("/api/payments", paymentRouter);

// Serve the main page
app.get("/", (req, res) => {
  res.render("index");
});

// Socket.io connection handling
let connectedUsers = 0;

// ------------------------
// Socket.io - USER TRACKING & LOCATION UPDATES
// ------------------------
io.on("connection", (socket) => {
  connectedUsers++;
  console.log(`✅ User connected: ${socket.id}`);
  console.log(`Total users being tracked: ${connectedUsers}`);

  // Receive device location and broadcast to all connected clients
  socket.on("send-location", async (data) => {
    console.log(`📍 Location received from ${socket.id}:`, data);

    // If truckID is provided, update truck in database
    if (data.truckID && data.lat && data.lon) {
      try {
        const updatedTruck = await Truck.findByIdAndUpdate(
          data.truckID,
          {
            currentLocation: {
              type: "Point",
              coordinates: [data.lon, data.lat],
            },
            status: "enroute",
          },
          { new: true }
        );

        if (updatedTruck) {
          console.log(
            `✅ Truck ${updatedTruck.truckNumber} location updated in DB`
          );

          // Broadcast truck location update to all clients
          io.emit("update-truck-location", {
            truckID: updatedTruck._id,
            lat: data.lat,
            lon: data.lon,
            status: updatedTruck.status,
            truckNumber: updatedTruck.truckNumber,
            plateNo: updatedTruck.plateNo,
            colour: updatedTruck.colour,
          });
        }
      } catch (error) {
        console.error("❌ Error updating truck location:", error);
      }
    }

    // Broadcast general location update to all clients (for user tracking on map)
    io.emit("receive-location", { id: socket.id, ...data });
  });

  // Disconnect handler
  socket.on("disconnect", () => {
    connectedUsers--;
    console.log(`❌ User disconnected: ${socket.id}`);
    console.log(`Total users being tracked: ${connectedUsers}`);

    // Notify all clients that this user disconnected
    io.emit("user-disconnected", socket.id);
  });
});

// ------------------------
// MongoDB connection & start server
// ------------------------
mongoose
  .connect(
    "mongodb+srv://seagills_lanka_admin:uEAo9r3DN1CqWCJZ@cluster0.hviaanc.mongodb.net/SeagillsLanka"
  )
  .then(() => {
    console.log("✅ Connected to MongoDB");
    // Update truck locations on server start
    updateTruckLocations();
    server.listen(5000, () =>
      console.log("🚀 Server running on http://localhost:5000")
    );
  })
  .catch((err) => console.error("❌ MongoDB connection error:", err));
