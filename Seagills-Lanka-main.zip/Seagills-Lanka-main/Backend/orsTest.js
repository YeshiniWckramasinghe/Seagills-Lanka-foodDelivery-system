const axios = require("axios");

const API_KEY = "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjhjNTEyM2RhZDA0YjQ1YTRiMTBkNTIyYjZjOTI4MGM4IiwiaCI6Im11cm11cjY0In0="; 

// Example: [lng, lat]
const start = [79.8612, 6.9271]; // Colombo
const end = [80.2170, 6.0535];   // Galle

async function getRoute() {
  try {
    const response = await axios.post(
      "https://api.openrouteservice.org/v2/directions/driving-car/geojson",
      { coordinates: [start, end] },
      {
        headers: {
          Authorization: API_KEY,
          "Content-Type": "application/json",
        },
      }
    );

    console.log("✅ Route GeoJSON:", JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error("❌ Error fetching route:", error.response?.data || error.message);
  }
}

getRoute();
