const express = require("express");
const router = express.Router();
const { getDailyTruckReport } = require("../Controller/TruckReportController");

router.get("/daily/:date", getDailyTruckReport);

module.exports = router;
