// Backend/Route/AssignedTruckRoute.js
const express = require("express");
const router = express.Router();
const assignedTruckController = require("../Controller/AssignedTruckController");

// Assign truck
router.post("/", assignedTruckController.assignTruck);

// Get all assignments
router.get("/", assignedTruckController.getAllAssignments); // <-- make sure getAllAssignments exists in controller

// Get assignments by coordinator
router.get(
  "/coordinator/:coordinatorId",
  assignedTruckController.getAssignmentsByCoordinator
); // must exist

// Get assignments by date
router.get("/date/:date", assignedTruckController.getAssignmentsByDate); // must exist

// ✅ Get driver's assigned truck for today
router.get("/driver/:driverID", assignedTruckController.getDriverTruck);

// Get today's full schedule (assignment + route details) for a coordinator
// GET /api/assigned-trucks/schedule/64f5b2c9e4b0123456789abc/2024-09-19
router.get(
  "/schedule/:coordinatorId/:date",
  assignedTruckController.getCoordinatorDailySchedule
);

// Delete truck assignment by ID
// DELETE /api/assigned-trucks/64f5b2c9e4b0123456789abc
// ✅ Get all trucks
router.get("/trucks", assignedTruckController.getAllTrucks);

// Update assignment
router.put("/:id", assignedTruckController.updateAssignment);

// Delete assignment
router.delete("/:id", assignedTruckController.deleteAssignment);

module.exports = router;
