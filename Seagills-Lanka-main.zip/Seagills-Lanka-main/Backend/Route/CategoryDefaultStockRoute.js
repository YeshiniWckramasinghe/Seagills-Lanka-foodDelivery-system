// Backend/Route/CategoryDefaultStockRoute.js
const express = require("express");
const router = express.Router();
const categoryDefaultStockController = require("../Controller/CategoryDefaultStockController");

// ============ ROUTES ============

// GET: Retrieve default stock for a specific category
router.get(
  "/category/:category",
  categoryDefaultStockController.getDefaultStockByCategory
);

// GET: Retrieve all default stocks (all categories)
router.get("/", categoryDefaultStockController.getAllDefaultStocks);

// POST: Create or update default stock for a category (UPSERT)
router.post("/", categoryDefaultStockController.upsertDefaultStock);

// PUT: Update a specific product quantity in category default stock
router.put(
  "/product/update",
  categoryDefaultStockController.updateProductInDefaultStock
);

// DELETE: Remove a product from category default stock
router.delete(
  "/:category/:productID",
  categoryDefaultStockController.deleteProductFromDefaultStock
);

module.exports = router;
