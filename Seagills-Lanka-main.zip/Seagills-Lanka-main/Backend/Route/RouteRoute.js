// Backend/Route/RouteRoute.js
const express = require("express");
const router = express.Router();
const {
  createRoute,
  getRouteById,
  getAllRoutes,
  updateRoute,
  deleteRoute,
} = require("../Controller/RouteController");

// CREATE a new route
router.post("/", createRoute);

// READ all routes (optionally filtered by branchID)
router.get("/", getAllRoutes);

// READ a single route by ID
router.get("/:id", getRouteById);

// UPDATE a route by ID
router.put("/:id", updateRoute);

// DELETE a route by ID
router.delete("/:id", deleteRoute);

module.exports = router;
