// Backend/Route/TripSummaryRoute.js
const express = require("express");
const router = express.Router();
const tripClosureController = require("../Controller/TripClosureController");
const tripReportPDFController = require("../Controller/TripReportPDFController");

// POST /api/trip-summaries/close
// POST /close - Close trip and generate summary
router.post("/close", tripClosureController.closeTripAndGenerateSummary);

// GET /api/trip-summaries/:id/pdf - Generate and download trip report as PDF
router.get("/:id/pdf", tripReportPDFController.generateTripReportPDF);

// GET /api/trip-summaries/
// GET / - Get all summaries with filters
router.get("/", tripClosureController.getAllTripSummaries);

// GET /api/trip-summaries/truck/:truckId?date=YYYY-MM-DD
// GET /truck/:truckId - Get summary by truck and date
router.get(
  "/truck/:truckId",
  tripClosureController.getTripSummaryByTruckAndDate
);

// GET /api/trip-summaries/coordinator/:coordinatorId
// GET /coordinator/:coordinatorId - Get coordinator summaries (with date/status filters)
router.get(
  "/coordinator/:coordinatorId",
  tripClosureController.getTripSummariesByCoordinator
);

// GET /api/trip-summaries/:id/report
// GET /:id/report - Generate detailed report for a specific trip summary
router.get("/:id/report", tripClosureController.generateDetailedTripReport);

// PATCH /api/trip-summaries/:id/approve
// PATCH /:id/approve - Approve trip summary (Requires admin/manager role authentication)
router.patch("/:id/approve", tripClosureController.approveTripSummary);

module.exports = router;
