const express = require("express");
const router = express.Router();
const {
  createTruck,
  getTruckById,
  getAllTrucks,
  updateTruck,
  deleteTruck,
} = require("../Controller/TruckController");

router.post("/", createTruck);
router.get("/", getAllTrucks);
router.get("/:id", getTruckById);
router.put("/:id", updateTruck);
router.delete("/:id", deleteTruck);

module.exports = router;
