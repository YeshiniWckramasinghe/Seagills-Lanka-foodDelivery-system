const express = require("express");
const router = express.Router();

const {
  createBranch,
  getBranchById,
  getAllBranches,
  updateBranch,
  deleteBranch,
} = require("../Controller/BranchController");

// CREATE a new branch
router.post("/", createBranch);

// READ all branches
router.get("/", getAllBranches);

// READ a single branch by ID
router.get("/:id", getBranchById);

// UPDATE a branch by ID
router.put("/:id", updateBranch);

// DELETE a branch by ID
router.delete("/:id", deleteBranch);

module.exports = router;
