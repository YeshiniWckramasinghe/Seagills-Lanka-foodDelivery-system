// DailyLoadingRoute.js

const express = require("express");
const router = express.Router();
const DailyLoadingController = require("../Controller/DailyLoadingController");

// Specific routes FIRST
router.get("/truck/:truckId", DailyLoadingController.getLoadingsByTruckId);
router.get(
  "/coordinator/:coordinatorId",
  DailyLoadingController.getLoadingsByCoordinatorId
);
router.get("/date/:date", DailyLoadingController.getLoadingsByDate);
router.get("/today", DailyLoadingController.getTodayLoadings);

// CRUD routes
router.post("/", DailyLoadingController.createDailyLoading);
router.get("/", DailyLoadingController.getAllDailyLoadings);
router.get("/:id", DailyLoadingController.getDailyLoadingById);
router.put("/:id", DailyLoadingController.updateDailyLoading);
router.delete("/:id", DailyLoadingController.deleteDailyLoading);

module.exports = router;
