// Backend/Route/CoordinatorSummaryRoute.js
const express = require("express");
const router = express.Router();
const {
  getCoordinatorDailySummary,
} = require("../Controller/CoordinatorSummaryController");

// GET /api/coordinator-summary/:coordinatorId
// Optional query param: ?date=2025-10-17
router.get("/:coordinatorId", getCoordinatorDailySummary);

module.exports = router;
