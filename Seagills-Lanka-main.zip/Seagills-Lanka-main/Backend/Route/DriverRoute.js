const express = require("express");
const router = express.Router();
const driverController = require("../Controller/DriverController");

// Create driver
// POST /api/drivers
router.post("/", driverController.createDriver);

// Get all drivers
// GET /api/drivers
router.get("/", driverController.getAllDrivers);

// Get driver by ID
// GET /api/drivers/64f5b2c9e4b0123456789abc
router.get("/:id", driverController.getDriverById);

// Update driver
// PUT /api/drivers/64f5b2c9e4b0123456789abc
router.put("/:id", driverController.updateDriver);

// Delete driver
// DELETE /api/drivers/64f5b2c9e4b0123456789abc
router.delete("/:id", driverController.deleteDriver);

module.exports = router;
