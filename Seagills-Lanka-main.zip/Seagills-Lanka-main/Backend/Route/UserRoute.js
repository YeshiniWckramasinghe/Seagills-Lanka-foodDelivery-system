// Backend/Route/UserRoute.js
const express = require("express");
const {
  registerUser,
  loginUser,
  getAllDeliveryCoordinators,
  getDeliveryCoordinatorById,
  getUserById,
  getUsersByRole,
  getAllTruckDrivers,
  getTruckDriverById
} = require("../Controller/UserController");

const router = express.Router();

// Auth routes
router.post("/register", registerUser);
router.post("/login", loginUser);

// DeliveryCoordinator routes
router.get("/delivery-coordinators", getAllDeliveryCoordinators);
router.get("/delivery-coordinators/:id", getDeliveryCoordinatorById);

// TruckDriver routes
router.get("/truck-drivers", getAllTruckDrivers);
router.get("/truck-drivers/:id", getTruckDriverById);

// Generic user routes
router.get("/role/:role", getUsersByRole);
router.get("/:id", getUserById);

module.exports = router;
