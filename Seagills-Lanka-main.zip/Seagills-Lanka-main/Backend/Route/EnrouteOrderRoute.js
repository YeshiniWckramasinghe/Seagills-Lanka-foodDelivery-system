const express = require("express");
const router = express.Router();
const enrouteOrderController = require("../Controller/EnrouteOrderController");

// Route to create a new en-route order
// POST /api/enroute-orders
router.post("/", enrouteOrderController.createEnrouteOrder);

// Route to get all en-route orders (with optional filters)
// GET /api/enroute-orders
// Example: /api/enroute-orders?date=2025-09-24&coordinatorId=...
router.get("/", enrouteOrderController.getAllEnrouteOrders);

// Route to get en-route orders by coordinator ID
// GET /api/enroute-orders/coordinator/:coordinatorId
router.get(
  "/coordinator/:coordinatorId",
  enrouteOrderController.getEnrouteOrdersByCoordinator
);

// Route to get en-route orders by truck ID
// GET /api/enroute-orders/truck/:truckId
router.get("/truck/:truckId", enrouteOrderController.getEnrouteOrdersByTruck);

// Route to get a single en-route order by its ID
// GET /api/enroute-orders/:id
router.get("/:id", enrouteOrderController.getEnrouteOrderById);

// Route to update an en-route order (customer info, not products)
// PATCH /api/enroute-orders/:id
router.patch("/:id", enrouteOrderController.updateEnrouteOrder);

// User Story 1: Customer sends on-route stop request 
// POST /api/enroute-orders
router.post('/', enrouteOrderController.createEnrouteStopRequest);

// User Story 2: Customer adds short note with request
// PUT /api/enroute-orders/:orderId/note
router.put('/:orderId/note', enrouteOrderController.updateDeliveryNote);

// ============= SPRINT 2 =============

// User Story 3: Coordinator accepts stop requests
// PUT /api/enroute-orders/:orderId/accept
router.put('/:orderId/accept', enrouteOrderController.acceptStopRequest);

// User Story 3: Coordinator rejects stop requests  
// PUT /api/enroute-orders/:orderId/reject
router.put('/:orderId/reject', enrouteOrderController.rejectStopRequest);

// User Story 4: Coordinator is instantly notified of stop requests
// GET /api/enroute-orders/coordinator/:coordinatorId/notifications
router.get('/coordinator/:coordinatorId/notifications', enrouteOrderController.getPendingRequestsForCoordinator);

// User Story 5: Customer knows if request is accepted or rejected
// GET /api/enroute-orders/:orderId/status
router.get('/:orderId/status', enrouteOrderController.getRequestStatus);

// ============= SPRINT 3 =============

// User Story 6: Coordinator uses existing POS system for better payment service
// User Story 7: Customer receives bill after delivery
// POST /api/enroute-orders/:orderId/generate-bill
router.post('/:orderId/generate-bill', enrouteOrderController.generateBillAfterDelivery);

// User Story 8: Admin generates summary report of enroute orders
// GET /api/enroute-orders/reports/summary
router.get('/reports/summary', enrouteOrderController.generateEnrouteSummaryReport);

module.exports = router;
