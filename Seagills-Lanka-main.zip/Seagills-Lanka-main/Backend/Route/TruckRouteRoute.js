// Backend/Route/TruckRouteRoute.js
const express = require("express");
const router = express.Router();
const {
  createTruckRoute,
  getTruckRouteById,
  getAllTruckRoutes,
  updateTruckRoute,
  deleteTruckRoute,
  getSchedulesByTruck,
  getSchedulesByDate,
  startDailyRun,
} = require("../Controller/TruckRouteController");

router.post("/", createTruckRoute);
router.get("/", getAllTruckRoutes);
router.get("/:id", getTruckRouteById);
router.put("/:id", updateTruckRoute);
router.delete("/:id", deleteTruckRoute);
router.get("/truck/:truckID", getSchedulesByTruck);
router.get("/date/:date", getSchedulesByDate);
router.post("/schedules/start-run", startDailyRun);

module.exports = router;
