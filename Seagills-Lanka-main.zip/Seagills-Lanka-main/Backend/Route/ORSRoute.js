// backend/Route/ORSRoute.js
const express = require("express");
const router = express.Router();
const fetch = require("node-fetch");

// Put your real ORS API key here (or put in process.env.ORS_API_KEY)
const ORS_API_KEY = process.env.ORS_API_KEY || "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjhjNTEyM2RhZDA0YjQ1YTRiMTBkNTIyYjZjOTI4MGM4IiwiaCI6Im11cm11cjY0In0=";

router.get("/", async (req, res) => {
  try {
    const { start, end } = req.query;
    if (!start || !end) return res.status(400).json({ error: "Missing coordinates (start,end)" });

    // Expect start and end as "lon,lat"
    const [startLon, startLat] = start.split(",").map(Number);
    const [endLon, endLat] = end.split(",").map(Number);
    if ([startLon, startLat, endLon, endLat].some((v) => Number.isNaN(v))) {
      return res.status(400).json({ error: "Invalid coordinates" });
    }

    const url = `https://api.openrouteservice.org/v2/directions/driving-car?start=${startLon},${startLat}&end=${endLon},${endLat}`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Accept": "application/json, application/geo+json",
        "Authorization": ORS_API_KEY
      },
    });

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      console.error("ORS error:", response.status, text);
      return res.status(502).json({ error: "OpenRouteService error", details: text });
    }

    const data = await response.json();
    // Validate
    if (!data || !data.features || data.features.length === 0) {
      return res.status(400).json({ error: "No route returned from ORS" });
    }

    // Return the ORS feature directly
    return res.json(data);
  } catch (err) {
    console.error("ORSRoute error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
