const express = require('express');
const router = express.Router();
const manageStockController = require('../Controller/ManageProductStockController');


// Route
router.post('/add', manageStockController.addStock);         // Add stock
router.get('/view', manageStockController.getAllStock);      // View all stock
router.put('/update/:id', manageStockController.updateStock); // Update stock by ID
router.delete('/delete/:id', manageStockController.deleteStock); // Delete stock by ID

module.exports = router;
