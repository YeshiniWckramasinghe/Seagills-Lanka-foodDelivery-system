// Backend/Route/IncidentRoute.js
const express = require("express");
const router = express.Router();
const incidentController = require("../Controller/IncidentController");

// Record new incident (breakdown/delay)
// POST /api/incidents
router.post("/", incidentController.recordIncident);

// Get incidents by truck and date
// GET /api/incidents/truck/66f5b2c9e4b0123456789abc?date=2024-09-19
router.get("/truck/:truckId", incidentController.getIncidentsByTruckAndDate);

// Get incidents by coordinator
// GET /api/incidents/coordinator/66f5b2c9e4b0123456789abc?date=2024-09-19&status=reported
router.get(
  "/coordinator/:coordinatorId",
  incidentController.getIncidentsByCoordinator
);

// Get all incidents with filters
// GET /api/incidents?status=reported&severity=high&date=2024-09-19
router.get("/", incidentController.getAllIncidents);

// Get single incident by ID
// GET /api/incidents/66f5b2c9e4b0123456789abc
router.get("/:id", incidentController.getIncidentById);

// Update incident (resolution, status)
// PUT /api/incidents/66f5b2c9e4b0123456789abc
router.put("/:id", incidentController.updateIncident);

module.exports = router;
