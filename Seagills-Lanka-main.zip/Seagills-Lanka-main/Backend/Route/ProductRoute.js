// Backend/Route/ProductRoute.js
const express = require("express");
const router = express.Router();

const {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  getProductsByCategory,
  searchProducts,
  getProductStatistics,
  getProductCategories,
} = require("../Controller/ProductController");

// IMPORTANT: Specific routes MUST come BEFORE dynamic routes like /:id

// SEARCH - Search products by query
// GET /api/products/search?query=apple
router.get("/search", searchProducts);

// STATISTICS - Get product statistics
// GET /api/products/statistics
router.get("/statistics", getProductStatistics);

// CATEGORIES - Get all unique categories
// GET /api/products/categories
router.get("/categories", getProductCategories);

// Get products by category
// GET /api/products/category/fish
router.get("/category/:category", getProductsByCategory);

// Browse all products
// GET /api/products
router.get("/", getProducts);

// CREATE - Add new product
// POST /api/products
router.post("/", createProduct);

// Select one product by ID
// GET /api/products/66f5b2c9e4b0123456789abc
router.get("/:id", getProductById);

// UPDATE - Update product by ID
// PUT /api/products/66f5b2c9e4b0123456789abc
router.put("/:id", updateProduct);

// DELETE - Delete product by ID
// DELETE /api/products/66f5b2c9e4b0123456789abc
router.delete("/:id", deleteProduct);

module.exports = router;
