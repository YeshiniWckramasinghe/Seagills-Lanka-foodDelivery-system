// Backend/Route/PreorderRoute.js
const express = require("express");
const router = express.Router();
const preorderController = require("../Controller/PreorderController");


// Get pre-orders assigned to specific truck for loading manifest view
// GET /api/preorders/truck/66f5b2c9e4b0123456789abc?date=2024-09-19
router.get("/truck/:truckId", preorderController.getPreordersByTruck);

// Verify pre-order during loading (mark as verified/loaded)
// PUT /api/preorders/66f5b2c9e4b0123456789abc/verify
router.put("/:id/verify", preorderController.verifyPreorder);

// Update delivery status for pre-orders
// PUT /api/preorders/66f5b2c9e4b0123456789abc/status
router.put("/:id/status", preorderController.updateDeliveryStatus);

// ============ BASIC CRUD ROUTES ============

// Create new pre-order
// POST /api/preorders
router.post("/", preorderController.createPreorder);

// Get all pre-orders with optional filters
// GET /api/preorders?status=pending&date=2024-09-19&branchId=66f5b2c9e4b0123456789abc
router.get("/", preorderController.getAllPreorders);

// Get all pre-orders for a specific customer
router.get("/customer/:customerId", preorderController.getPreordersByCustomer);

// Get single pre-order by ID (MUST be placed after specific routes to avoid conflicts)
// GET /api/preorders/66f5b2c9e4b0123456789abc
router.get("/:id", preorderController.getPreorderById);

//Edit the preorder
router.put("/:id", preorderController.editPreorder);

//Delete the preorder
router.delete("/:id", preorderController.deletePreorder);


module.exports = router;
