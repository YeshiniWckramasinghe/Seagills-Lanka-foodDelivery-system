// Backend/Route/PaymentRoute.js
const express = require("express");
const router = express.Router();
const { updateOrderPayment } = require("../Controller/PaymentController");

// PATCH request to update the payment status of an order by its ID
// Route: /api/payments/:id
router.patch("/:id", updateOrderPayment);

module.exports = router;
