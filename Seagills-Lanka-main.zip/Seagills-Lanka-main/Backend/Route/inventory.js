// routes/inventory.js
const express = require('express');
const router = express.Router();
const {
   generateSKU,
  getAllInventory,
  getInventoryById,
  createInventory,
  updateInventory,
  deleteInventory,
  searchInventory,
  getLowStock
} = require('../Controller/inventoryController');

// GET /api/inventory/generate-sku - Generate SKU
router.get('/generate-sku', generateSKU);


// GET /api/inventory - Get all inventory items
router.get('/', getAllInventory);

// GET /api/inventory/low-stock - Get low stock items
router.get('/low-stock', getLowStock);

// GET /api/inventory/search - Search inventory
router.get('/search', searchInventory);

// GET /api/inventory/:id - Get single inventory item
router.get('/:id', getInventoryById);

// POST /api/inventory - Create new inventory item
router.post('/', createInventory);

// PUT /api/inventory/:id - Update inventory item
router.put('/:id', updateInventory);

// DELETE /api/inventory/:id - Delete inventory item
router.delete('/:id', deleteInventory);
//comment
module.exports = router;