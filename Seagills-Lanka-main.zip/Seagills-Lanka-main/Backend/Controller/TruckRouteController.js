// Backend/Controller/TruckRouteController.js
const TruckRoute = require("../Model/TruckRouteModel");
const Truck = require("../Model/TruckModel");
const Route = require("../Model/RouteModel");

// CREATE: Insert a new truck-route assignment
const createTruckRoute = async (req, res, next) => {
  try {
    const { truckID, routeID, date, startTime } = req.body;

    // Validate truck exists
    const truck = await Truck.findById(truckID);
    if (!truck) {
      return res.status(404).json({ message: "Truck not found" });
    }

    // Validate route exists
    const route = await Route.findById(routeID);
    if (!route) {
      return res.status(404).json({ message: "Route not found" });
    }

    // Check if truck already has schedule for this date
    const existingSchedule = await TruckRoute.findOne({
      truckID,
      date: new Date(date),
    });

    if (existingSchedule) {
      return res
        .status(400)
        .json({ message: "Truck already has a schedule for this date" });
    }

    const truckRoute = new TruckRoute({
      truckID,
      routeID,
      date: new Date(date),
      startTime,
    });

    await truckRoute.save();

    // Define time range for this day
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    try {
      // Find truck assignment record for this day
      const assignment = await AssignedTruck.findOne({
        truckID,
        date: { $gte: startOfDay, $lte: endOfDay },
      });

      // No assignment found: respond success without auto-assignment
      if (!assignment) {
        return res.status(201).json({
          message:
            "TruckRoute created successfully (no assignment found for auto-assignment)",
          truckRoute,
        });
      }

      const { branchID, category, deliveryCoordinatorID } = assignment;
      const normalizedCategory = category.replace(/\s+/g, "").toLowerCase();

      // Find matching preorders for this date and branch
      const preorders = await Preorder.find({
        branchID,
        deliveryDate: { $gte: startOfDay, $lte: endOfDay },
        orderStatus: { $in: ["pending", "assigned"] },
      });

      // Filter by matching category and not already assigned
      const matchingPreorders = preorders
        .filter((preorder) =>
          preorder.categories.some(
            (cat) =>
              cat.replace(/\s+/g, "").toLowerCase() === normalizedCategory
          )
        )
        .filter(
          (preorder) =>
            !preorder.assignedTrucks.some(
              (truck) =>
                truck.category.replace(/\s+/g, "").toLowerCase() ===
                normalizedCategory
            )
        );

      let assignedCount = 0;

      // Assign matching preorders to this truck
      for (const preorder of matchingPreorders) {
        const isMatch = await checkRouteMatch(preorder.address, route);

        if (isMatch) {
          await Preorder.findByIdAndUpdate(preorder._id, {
            $push: {
              assignedTrucks: {
                category,
                truckID,
                coordinatorID: deliveryCoordinatorID,
                assignedAt: new Date(),
              },
            },
            $set: {
              orderStatus: "assigned",
              lastUpdated: new Date(),
            },
          });
          assignedCount++;
        }
      }

      return res.status(201).json({
        message: "TruckRoute created successfully with auto-assignment",
        truckRoute,
        autoAssignment: {
          totalPreordersChecked: matchingPreorders.length,
          assignedToThisTruck: assignedCount,
          category,
          route: `${route.start.name} to ${route.end.name}`,
        },
      });
    } catch (assignmentErr) {
      // Handle only the assignment error (creation succeeded)
      console.error("❌ Auto-assignment failed:", assignmentErr);
      return res.status(201).json({
        message: "TruckRoute created successfully, but auto-assignment failed",
        truckRoute,
        error: assignmentErr.message,
      });
    }
  } catch (err) {
    // This only runs if the *creation itself* fails
    next(err);
  }
};

// READ: Get a single truck-route by ID
const getTruckRouteById = async (req, res, next) => {
  try {
    const truckRoute = await TruckRoute.findById(req.params.id)
      .populate("truckID")
      .populate({
        path: "routeID",
        populate: { path: "branchID" }, // populate branch info in route
      });

    if (!truckRoute)
      return res.status(404).json({ message: "TruckRoute not found" });
    return res.status(200).json(truckRoute);
  } catch (err) {
    next(err);
  }
};

// READ: Get all truck-routes
const getAllTruckRoutes = async (req, res, next) => {
  try {
    const truckRoutes = await TruckRoute.find()
      .populate("truckID")
      .populate({
        path: "routeID",
        populate: { path: "branchID" },
      })
      .sort({ date: -1 }); // Latest first
    return res.status(200).json(truckRoutes);
  } catch (err) {
    next(err);
  }
};

// UPDATE: Update truck-route by ID
const updateTruckRoute = async (req, res, next) => {
  try {
    const { truckID, routeID, date, startTime } = req.body;
    const updateData = {};
    if (truckID) updateData.truckID = truckID;
    if (routeID) updateData.routeID = routeID;
    if (date) {
      updateData.date = new Date(date);
    }
    if (startTime) updateData.startTime = startTime;

    const truckRoute = await TruckRoute.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!truckRoute)
      return res.status(404).json({ message: "TruckRoute not found" });
    return res
      .status(200)
      .json({ message: "TruckRoute updated successfully", truckRoute });
  } catch (err) {
    next(err);
  }
};

// DELETE: Delete truck-route by ID
const deleteTruckRoute = async (req, res, next) => {
  try {
    const truckRoute = await TruckRoute.findByIdAndDelete(req.params.id);
    if (!truckRoute)
      return res.status(404).json({ message: "TruckRoute not found" });
    return res
      .status(200)
      .json({ message: "TruckRoute deleted successfully", truckRoute });
  } catch (err) {
    next(err);
  }
};

// Get schedules by truck (for specific truck view)
const getSchedulesByTruck = async (req, res) => {
  try {
    const { truckId } = req.params;

    const schedules = await TruckRoute.find({ truckID: truckId })
      .populate("routeID", "start end branchID")
      .sort({ date: -1 });

    res.status(200).json({
      success: true,
      message: "Truck schedules retrieved successfully",
      truckId,
      count: schedules.length,
      schedules,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving truck schedules",
      error: error.message,
    });
  }
};

// Get schedules by date (for daily operations)
const getSchedulesByDate = async (req, res) => {
  try {
    const { date } = req.params;

    // Set date range for the entire day
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const schedules = await TruckRoute.find({
      date: { $gte: startOfDay, $lte: endOfDay },
    })
      .populate("truckID", "plateNo colour")
      .populate("routeID", "start end branchID");

    res.status(200).json({
      success: true,
      message: "Daily schedules retrieved successfully",
      date: date,
      count: schedules.length,
      schedules,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving daily schedules",
      error: error.message,
    });
  }
};

// Start daily run - Update schedule when coordinator clicks "Start Daily Run"
const startDailyRun = async (req, res) => {
  try {
    const { truckID, date } = req.body;

    if (!truckID || !date) {
      return res.status(400).json({
        success: false,
        message: "Truck ID and date are required",
      });
    }

    const checkDate = new Date(date);
    const startOfDay = new Date(checkDate);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(checkDate);
    endOfDay.setHours(23, 59, 59, 999);

    // Find the schedule for this truck and date
    const schedule = await TruckRoute.findOne({
      truckID,
      date: { $gte: startOfDay, $lte: endOfDay },
    });

    if (!schedule) {
      return res.status(404).json({
        success: false,
        message: "No schedule found for this truck and date",
      });
    }

    // Check if already started
    if (schedule.tripStartedAt) {
      return res.status(400).json({
        success: false,
        message: "Daily run has already been started",
        tripStartedAt: schedule.tripStartedAt,
      });
    }

    // Update with current timestamp
    schedule.tripStartedAt = new Date();
    schedule.tripStatus = "in_progress";
    await schedule.save();

    res.status(200).json({
      success: true,
      message: "Daily run started successfully",
      tripStartedAt: schedule.tripStartedAt,
      schedule,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error starting daily run",
      error: error.message,
    });
  }
};

const getScheduleByTruckAndDate = async ({ truckID, date }) => {
  // Set date range for the entire day (same logic as getSchedulesByDate)
  const checkDate = new Date(date);
  const startOfDay = new Date(checkDate);
  startOfDay.setHours(0, 0, 0, 0);

  const endOfDay = new Date(checkDate);
  endOfDay.setHours(23, 59, 59, 999);

  const schedule = await TruckRoute.findOne({
    truckID: truckID,
    date: { $gte: startOfDay, $lte: endOfDay },
  })
    .populate("truckID", "plateNo colour")
    .populate({
      path: "routeID",
      populate: [
        { path: "start", select: "name" },
        { path: "end", select: "name" },
      ],
    });

  return schedule;
};

module.exports = {
  createTruckRoute,
  getTruckRouteById,
  getAllTruckRoutes,
  updateTruckRoute,
  deleteTruckRoute,
  getSchedulesByTruck,
  getSchedulesByDate,
  getScheduleByTruckAndDate,
  startDailyRun,
};
