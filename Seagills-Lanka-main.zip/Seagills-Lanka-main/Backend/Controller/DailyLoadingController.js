// Backend/Controller/DailyLoadingController.js
const DailyLoading = require("../Model/DailyLoadingModel");
const Truck = require("../Model/TruckModel");
const { DeliveryCoordinator } = require("../Model/UserModel");
const Product = require("../Model/ProductModel");
const { PreorderProduct } = require("../Model/PreorderModel");
const mongoose = require("mongoose");

// Allowed status values
const STATUS_ENUM = ["loading", "completed", "departed"];

// The main function to create the daily loading manifest
const createDailyLoading = async (req, res) => {
  try {
    const { truckID, coordinatorID, date, truckCategory, defaultStockItems } =
      req.body;

    // 1. Validation
    if (!truckID || !coordinatorID || !date || !truckCategory) {
      return res.status(400).json({
        message:
          "truckID, coordinatorID, date, and truckCategory are required.",
      });
    }

    const loadingDate = new Date(date);
    loadingDate.setUTCHours(0, 0, 0, 0);

    const existingLoading = await DailyLoading.findOne({
      truckID,
      date: {
        $gte: loadingDate,
        $lt: new Date(loadingDate.getTime() + 24 * 60 * 60 * 1000),
      },
    });
    if (existingLoading) {
      return res.status(400).json({
        message: "This truck already has a loading assigned for this date.",
      });
    }

    // 2. Automatically find and populate pre-order products for this truck's category
    let totalWeight = 0;
    const loadedPreorderProducts = [];

    const preordersForTruck = await PreorderProduct.aggregate([
      {
        $lookup: {
          from: "preorders",
          localField: "preorderID",
          foreignField: "_id",
          as: "preorderInfo",
        },
      },
      { $unwind: "$preorderInfo" },
      {
        $match: {
          "preorderInfo.orderDate": {
            $gte: loadingDate,
            $lt: new Date(loadingDate.getTime() + 24 * 60 * 60 * 1000),
          },
        },
      },
      {
        $lookup: {
          from: "products",
          localField: "productID",
          foreignField: "_id",
          as: "productInfo",
        },
      },
      { $unwind: "$productInfo" },
      { $match: { "productInfo.category": truckCategory } },
      {
        $project: {
          _id: 1, // PreorderProduct ID
          quantity: "$quantity",
          weightInKg: "$productInfo.weightInKg",
        },
      },
    ]);

    for (const item of preordersForTruck) {
      if (item.weightInKg) {
        totalWeight += item.quantity * item.weightInKg;
      }
      loadedPreorderProducts.push({ preorderProductID: item._id });
    }

    // 3. Process and add default stock items to the manifest
    const validUnits = ["kg", "g", "nos", "pcs", "bunch"];

    const loadedStockItems = [];
    if (defaultStockItems && defaultStockItems.length > 0) {
      for (const item of defaultStockItems) {
        // Validate unit
        if (item.unit && !validUnits.includes(item.unit)) {
          return res.status(400).json({
            message: `Invalid unit '${
              item.unit
            }'. Valid units are: ${validUnits.join(", ")}`,
          });
        }
        const product = await Product.findById(item.productID);
        if (product) {
          if (product.weightInKg) {
            totalWeight += item.quantity * product.weightInKg;
          }
          loadedStockItems.push({
            productID: item.productID,
            quantity: item.quantity,
            unit: item.unit || "pcs", // Default to "pcs" if not provided
          });
        }
      }
    }

    // 4. Create the new DailyLoading record
    const newLoading = new DailyLoading({
      truckID,
      coordinatorID,
      category: truckCategory,
      date: loadingDate,
      loadedPreorderProducts,
      loadedStockItems,
      totalWeight,
      status: "loading",
    });

    await newLoading.save();

    res.status(201).json({
      success: true,
      message: `Daily loading manifest created for truck ${truckID} on ${date}`,
      manifest: newLoading,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET all Daily Loadings
const getAllDailyLoadings = async (req, res) => {
  try {
    const loadings = await DailyLoading.find()
      .populate("truckID")
      .populate("coordinatorID")
      .populate({
        path: "loadedPreorderProducts.preorderProductID",
        populate: { path: "productID" },
      })
      .populate("loadedStockItems.productID");
    res.json(loadings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET Daily Loading by ID
const getDailyLoadingById = async (req, res) => {
  try {
    const loading = await DailyLoading.findById(req.params.id)
      .populate("truckID")
      .populate("coordinatorID")
      .populate({
        path: "loadedPreorderProducts.preorderProductID",
        populate: { path: "productID" },
      })
      .populate("loadedStockItems.productID");
    if (!loading)
      return res.status(404).json({ message: "Daily loading not found" });
    res.json(loading);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// UPDATE Daily Loading
const updateDailyLoading = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      loadedPreorderProducts,
      loadedStockItems,
      status,
      loadingStartTime,
      loadingEndTime,
    } = req.body;

    const updateData = {};
    let totalWeight = 0;

    // If a new list of loadedPreorderProducts is provided, recalculate its weight
    if (loadedPreorderProducts) {
      const preorderItems = await Promise.all(
        loadedPreorderProducts.map((item) =>
          PreorderProduct.findById(item.preorderProductID).populate("productID")
        )
      );
      preorderItems.forEach((item) => {
        if (item && item.productID && item.productID.weightInKg) {
          totalWeight += item.quantity * item.productID.weightInKg;
        }
      });
      updateData.loadedPreorderProducts = loadedPreorderProducts;
    }

    // If a new list of loadedStockItems is provided, recalculate its weight
    if (loadedStockItems) {
      const stockItems = await Promise.all(
        loadedStockItems.map((item) => Product.findById(item.productID))
      );
      stockItems.forEach((product, index) => {
        if (product && product.weightInKg) {
          totalWeight += loadedStockItems[index].quantity * product.weightInKg;
        }
      });
      updateData.loadedStockItems = loadedStockItems;
    }

    if (loadedPreorderProducts || loadedStockItems) {
      updateData.totalWeight = totalWeight;
    }

    if (status) {
      const validStatuses = ["loading", "completed", "departed"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      updateData.status = status;
    }
    if (loadingStartTime) updateData.loadingStartTime = loadingStartTime;
    if (loadingEndTime) updateData.loadingEndTime = loadingEndTime;

    const updatedRecord = await DailyLoading.findByIdAndUpdate(id, updateData, {
      new: true,
      runValidators: true,
    })
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .populate({
        path: "loadedPreorderProducts.preorderProductID",
        populate: { path: "productID", select: "productName category price" },
      })
      .populate("loadedStockItems.productID", "productName category price");

    if (!updatedRecord) {
      return res.status(404).json({ message: "Daily loading not found" });
    }

    res.status(200).json({
      success: true,
      message: "Daily loading updated successfully",
      loadingRecord: updatedRecord,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// DELETE Daily Loading
const deleteDailyLoading = async (req, res) => {
  try {
    const loading = await DailyLoading.findByIdAndDelete(req.params.id);
    if (!loading)
      return res.status(404).json({ message: "Daily loading not found" });
    res.json({ message: "Daily loading deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET Loadings by Truck ID (all dates)
const getLoadingsByTruckId = async (req, res) => {
  try {
    const { truckId } = req.params;
    const truck = await Truck.findById(truckId);
    if (!truck) return res.status(404).json({ message: "Truck not found" });

    const loadings = await DailyLoading.find({ truckID: truckId })
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .populate({
        path: "loadedPreorderProducts.preorderProductID",
        populate: {
          path: "productID",
          select: "productName category price unit",
        },
      })
      .populate("loadedStockItems.productID", "productName category price unit")
      .select(
        "date status loadedPreorderProducts loadedStockItems totalWeight loadingStartTime loadingEndTime"
      );

    if (!loadings.length) {
      return res
        .status(404)
        .json({ message: "No loadings found for this truck" });
    }

    res.json({ success: true, count: loadings.length, loadings });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET Today's Daily Loadings
const getTodayLoadings = async (req, res) => {
  try {
    const today = new Date();
    const start = new Date(today);
    start.setHours(0, 0, 0, 0);
    const end = new Date(today);
    end.setHours(23, 59, 59, 999);

    const loadings = await DailyLoading.find({
      date: { $gte: start, $lte: end },
    })
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .populate({
        path: "loadedPreorderProducts.preorderProductID",
        populate: {
          path: "productID",
          select: "productName category price unit",
        },
      })
      .populate("loadedStockItems.productID", "productName category price unit")
      .select(
        "date status loadedPreorderProducts loadedStockItems totalWeight loadingStartTime loadingEndTime"
      );

    if (!loadings.length) {
      return res.status(200).json({
        success: true,
        date: today.toISOString().split("T")[0],
        count: 0,
        loadings: [], // Return empty array
      });
    }

    res.json({
      success: true,
      date: today.toISOString().split("T")[0],
      count: loadings.length,
      loadings,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET Loadings by Coordinator ID (all dates)
const getLoadingsByCoordinatorId = async (req, res) => {
  try {
    const { coordinatorId } = req.params;
    const coordinator = await DeliveryCoordinator.findById(coordinatorId);
    if (!coordinator)
      return res.status(404).json({ message: "Coordinator not found" });

    const loadings = await DailyLoading.find({ coordinatorID: coordinatorId })
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .populate({
        path: "loadedPreorderProducts.preorderProductID",
        populate: {
          path: "productID",
          select: "productName category price unit",
        },
      })
      .populate("loadedStockItems.productID", "productName category price unit")
      .select(
        "date status loadedPreorderProducts loadedStockItems totalWeight loadingStartTime loadingEndTime"
      );

    if (!loadings.length)
      return res
        .status(404)
        .json({ message: "No loadings found for this coordinator" });

    res.json({ success: true, count: loadings.length, loadings });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET Loadings by Date
const getLoadingsByDate = async (req, res) => {
  try {
    const { date } = req.params;
    if (!date) return res.status(400).json({ message: "Date is required" });

    const start = new Date(date);
    start.setHours(0, 0, 0, 0);
    const end = new Date(date);
    end.setHours(23, 59, 59, 999);

    const loadings = await DailyLoading.find({
      date: { $gte: start, $lte: end },
    })
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .populate({
        path: "loadedPreorderProducts.preorderProductID",
        populate: {
          path: "productID",
          select: "productName category price unit",
        },
      })
      .populate("loadedStockItems.productID", "productName category price unit")
      .select(
        "date status loadedPreorderProducts loadedStockItems totalWeight loadingStartTime loadingEndTime"
      );

    if (!loadings.length)
      return res
        .status(404)
        .json({ message: "No loadings found for this date" });

    res.json({ success: true, date, count: loadings.length, loadings });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createDailyLoading,
  getAllDailyLoadings,
  getDailyLoadingById,
  updateDailyLoading,
  deleteDailyLoading,
  getLoadingsByTruckId,
  getTodayLoadings,
  getLoadingsByCoordinatorId,
  getLoadingsByDate,
};
