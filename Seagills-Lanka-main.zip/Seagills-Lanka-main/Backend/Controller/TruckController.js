const Truck = require("../Model/TruckModel");
const Branch = require("../Model/BranchModel");

// CREATE a new truck
const createTruck = async (req, res, next) => {
  try {
    const { truckNumber, branchID, colour, plateNo } = req.body;

    if (!truckNumber) {
      return res.status(400).json({ message: "Truck number is required" });
    }

    // Check duplicate
    const existingTruck = await Truck.findOne({ truckNumber });
    if (existingTruck) {
      return res.status(400).json({ message: "Truck with this number already exists" });
    }

    // Default location
    // Default location = branch location
let currentLocation = { type: "Point", coordinates: [0, 0] };
if (branchID) {
  const branch = await Branch.findById(branchID);
  if (branch?.location?.coordinates) currentLocation = branch.location;
}


    const truck = new Truck({ truckNumber, branchID, colour, plateNo, currentLocation });
    await truck.save();

    res.status(201).json({ message: "Truck created successfully", truck });
  } catch (err) {
    next(err);
  }
};

// GET all trucks
const getAllTrucks = async (req, res, next) => {
  try {
    const trucks = await Truck.find().populate("branchID", "branchName location");
    res.status(200).json(trucks);
  } catch (err) {
    next(err);
  }
};

// GET truck by ID
const getTruckById = async (req, res, next) => {
  try {
    const truck = await Truck.findById(req.params.id).populate("branchID", "branchName location");
    if (!truck) return res.status(404).json({ message: "Truck not found" });
    res.status(200).json(truck);
  } catch (err) {
    next(err);
  }
};

// UPDATE truck
const updateTruck = async (req, res, next) => {
  try {
    const { truckNumber, branchID, colour, plateNo } = req.body;
    const updateData = {};

    if (truckNumber) updateData.truckNumber = truckNumber;
    if (colour) updateData.colour = colour;
    if (plateNo) updateData.plateNo = plateNo;

    if (branchID) {
      const branch = await Branch.findById(branchID);
      if (branch?.location?.coordinates) updateData.currentLocation = branch.location;
      updateData.branchID = branchID;
    }

    const truck = await Truck.findByIdAndUpdate(req.params.id, updateData, { new: true, runValidators: true });
    if (!truck) return res.status(404).json({ message: "Truck not found" });

    res.status(200).json({ message: "Truck updated successfully", truck });
  } catch (err) {
    next(err);
  }
};

// DELETE truck
const deleteTruck = async (req, res, next) => {
  try {
    const truck = await Truck.findByIdAndDelete(req.params.id);
    if (!truck) return res.status(404).json({ message: "Truck not found" });
    res.status(200).json({ message: "Truck deleted successfully", truck });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  createTruck,
  getAllTrucks,
  getTruckById,
  updateTruck,
  deleteTruck,
};
