// Backend/Controller/RouteController.js
const Route = require("../Model/RouteModel");

// CREATE: Insert a new route
const createRoute = async (req, res, next) => {
  try {
    const { start, end, branchID } = req.body;
    const route = new Route({ start, end, branchID });
    await route.save();
    return res
      .status(201)
      .json({ message: "Route created successfully", route });
  } catch (err) {
    next(err);
  }
};

// READ: Get a single route by ID
const getRouteById = async (req, res, next) => {
  try {
    const route = await Route.findById(req.params.id).populate('branchID');
    if (!route) return res.status(404).json({ message: "Route not found" });
    return res.status(200).json(route);
  } catch (err) {
    next(err);
  }
};

// READ: Get all routes or routes filtered by branchID
// READ: Get all routes or routes filtered by branchID
const getAllRoutes = async (req, res, next) => {
  try {
    const { branchID } = req.query; // optional query
    const filter = {};
    if (branchID) filter.branchID = branchID;

    const routes = await Route.find(filter).populate('branchID');
    return res.status(200).json(routes);
  } catch (err) {
    next(err);
  }
};

// UPDATE: Update route by ID
const updateRoute = async (req, res, next) => {
  try {
    const { start, end, branchID } = req.body;
    const updateData = {};
    if (start) updateData.start = start;
    if (end) updateData.end = end;
    if (branchID) updateData.branchID = branchID;

    const route = await Route.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
      runValidators: true,
    });

    if (!route) return res.status(404).json({ message: "Route not found" });
    return res
      .status(200)
      .json({ message: "Route updated successfully", route });
  } catch (err) {
    next(err);
  }
};

// DELETE: Delete route by ID
const deleteRoute = async (req, res, next) => {
  try {
    const route = await Route.findByIdAndDelete(req.params.id);
    if (!route) return res.status(404).json({ message: "Route not found" });
    return res
      .status(200)
      .json({ message: "Route deleted successfully", route });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  createRoute,
  getRouteById,
  getAllRoutes,
  updateRoute,
  deleteRoute,
};
