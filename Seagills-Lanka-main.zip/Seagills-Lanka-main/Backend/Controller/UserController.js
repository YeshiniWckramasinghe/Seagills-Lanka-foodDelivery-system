// Backend/Controller/UserController.js
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const mongoose = require("mongoose");
const { User, DeliveryCoordinator, TruckDriver } = require("../Model/UserModel");
const Branch = require("../Model/BranchModel");

// ------------------------
// Register new user
// ------------------------
const registerUser = async (req, res, next) => {
  try {
    const {
      username,
      password,
      firstName,
      lastName,
      email,
      telephone,
      role,
      branchID,
      licenseNumber,
      assignedTruck
    } = req.body;

    if (!username || !password || !role) {
      return res.status(400).json({ success: false, message: "Username, password, and role are required." });
    }

    const validRoles = ["Admin","RegisteredCustomer","StockManager","DeliveryCoordinator","TruckDriver"];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ success: false, message: "Invalid role selected." });
    }

    const existingUser = await User.findOne({ username });
    if (existingUser) return res.status(400).json({ success: false, message: "Username already exists." });

    const hashedPassword = await bcrypt.hash(password, 12);
    const userData = { username, password: hashedPassword, firstName, lastName, email, telephone, role };

    let newUser;
    if (role === "DeliveryCoordinator") {
      if (!branchID) return res.status(400).json({ success: false, message: "Branch ID is required" });
      if (!mongoose.Types.ObjectId.isValid(branchID)) return res.status(400).json({ message: "Invalid Branch ID format." });
      const branchExists = await Branch.findById(branchID);
      if (!branchExists) return res.status(400).json({ message: "No branch found with this ID." });

      newUser = new DeliveryCoordinator({ ...userData, branchID });
    } else if (role === "TruckDriver") {
      if (!licenseNumber) return res.status(400).json({ message: "License number required for TruckDriver" });
      newUser = new TruckDriver({ ...userData, licenseNumber, assignedTruck: assignedTruck || null });
    } else {
      newUser = new User(userData);
    }

    const savedUser = await newUser.save();

    const userResponse = {
      id: savedUser._id,
      username: savedUser.username,
      firstName: savedUser.firstName,
      lastName: savedUser.lastName,
      email: savedUser.email,
      telephone: savedUser.telephone,
      role: savedUser.role,
      createdAt: savedUser.createdAt,
      updatedAt: savedUser.updatedAt,
    };

    if (role === "DeliveryCoordinator") {
      const branchInfo = await Branch.findById(savedUser.branchID).select("branchName branchAddress");
      userResponse.branchID = savedUser.branchID;
      userResponse.branchInfo = branchInfo;
    }

    res.status(201).json({ success: true, message: "User registered successfully", user: userResponse });
  } catch (err) {
    next(err);
  }
};

// ------------------------
// Login user
// ------------------------
const loginUser = async (req, res, next) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ success: false, message: "Invalid username or password." });

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ success: false, message: "Invalid username or password." });

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET || "secretKey", { expiresIn: "1h" });

    const userResponse = { id: user._id, username: user.username, role: user.role };

if (user.role === "TruckDriver") {
  // Populate the assignedTruck
  const driver = await TruckDriver.findById(user._id).populate("assignedTruck");
  userResponse.assignedTruck = driver.assignedTruck; // This includes currentLocation, plateNo, etc.
}


    res.json({ success: true, message: "Login successful", token, user: userResponse });
  } catch (err) {
    next(err);
  }
};

// ------------------------
// Get all users by role
// ------------------------
const getUsersByRole = async (req, res) => {
  try {
    const { role } = req.params;
    const users = await User.find({ role }).select("firstName lastName username email telephone role");
    res.status(200).json({ message: `${role}s retrieved successfully`, count: users.length, users });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ------------------------
// Get user by ID
// ------------------------
const getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findById(id)
      .populate("assignedTruck", "truckNumber colour currentLocation")
      .populate("branchID", "branchName branchAddress location");
    if (!user) return res.status(404).json({ message: "User not found" });
    res.status(200).json({ user });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ------------------------
// DeliveryCoordinator endpoints
// ------------------------
const getAllDeliveryCoordinators = async (req, res) => {
  try {
    const coordinators = await DeliveryCoordinator.find().populate("branchID", "branchName branchAddress location");
    res.status(200).json({ count: coordinators.length, coordinators });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getDeliveryCoordinatorById = async (req, res) => {
  try {
    const { id } = req.params;
    const coordinator = await DeliveryCoordinator.findById(id).populate("branchID", "branchName branchAddress location");
    if (!coordinator) return res.status(404).json({ message: "Coordinator not found" });
    res.status(200).json({ coordinator });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ------------------------
// TruckDriver endpoints
// ------------------------
const getAllTruckDrivers = async (req, res) => {
  try {
    const drivers = await TruckDriver.find().populate("assignedTruck", "truckNumber colour currentLocation");
    res.status(200).json({ count: drivers.length, drivers });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getTruckDriverById = async (req, res) => {
  try {
    const { id } = req.params;
    const driver = await TruckDriver.findById(id).populate("assignedTruck", "truckNumber colour currentLocation");
    if (!driver) return res.status(404).json({ message: "Driver not found" });
    res.status(200).json({ driver });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
  registerUser,
  loginUser,
  getUsersByRole,
  getUserById,
  getAllDeliveryCoordinators,
  getDeliveryCoordinatorById,
  getAllTruckDrivers,
  getTruckDriverById
};
