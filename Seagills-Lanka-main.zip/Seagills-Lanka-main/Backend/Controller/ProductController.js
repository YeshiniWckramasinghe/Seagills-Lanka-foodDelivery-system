// Backend/Controller/ProductController.js
const Product = require("../Model/ProductModel");
const Truck = require("../Model/TruckModel");
const { DeliveryCoordinator } = require("../Model/UserModel");
const mongoose = require("mongoose"); // import mongoose for ObjectId validation

// Helper function to add a formatted displayPrice to a product object
const formatProductForDisplay = (product) => {
  const productObject = product.toObject();
  return {
    ...productObject,
    displayPrice: `Rs. ${productObject.price} per ${productObject.unit}`,
  };
};

// Define the valid units centrally for consistency
const VALID_UNITS = ["kg", "g", "nos", "pcs", "bunch"];

// CRUD methods for Product management
// CREATE - Add new product
const createProduct = async (req, res) => {
  try {
    const {
      productName,
      productDescription,
      category,
      price,
      weightInKg,
      unit,
    } = req.body;

    // Validation: Check required fields
    if (!productName || !price || !unit || !category) {
      return res.status(400).json({
        success: false,
        message: "Product name and price, unit, and category are required",
      });
    }

    // Validation: Check if price is a positive number
    if (isNaN(price) || price <= 0) {
      return res.status(400).json({
        success: false,
        message: "Price must be a positive number",
      });
    }

    // Validation: Check if unit is valid
    if (!VALID_UNITS.includes(unit.trim().toLowerCase())) {
      return res.status(400).json({
        success: false,
        message: `Invalid unit. Allowed units are: ${VALID_UNITS.join(", ")}`,
      });
    }

    // Validation: Check weightInKg if provided
    if (weightInKg !== undefined && (isNaN(weightInKg) || weightInKg < 0)) {
      return res.status(400).json({
        success: false,
        message: "Weight must be a non-negative number",
      });
    }

    // Validation: Check if product name already exists (case-insensitive)
    // Escape special regex characters in the product name
    const escapedProductName = productName
      .trim()
      .replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

    const existingProduct = await Product.findOne({
      productName: { $regex: new RegExp("^" + escapedProductName + "$", "i") },
    });

    if (existingProduct) {
      return res.status(400).json({
        success: false,
        message: "Product with this name already exists",
      });
    }

    // Create new product (only if no duplicate found)
    const newProduct = new Product({
      productName: productName.trim(),
      productDescription: productDescription ? productDescription.trim() : "",
      category: category ? category.trim() : "",
      price: parseFloat(price),
      weightInKg: weightInKg ? parseFloat(weightInKg) : 0,
      unit: unit.trim(),
    });

    const savedProduct = await newProduct.save();

    res.status(201).json({
      success: true,
      message: "Product created successfully",
      product: savedProduct,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error creating product",
      error: error.message,
    });
  }
};

// Get all products
// @route GET /api/products
const getProducts = async (req, res) => {
  try {
    const products = await Product.find(); // fetch all products
    const formattedProducts = products.map(formatProductForDisplay);
    res.json(formattedProducts);
  } catch (err) {
    res.status(500).json({ message: "Server Error", error: err.message });
  }
};

//Get single product by ID
// @route GET /api/products/:id
const getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    const formattedProduct = formatProductForDisplay(product);
    res.json(formattedProduct);
  } catch (err) {
    res.status(500).json({ message: "Server Error", error: err.message });
  }
};

// UPDATE - Update product by ID
const updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      productName,
      productDescription,
      category,
      price,
      weightInKg,
      unit,
      productImage,
    } = req.body;

    const updateData = {};

    // Validation: Check if ID is valid MongoDB ObjectId
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid product ID format",
      });
    }

    // Validation: Check if price is valid (if provided)
    if (price !== undefined && (isNaN(price) || price <= 0)) {
      return res.status(400).json({
        success: false,
        message: "Price must be a positive number",
      });
    }

    // Validation: Check if unit is valid (if provided)
    if (unit && !VALID_UNITS.includes(unit.trim().toLowerCase())) {
      return res.status(400).json({
        success: false,
        message: `Invalid unit. Allowed units are: ${VALID_UNITS.join(", ")}`,
      });
    }

    // Validation: Check if product name already exists (excluding current product)
    if (productName) {
      const escapedProductName = productName
        .trim()
        .replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

      const existingProduct = await Product.findOne({
        productName: {
          $regex: new RegExp("^" + escapedProductName + "$", "i"),
        },
        _id: { $ne: id }, // Exclude current product from check
      });

      if (existingProduct) {
        return res.status(400).json({
          success: false,
          message: "Another product with this name already exists",
        });
      }
    }

    // Prepare update data (only include fields that were provided)
    if (productName) updateData.productName = productName.trim();
    if (productDescription !== undefined)
      updateData.productDescription = productDescription.trim();
    if (category !== undefined) updateData.category = category.trim();
    if (price !== undefined) updateData.price = parseFloat(price);
    if (weightInKg !== undefined)
      updateData.weightInKg = parseFloat(weightInKg);
    if (unit) updateData.unit = unit.trim().toLowerCase();
    if (productImage !== undefined) updateData.productImage = productImage;

    // Update the product
    const updatedProduct = await Product.findByIdAndUpdate(id, updateData, {
      new: true, // Return the updated document
      runValidators: true, // Run mongoose validations
    });

    if (!updatedProduct) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Product updated successfully",
      product: updatedProduct,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error updating product",
      error: error.message,
    });
  }
};

// DELETE - Delete product by ID
const deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;

    // Validation: Check if ID is valid MongoDB ObjectId
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid product ID format",
      });
    }

    // Delete the product
    const deletedProduct = await Product.findByIdAndDelete(id);

    if (!deletedProduct) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Product deleted successfully",
      product: deletedProduct,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error deleting product",
      error: error.message,
    });
  }
};

// Get products by category (for organizing loading)
const getProductsByCategory = async (req, res) => {
  try {
    const { category } = req.params;

    const products = await Product.find({ category }).select(
      "productName productDescription category price unit"
    );
    const formattedProducts = products.map(formatProductForDisplay);

    res.status(200).json({
      success: true,
      message: `Products in ${category} category retrieved successfully`,
      category,
      count: products.length,
      products: formattedProducts,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving products by category",
      error: error.message,
    });
  }
};

// Additional Utility Methods
// SEARCH - Search products by name or category
const searchProducts = async (req, res) => {
  try {
    const { query } = req.query; // Get search query from URL parameters (?query=apple)

    // Validation: Check if search query is provided
    if (!query || query.trim() === "") {
      return res.status(400).json({
        success: false,
        message: "Search query is required",
      });
    }

    // Create case-insensitive regex pattern for search
    const searchRegex = new RegExp(query.trim(), "i");

    // Search ONLY in productName and category
    const products = await Product.find({
      $or: [{ productName: searchRegex }, { category: searchRegex }],
    }).select("productName productDescription category price unit");

    const formattedProducts = products.map(formatProductForDisplay);

    res.status(200).json({
      success: true,
      message: `Search results for "${query.trim()}" in product names and categories`,
      searchQuery: query.trim(),
      count: products.length,
      products: formattedProducts,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error searching products",
      error: error.message,
    });
  }
};

// GET CATEGORIES - Get list of all unique categories
const getProductCategories = async (req, res) => {
  try {
    // Get distinct categories from products
    const categories = await Product.distinct("category");

    // Remove empty categories and sort
    const validCategories = categories
      .filter((cat) => cat && cat.trim() !== "")
      .sort();

    res.status(200).json({
      success: true,
      message: "Product categories retrieved successfully",
      count: validCategories.length,
      categories: validCategories,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving product categories",
      error: error.message,
    });
  }
};

// STATISTICS - Get product statistics and analytics
const getProductStatistics = async (req, res) => {
  try {
    // Get total count of products
    const totalProducts = await Product.countDocuments();

    // Get statistics by category using aggregation
    const categoryStats = await Product.aggregate([
      {
        // Group by category and calculate stats
        $group: {
          _id: "$category", // Group by category field
          count: { $sum: 1 }, // Count products in each category
          avgPrice: { $avg: "$price" }, // Average price per category
          minPrice: { $min: "$price" }, // Minimum price per category
          maxPrice: { $max: "$price" }, // Maximum price per category
          totalValue: { $sum: "$price" }, // Total value per category
        },
      },
      {
        // Sort by count (highest first)
        $sort: { count: -1 },
      },
    ]);

    // Get overall price statistics
    const overallPriceStats = await Product.aggregate([
      {
        $group: {
          _id: null, // Group all products together
          avgPrice: { $avg: "$price" }, // Overall average price
          minPrice: { $min: "$price" }, // Overall minimum price
          maxPrice: { $max: "$price" }, // Overall maximum price
          totalValue: { $sum: "$price" }, // Total value of all products
        },
      },
    ]);

    // Get products with highest and lowest prices
    const highestPricedProduct = await Product.findOne()
      .sort({ price: -1 })
      .select("productName price unit");
    const lowestPricedProduct = await Product.findOne()
      .sort({ price: 1 })
      .select("productName price unit");

    // Format response
    const statistics = {
      summary: {
        totalProducts,
        totalCategories: categoryStats.length,
        overallStats: overallPriceStats[0] || {
          avgPrice: 0,
          minPrice: 0,
          maxPrice: 0,
          totalValue: 0,
        },
      },
      categoryBreakdown: categoryStats,
      priceExtremes: {
        highestPriced: highestPricedProduct
          ? formatProductForDisplay(highestPricedProduct)
          : null,
        lowestPriced: lowestPricedProduct
          ? formatProductForDisplay(lowestPricedProduct)
          : null,
      },
    };

    res.status(200).json({
      success: true,
      message: "Product statistics retrieved successfully",
      statistics,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving product statistics",
      error: error.message,
    });
  }
};

module.exports = {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  searchProducts,
  getProductsByCategory,
  getProductCategories,
  getProductStatistics,
};
