// controllers/inventoryController.js
const Inventory = require('../Model/Inventory');

//
// Generate SKU automatically
const generateSKU = async (req, res) => {
  try {
    const { productName, category } = req.query;
    
    if (!productName || !category) {
      return res.status(400).json({ message: 'Product name and category are required' });
    }

    // Create base SKU from product name and category
    const categoryCode = category.substring(0, 3).toUpperCase();
    const productCode = productName
      .substring(0, 3)
      .toUpperCase()
      .replace(/\s+/g, '');
    
    let sku = `${categoryCode}-${productCode}`;
    let counter = 1;
    let finalSKU = sku;

    // Check if SKU exists and find available one
    while (true) {
      const existingProduct = await Inventory.findOne({ sku: finalSKU });
      if (!existingProduct) {
        break;
      }
      finalSKU = `${sku}-${counter.toString().padStart(3, '0')}`;
      counter++;
      
      // Safety break to prevent infinite loop
      if (counter > 999) {
        finalSKU = `${sku}-${Date.now().toString().slice(-3)}`;
        break;
      }
    }

    res.json({ sku: finalSKU });
  } catch (error) {
    res.status(500).json({ message: 'Error generating SKU', error: error.message });
  }
};


// Get all inventory items
const getAllInventory = async (req, res) => {
  try {
    const inventory = await Inventory.find().sort({ createdAt: -1 });
    res.json(inventory);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get single inventory item
const getInventoryById = async (req, res) => {
  try {
    const inventory = await Inventory.findById(req.params.id);
    if (!inventory) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }
    res.json(inventory);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Create new inventory item
const createInventory = async (req, res) => {
  try {
    const { productName, sku, category, price, quantity, description } = req.body;

    // Check if SKU already exists
    const existingItem = await Inventory.findOne({ sku });
    if (existingItem) {
      return res.status(400).json({ message: 'SKU already exists' });
    }

    // If no SKU provided, generate one
    let finalSKU = sku;
    if (!finalSKU) {
      const skuResponse = await generateSKU({ query: { productName, category } }, { json: () => {} });
      finalSKU = skuResponse.sku;
    }

    const inventory = new Inventory({
      productName,
      sku: finalSKU,
      category,
      price,
      description
    });

    const savedInventory = await inventory.save();
    res.status(201).json(savedInventory);
  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({ message: 'Validation error', error: error.message });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};


// Update inventory item (other functions remain the same)
const updateInventory = async (req, res) => {
  try {
    const { productName, category, price, quantity, description } = req.body;

    // SKU cannot be updated
    const updatedInventory = await Inventory.findByIdAndUpdate(
      req.params.id,
      { productName, category, price, quantity, description },
      { new: true, runValidators: true }
    );

    if (!updatedInventory) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }

    res.json(updatedInventory);
  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({ message: 'Validation error', error: error.message });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
// Delete inventory item
const deleteInventory = async (req, res) => {
  try {
    const deletedInventory = await Inventory.findByIdAndDelete(req.params.id);
    if (!deletedInventory) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }
    res.json({ message: 'Inventory item deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Search inventory
const searchInventory = async (req, res) => {
  try {
    const { query } = req.query;
    const inventory = await Inventory.find({
      $or: [
        { productName: { $regex: query, $options: 'i' } },
        { category: { $regex: query, $options: 'i' } },
        { sku: { $regex: query, $options: 'i' } }
      ]
    });
    res.json(inventory);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get low stock items
const getLowStock = async (req, res) => {
  try {
    const lowStockItems = await Inventory.find({
      quantity: { $lte: 10 } // Adjust threshold as needed
    });
    res.json(lowStockItems);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  generateSKU,
  getAllInventory,
  getInventoryById,
  createInventory,
  updateInventory,
  deleteInventory,
  searchInventory,
  getLowStock
};
