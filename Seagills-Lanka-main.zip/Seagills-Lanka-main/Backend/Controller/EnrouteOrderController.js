// Backend/Controller/EnrouteOrderController.js
const EnrouteOrder = require("../Model/EnrouteOrderModel");
const AssignedTruck = require("../Model/AssignedTruckModel");
const { User, DeliveryCoordinator } = require("../Model/UserModel");
const Product = require("../Model/ProductModel");
const mongoose = require("mongoose");

// Create en-route order with a specified payment method and a 'pending' status
const createEnrouteOrder = async (req, res) => {
  try {
    const {
      customerLocation,
      contactNum,
      deliveryCoordinatorID,
      products,
      paymentMethod,
    } = req.body;

    // 1. Validation: Check for required fields and user existence
    if (
      !customerLocation ||
      !contactNum ||
      !deliveryCoordinatorID ||
      !products ||
      !products.length ||
      !paymentMethod
    ) {
      return res.status(400).json({
        message:
          "Customer location, contact number, coordinator ID, products, and payment method are required",
      });
    }

    // Validate Sri Lankan mobile number (10 digits starting with 0)
    const phoneRegex = /^0\d{9}$/;
    if (!phoneRegex.test(contactNum.trim())) {
      return res.status(400).json({
        success: false,
        message:
          "Invalid contact number. Must be a 10-digit Sri Lankan mobile number starting with 0 (e.g., 0771234567)",
      });
    }

    const coordinator = await DeliveryCoordinator.findById(
      deliveryCoordinatorID
    );
    if (!coordinator) {
      return res.status(404).json({
        success: false,
        message: "Delivery coordinator not found",
      });
    }

    // 2. Product and Total Calculation with Unit Conversion
    const validatedProducts = [];
    let totalAmount = 0;
    let productCategory = null;

    for (const item of products) {
      const product = await Product.findById(item.productID).lean();
      if (!product) {
        return res
          .status(404)
          .json({ message: `Product not found: ${item.productID}` });
      }
      if (item.quantity <= 0) {
        return res
          .status(400)
          .json({ message: "Product quantities must be greater than 0" });
      }

      // Check if all products belong to the same category
      if (productCategory === null) {
        productCategory = product.category;
      } else if (productCategory !== product.category) {
        return res.status(400).json({
          message:
            "All products in an en-route order must belong to the same category.",
        });
      }

      // Perform unit conversion before calculation
      let convertedQuantity = item.quantity;
      if (product.unit === "kg" && item.unit === "g") {
        convertedQuantity = item.quantity / 1000;
      } else if (product.unit === "g" && item.unit === "kg") {
        convertedQuantity = item.quantity * 1000;
      }
      // Add more unit conversion logic here if needed (e.g., pcs to nos)

      totalAmount += product.price * convertedQuantity;
      validatedProducts.push({
        productID: product._id,
        quantity: item.quantity,
        unit: item.unit,
        unitPrice: product.price,
        // The saved `unit` and `quantity` will be what the user provided
      });
    }

    // 3. Create the En-route Order with 'pending' status
    const newEnrouteOrder = new EnrouteOrder({
      customerLocation: customerLocation.trim(),
      contactNum: contactNum.trim(),
      deliveryCoordinatorID,
      products: validatedProducts,
      totalAmount,
      paymentMethod,
      status: "pending", // Initial status is pending
      date: new Date(),
    });

    const savedOrder = await newEnrouteOrder.save();

    // 4. Respond with the created order
    const populatedOrder = await EnrouteOrder.findById(savedOrder._id)
      .populate("deliveryCoordinatorID", "firstName lastName username")
      .populate("products.productID", "productName category price");

    res.status(201).json({
      message: "En-route order created successfully with pending payment",
      order: populatedOrder,
    });
  } catch (error) {
    res.status(500).json({
      message: "Error creating en-route order",
      error: error.message,
    });
  }
};

// Get all en-route orders
const getAllEnrouteOrders = async (req, res) => {
  try {
    const { date, coordinatorId, status } = req.query;

    const filter = {};
    if (coordinatorId) filter.deliveryCoordinatorID = coordinatorId;
    if (status) filter.status = status;
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      filter.date = { $gte: startOfDay, $lte: endOfDay };
    }

    const orders = await EnrouteOrder.find(filter)
      .populate("deliveryCoordinatorID", "firstName lastName username")
      .populate("products.productID", "productName category price unit")
      .sort({ date: -1 });

    res.status(200).json({
      message: "En-route orders retrieved successfully",
      count: orders.length,
      filters: { date, coordinatorId, status },
      orders,
    });
  } catch (error) {
    res.status(500).json({
      message: "Error retrieving en-route orders",
      error: error.message,
    });
  }
};

// Get en-route orders by coordinator
const getEnrouteOrdersByCoordinator = async (req, res) => {
  try {
    const { coordinatorId } = req.params;
    const { date } = req.query;

    console.log("🪵 coordinatorId:", coordinatorId);
    console.log("🪵 date:", date);

    if (!mongoose.Types.ObjectId.isValid(coordinatorId)) {
      console.log("❌ Invalid ObjectId");
      return res.status(400).json({ message: "Invalid coordinator ID format" });
    }

    const filter = { deliveryCoordinatorID: coordinatorId };
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      filter.date = { $gte: startOfDay, $lte: endOfDay };
    }

    console.log("🪵 Filter:", filter);

    const orders = await EnrouteOrder.find(filter)
      .populate("deliveryCoordinatorID", "firstName lastName username")
      .populate("products.productID", "productName category price unit")
      .sort({ date: -1 });

    console.log("🪵 Orders count:", orders.length);

    if (!orders.length) {
      return res.status(200).json({
        message: "No en-route orders found",
        count: 0,
        orders: [],
      });
    }

    res.status(200).json({
      message: "Coordinator en-route orders retrieved successfully",
      count: orders.length,
      orders,
    });
  } catch (error) {
    console.error("🔥 ERROR retrieving orders:", error);
    res
      .status(500)
      .json({ message: "Error retrieving orders", error: error.message });
  }
};

// Get en-route orders by truck (for trip log)
const getEnrouteOrdersByTruck = async (req, res) => {
  try {
    const { truckId } = req.params;
    const { date } = req.query;

    // 1. Validate truck ID and date
    if (!mongoose.Types.ObjectId.isValid(truckId)) {
      return res.status(400).json({ message: "Invalid truck ID format" });
    }
    if (!date) {
      return res.status(400).json({
        message: "Date is required to get orders for a specific truck run.",
      });
    }

    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    // 2. Find the coordinator assigned to this truck on this specific date
    const assignment = await AssignedTruck.findOne({
      truckID: truckId,
      date: { $gte: startOfDay, $lte: endOfDay },
    }).select("deliveryCoordinatorID");

    if (!assignment) {
      return res.status(404).json({
        message:
          "No delivery coordinator found for this truck on the specified date.",
      });
    }

    const coordinatorId = assignment.deliveryCoordinatorID;

    // 3. Find all en-route orders made by this coordinator on this date
    const orders = await EnrouteOrder.find({
      deliveryCoordinatorID: coordinatorId,
      date: { $gte: startOfDay, $lte: endOfDay },
    })
      .populate("deliveryCoordinatorID", "firstName lastName username")
      .populate("products.productID", "productName category price unit")
      .sort({ date: -1 });

    if (!orders.length) {
      return res.status(404).json({
        message:
          "No en-route orders found for this truck on the specified date.",
      });
    }

    res.status(200).json({
      message: "En-route orders for truck retrieved successfully",
      truckId,
      date,
      count: orders.length,
      orders,
    });
  } catch (error) {
    res.status(500).json({
      message: "Error retrieving en-route orders",
      error: error.message,
    });
  }
};

// Get single en-route order by ID
const getEnrouteOrderById = async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid order ID format" });
    }

    const order = await EnrouteOrder.findById(id)
      .populate(
        "deliveryCoordinatorID",
        "firstName lastName username email telephone"
      )
      .populate(
        "products.productID",
        "productName category price productDescription"
      );

    if (!order) {
      return res.status(404).json({ message: "En-route order not found" });
    }

    res.status(200).json({
      message: "En-route order retrieved successfully",
      order,
    });
  } catch (error) {
    res.status(500).json({
      message: "Error retrieving en-route order",
      error: error.message,
    });
  }
};

// This function is for updating simple fields, not products
const updateEnrouteOrder = async (req, res) => {
  try {
    const { id } = req.params;
    const { customerLocation, contactNum } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid order ID format" });
    }

    const updateData = {};
    if (customerLocation) updateData.customerLocation = customerLocation.trim();
    if (contactNum) updateData.contactNum = contactNum.trim();

    const updatedOrder = await EnrouteOrder.findByIdAndUpdate(id, updateData, {
      new: true,
      runValidators: true,
    }).populate("deliveryCoordinatorID", "firstName lastName username");

    if (!updatedOrder) {
      return res.status(404).json({ message: "En-route order not found" });
    }

    res.status(200).json({
      message: "En-route order updated successfully",
      order: updatedOrder,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error updating en-route order", error: error.message });
  }
};

// Validation helper functions
const validatePhoneNumber = (phone) => {
  // Sri Lankan phone number validation (mobile: 07X-XXXXXXX, landline: 0XX-XXXXXXX)
  const phoneRegex = /^0[0-9]{8,9}$/;
  return phoneRegex.test(phone.replace(/[\s-]/g, ""));
};

const validateLocation = (location) => {
  // Basic location validation - should not be empty and should have reasonable length
  return (
    location && location.trim().length >= 5 && location.trim().length <= 200
  );
};

const validateNote = (note) => {
  if (!note) return true;
  return note.trim().length <= 500;
};

const validateProductQuantity = (quantity) => {
  return Number.isInteger(quantity) && quantity > 0 && quantity <= 1000;
};

// ============= SPRINT 1 =============

// User Story 1: Customer sends on-route stop request
const createEnrouteStopRequest = async (req, res) => {
  try {
    const { customerLocation, contactNum, note = "", products = [] } = req.body;

    // Validation 1: Required fields
    if (!customerLocation || !contactNum) {
      return res.status(400).json({
        success: false,
        message: "Customer location and contact number are required",
      });
    }

    // Validation 2: Validate customer location
    if (!validateLocation(customerLocation)) {
      return res.status(400).json({
        success: false,
        message: "Customer location must be between 5 and 200 characters",
      });
    }

    // Validation 3: Validate phone number
    if (!validatePhoneNumber(contactNum)) {
      return res.status(400).json({
        success: false,
        message:
          "Please provide a valid Sri Lankan phone number (e.g., 0712345678)",
      });
    }

    // Validation 4: Delivery note validation
    if (!validateNote(note)) {
      return res.status(400).json({
        success: false,
        message: "Delivery note must not exceed 500 characters",
      });
    }

    // Validation 5: Validate products if provided
    if (products && products.length > 0) {
      if (!Array.isArray(products) || products.length > 50) {
        return res.status(400).json({
          success: false,
          message: "Products must be an array with max 50 items",
        });
      }

      for (let i = 0; i < products.length; i++) {
        const product = products[i];
        if (!product.productID || !validateProductQuantity(product.quantity)) {
          return res.status(400).json({
            success: false,
            message: `Invalid product data at index ${i}. Product ID and valid quantity required.`,
          });
        }
      }
    }

    // Create stop request (coordinator will be assigned when they accept the request)
    const enrouteOrder = new EnrouteOrder({
      customerLocation: customerLocation.trim(),
      contactNum: contactNum.trim(),
      date: new Date(),
      note: note.trim(),
      status: "pending",
    });

    const savedOrder = await enrouteOrder.save();

    // Add products if provided
    const orderProducts = [];
    if (products && products.length > 0) {
      for (const product of products) {
        const existingProduct = await Product.findById(product.productID);
        if (!existingProduct) {
          // Rollback: Delete the order if product not found
          await EnrouteOrder.findByIdAndDelete(savedOrder._id);
          return res.status(404).json({
            success: false,
            message: `Product with ID ${product.productID} not found`,
          });
        }

        const enrouteOrderProduct = new EnrouteOrderProduct({
          enrouteOrderID: savedOrder._id,
          productID: product.productID,
          quantity: product.quantity,
        });

        const savedProduct = await enrouteOrderProduct.save();
        orderProducts.push(savedProduct);
      }
    }

    res.status(201).json({
      success: true,
      message: "On-route stop request submitted successfully",
      data: {
        order: savedOrder,
        products: orderProducts,
      },
    });
  } catch (error) {
    console.error("Error creating enroute stop request:", error);
    res.status(500).json({
      success: false,
      message: "Failed to create on-route stop request",
      error:
        process.env.NODE_ENV === "production"
          ? "Internal server error"
          : error.message,
    });
  }
};

// User Story 2: Customer adds short note with request
const updateDeliveryNote = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { note } = req.body; // FIXED: Check for null first

    if (!orderId) {
      return res.status(400).json({
        success: false,
        message: "Order ID is required",
      });
    } // <- MUST have this closing brace
    if (!orderId.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        success: false,
        message: "Invalid order ID format",
      });
    } // <- Closes this validation block
    if (!note || note.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: "Delivery note cannot be empty",
      });
    } // <- Closes this validation block
    if (!validateNote(note)) {
      return res.status(400).json({
        success: false,
        message: "Delivery note must not exceed 500 characters",
      });
    } // <- Closes this validation block
    const updatedOrder = await EnrouteOrder.findByIdAndUpdate(
      orderId,
      { note: note.trim() },
      { new: true, runValidators: true }
    );

    if (!updatedOrder) {
      return res.status(404).json({
        success: false,
        message: "Enroute order not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Delivery instructions updated successfully",
      data: updatedOrder,
    });
  } catch (error) {
    console.error("Error accepting stop request:", error);
    res.status(500).json({
      success: false,
      message: "Failed to accept stop request",
      error: error.message,
    });
  }
};

// ============= SPRINT 2 =============

// User Story 3: Coordinator accepts stop requests
const acceptStopRequest = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { coordinatorId, estimatedArrival, notes } = req.body; // FIXED: Check for null/undefined FIRST

    if (!orderId || !coordinatorId) {
      return res.status(400).json({
        success: false,
        message: "Order ID and coordinator ID are required",
      });
    } // FIXED: Now safe to call .match()

    if (
      !orderId.match(/^[0-9a-fA-F]{24}$/) ||
      !coordinatorId.match(/^[0-9a-fA-F]{24}$/)
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid ID format",
      });
    } // Verify coordinator exists

    const coordinator = await DeliveryCoordinator.findById(coordinatorId);
    if (!coordinator) {
      return res.status(404).json({
        success: false,
        message: "Delivery coordinator not found",
      });
    } // Verify order exists

    const order = await EnrouteOrder.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Stop request not found",
      });
    } // Check if order is still pending

    if (order.status !== "pending") {
      return res.status(400).json({
        success: false,
        message: "Request has already been processed",
      });
    } // Update order with acceptance details

    const updatedOrder = await EnrouteOrder.findByIdAndUpdate(
      orderId,
      {
        deliveryCoordinatorID: coordinatorId,
        status: "accepted",
        acceptedAt: new Date(),
        estimatedArrival: estimatedArrival || null,
        coordinatorNotes: notes || "",
      },
      { new: true, runValidators: true }
    ).populate("deliveryCoordinatorID", "firstName lastName email telephone");

    res.status(200).json({
      success: true,
      message: "Stop request accepted successfully",
      data: updatedOrder,
    });
  } catch (error) {
    console.error("Error accepting stop request:", error);
    res.status(500).json({
      success: false,
      message: "Failed to accept stop request",
      error: error.message,
    });
  }
};

// User Story 3: Coordinator rejects stop requests
const rejectStopRequest = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { coordinatorId, rejectionReason } = req.body; // FIXED: Check for null/undefined FIRST

    if (!orderId || !coordinatorId || !rejectionReason) {
      return res.status(400).json({
        success: false,
        message: "Order ID, coordinator ID, and rejection reason are required",
      });
    } // FIXED: Now safe to call .match() and .trim()

    if (
      !orderId.match(/^[0-9a-fA-F]{24}$/) ||
      !coordinatorId.match(/^[0-9a-fA-F]{24}$/)
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid ID format",
      });
    } // Validate rejection reason length

    if (
      rejectionReason.trim().length < 10 ||
      rejectionReason.trim().length > 500
    ) {
      return res.status(400).json({
        success: false,
        message: "Rejection reason must be between 10 and 500 characters",
      });
    } // Verify coordinator exists

    const coordinator = await DeliveryCoordinator.findById(coordinatorId);
    if (!coordinator) {
      return res.status(404).json({
        success: false,
        message: "Delivery coordinator not found",
      });
    } // Verify order exists

    const order = await EnrouteOrder.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Stop request not found",
      });
    } // Check if order is still pending

    if (order.status !== "pending") {
      return res.status(400).json({
        success: false,
        message: "Request has already been processed",
      });
    } // Update order with rejection details

    const updatedOrder = await EnrouteOrder.findByIdAndUpdate(
      orderId,
      {
        deliveryCoordinatorID: coordinatorId,
        status: "rejected",
        rejectedAt: new Date(),
        rejectionReason: rejectionReason.trim(),
      },
      { new: true, runValidators: true }
    );

    res.status(200).json({
      success: true,
      message: "Stop request rejected",
      data: updatedOrder,
    });
  } catch (error) {
    console.error("Error rejecting stop request:", error);
    res.status(500).json({
      success: false,
      message: "Failed to reject stop request",
      error: error.message,
    });
  }
};

// User Story 4: Coordinator is instantly notified of stop requests
const getPendingRequestsForCoordinator = async (req, res) => {
  try {
    const { coordinatorId } = req.params; // FIXED: Proper validation order

    if (!coordinatorId) {
      return res.status(400).json({
        success: false,
        message: "Coordinator ID is required",
      });
    }

    if (!coordinatorId.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        success: false,
        message: "Invalid coordinator ID format",
      });
    }

    const coordinator = await DeliveryCoordinator.findById(coordinatorId);
    if (!coordinator) {
      return res.status(404).json({
        success: false,
        message: "Delivery coordinator not found",
      });
    } // Get all pending requests

    const pendingRequests = await EnrouteOrder.find({
      status: "pending",
    }).sort({ createdAt: -1 }); // Get requests assigned to this coordinator

    const assignedRequests = await EnrouteOrder.find({
      deliveryCoordinatorID: coordinatorId,
      status: { $in: ["accepted", "pending"] },
    }).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      message: "Requests retrieved successfully",
      data: {
        newPendingRequests: pendingRequests,
        myAssignedRequests: assignedRequests,
        notificationCount: pendingRequests.length,
      },
    });
  } catch (error) {
    console.error("Error fetching requests:", error);
    res.status(500).json({
      success: false,
      message: "Failed to retrieve requests",
      error: error.message,
    });
  }
};

// User Story 5: Customer knows if request is accepted or rejected
const getRequestStatus = async (req, res) => {
  try {
    const { orderId } = req.params; // Validate orderId exists

    if (!orderId) {
      return res.status(400).json({
        success: false,
        message: "Order ID is required",
      });
    } // Validate orderId format

    if (!orderId.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        success: false,
        message: "Invalid order ID format",
      });
    } // Fetch order with populated coordinator details

    const order = await EnrouteOrder.findById(orderId)
      .populate("deliveryCoordinatorID", "firstName lastName telephone")
      .select(
        "customerLocation contactNum status acceptedAt rejectedAt rejectionReason estimatedArrival coordinatorNotes createdAt note deliveredAt totalAmount"
      ); // Check if order exists

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Request not found",
      });
    } // Build base status info

    let statusInfo = {
      orderId: order._id,
      customerLocation: order.customerLocation,
      contactNum: order.contactNum,
      requestDate: order.createdAt,
      status: order.status || "pending",
      note: order.note || "",
    }; // Add status-specific information

    if (order.status === "accepted") {
      statusInfo = {
        ...statusInfo,
        acceptedAt: order.acceptedAt,
        coordinator: order.deliveryCoordinatorID
          ? {
              name: `${order.deliveryCoordinatorID.firstName} ${order.deliveryCoordinatorID.lastName}`,
              contact: order.deliveryCoordinatorID.telephone,
            }
          : null,
        estimatedArrival: order.estimatedArrival,
        notes: order.coordinatorNotes,
      };
    } else if (order.status === "rejected") {
      statusInfo = {
        ...statusInfo,
        rejectedAt: order.rejectedAt,
        rejectionReason: order.rejectionReason,
      };
    } else if (order.status === "delivered") {
      statusInfo = {
        ...statusInfo,
        deliveredAt: order.deliveredAt,
        totalAmount: order.totalAmount,
        coordinator: order.deliveryCoordinatorID
          ? {
              name: `${order.deliveryCoordinatorID.firstName} ${order.deliveryCoordinatorID.lastName}`,
              contact: order.deliveryCoordinatorID.telephone,
            }
          : null,
      };
    } // Return success response

    res.status(200).json({
      success: true,
      message: "Request status retrieved successfully",
      data: statusInfo,
    });
  } catch (error) {
    console.error("Error fetching request status:", error);
    res.status(500).json({
      success: false,
      message: "Failed to retrieve request status",
      error: error.message,
    });
  }
};

// ============= SPRINT 3 =============

// User Story 6: Coordinator uses existing POS system for better payment service
const generateBillAfterDelivery = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { deliveryConfirmed } = req.body; // FIXED: Proper validation

    if (!orderId) {
      return res.status(400).json({
        success: false,
        message: "Order ID is required",
      });
    }

    if (!orderId.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        success: false,
        message: "Invalid order ID format",
      });
    }

    const order = await EnrouteOrder.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    if (order.status !== "accepted") {
      return res.status(400).json({
        success: false,
        message: "Order must be accepted to generate bill",
      });
    }

    if (!deliveryConfirmed) {
      return res.status(400).json({
        success: false,
        message: "Delivery must be confirmed to generate bill",
      });
    } // Get products for billing

    const orderProducts = await EnrouteOrderProduct.find({
      enrouteOrderID: orderId,
    }).populate("productID", "productName price");

    let totalAmount = 0;
    const billItems = orderProducts.map((item) => {
      const itemTotal = item.quantity * item.productID.price;
      totalAmount += itemTotal;
      return {
        productName: item.productID.productName,
        quantity: item.quantity,
        unitPrice: item.productID.price,
        total: itemTotal,
      };
    }); // Add delivery fee

    const deliveryFee = 200;
    totalAmount += deliveryFee; // Update order status to delivered

    await EnrouteOrder.findByIdAndUpdate(orderId, {
      status: "delivered",
      deliveredAt: new Date(),
      billGenerated: true,
      totalAmount: totalAmount,
    });

    const bill = {
      orderId: order._id,
      customerLocation: order.customerLocation,
      contactNum: order.contactNum,
      deliveryDate: new Date(),
      items: billItems,
      deliveryFee: deliveryFee,
      totalAmount: totalAmount,
      billNumber: `BILL-${Date.now()}`,
      paymentStatus: "pending",
    };

    res.status(200).json({
      success: true,
      message: "Bill generated successfully",
      data: bill,
    });
  } catch (error) {
    console.error("Error generating bill:", error);
    res.status(500).json({
      success: false,
      message: "Failed to generate bill",
      error: error.message,
    });
  }
};

// User Story 8: Admin generates summary report of enroute orders
const generateEnrouteSummaryReport = async (req, res) => {
  try {
    const { startDate, endDate, coordinatorId } = req.query;

    let filter = {}; // FIXED: Date range filter with validation
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      if (isNaN(start.getTime()) || isNaN(end.getTime())) {
        return res.status(400).json({
          success: false,
          message: "Invalid date format",
        });
      }
      if (start > end) {
        return res.status(400).json({
          success: false,
          message: "Start date must be before end date",
        });
      }
      filter.createdAt = {
        $gte: start,
        $lte: end,
      };
    } // Coordinator filter

    if (coordinatorId) {
      if (!coordinatorId.match(/^[0-9a-fA-F]{24}$/)) {
        return res.status(400).json({
          success: false,
          message: "Invalid coordinator ID format",
        });
      }
      filter.deliveryCoordinatorID = coordinatorId;
    }

    const orders = await EnrouteOrder.find(filter)
      .populate("deliveryCoordinatorID", "firstName lastName")
      .sort({ createdAt: -1 }); // Generate statistics

    const stats = {
      totalRequests: orders.length,
      pendingRequests: orders.filter((o) => o.status === "pending").length,
      acceptedRequests: orders.filter((o) => o.status === "accepted").length,
      rejectedRequests: orders.filter((o) => o.status === "rejected").length,
      deliveredRequests: orders.filter((o) => o.status === "delivered").length,
      coordinatorPerformance: {},
    }; // Coordinator performance analysis

    const coordinatorStats = {};
    orders.forEach((order) => {
      if (order.deliveryCoordinatorID) {
        const coordId = order.deliveryCoordinatorID._id.toString();
        const coordName = `${order.deliveryCoordinatorID.firstName} ${order.deliveryCoordinatorID.lastName}`;
        if (!coordinatorStats[coordId]) {
          coordinatorStats[coordId] = {
            name: coordName,
            total: 0,
            accepted: 0,
            rejected: 0,
            delivered: 0,
          };
        }
        coordinatorStats[coordId].total++;
        if (order.status === "accepted") coordinatorStats[coordId].accepted++;
        if (order.status === "rejected") coordinatorStats[coordId].rejected++;
        if (order.status === "delivered") coordinatorStats[coordId].delivered++;
      }
    });

    stats.coordinatorPerformance = coordinatorStats;

    res.status(200).json({
      success: true,
      message: "Summary report generated successfully",
      data: {
        reportDate: new Date(),
        filters: { startDate, endDate, coordinatorId },
        statistics: stats,
        orders: orders,
      },
    });
  } catch (error) {
    console.error("Error generating report:", error);
    res.status(500).json({
      success: false,
      message: "Failed to generate report",
      error: error.message,
    });
  }
};

module.exports = {
  createEnrouteStopRequest,
  acceptStopRequest,
  rejectStopRequest,
  getRequestStatus,
  generateBillAfterDelivery,
  updateDeliveryNote,
  generateEnrouteSummaryReport,
  getPendingRequestsForCoordinator,
  createEnrouteOrder,
  getEnrouteOrdersByCoordinator,
  getEnrouteOrdersByTruck,
  getEnrouteOrderById,
  updateEnrouteOrder,
  getAllEnrouteOrders,
};
