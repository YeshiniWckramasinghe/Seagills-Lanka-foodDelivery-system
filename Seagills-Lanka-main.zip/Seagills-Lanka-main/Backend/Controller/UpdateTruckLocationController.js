// Controller/UpdateTruckLocationController.js
const Truck = require("../Model/TruckModel");
const AssignedTruck = require("../Model/AssignedTruckModel");
const Branch = require("../Model/BranchModel");

/**
 * Update all trucks' status and location based on today's assignments.
 * Idle trucks stay at branch. Assigned trucks' location is updated in real-time.
 */
const updateTruckLocations = async () => {
  try {
    const trucks = await Truck.find().populate("branchID");

    for (let truck of trucks) {
      // Today's date
      const today = new Date();
      const startOfDay = new Date(today.setHours(0, 0, 0, 0));
      const endOfDay = new Date(today.setHours(23, 59, 59, 999));

      // Check if truck has an assignment today
      const assignment = await AssignedTruck.findOne({
        truckID: truck._id,
        date: { $gte: startOfDay, $lte: endOfDay },
      });

      if (!assignment) {
        // No assignment → truck is idle
        truck.status = "idle";
        // Keep at branch location
        if (truck.branchID?.location?.coordinates?.length === 2) {
          truck.currentLocation.coordinates = truck.branchID.location.coordinates;
        } else {
          // Fallback to Colombo
          truck.currentLocation.coordinates = [79.8612, 6.9271]; // [lng, lat]
        }
      } else {
        // Truck is assigned → status assigned
        truck.status = "assigned";
        // currentLocation will be updated in real-time via driver GPS
        // (do not overwrite here)
      }

      await truck.save();
    }

    console.log("✅ Truck statuses and locations updated");
  } catch (err) {
    console.error("❌ Error updating trucks:", err.message);
  }
};

/**
 * Real-time update of truck location from driver
 * @param {string} driverID - ID of the driver sending coordinates
 * @param {number} lat - Latitude
 * @param {number} lon - Longitude
 */
const updateTruckLocationByDriver = async (driverID, lat, lon) => {
  try {
    const assignment = await AssignedTruck.findOne({ driverID }).populate("truckID");
    if (!assignment) return;

    const truck = await Truck.findById(assignment.truckID._id);
    if (!truck) return;

    truck.currentLocation.coordinates = [lon, lat]; // [lng, lat]
    await truck.save();
  } catch (err) {
    console.error("❌ Error updating truck location from driver:", err.message);
  }
};

module.exports = { updateTruckLocations, updateTruckLocationByDriver };
