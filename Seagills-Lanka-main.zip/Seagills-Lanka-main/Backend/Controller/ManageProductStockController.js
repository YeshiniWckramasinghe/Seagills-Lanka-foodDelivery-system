const mongoose = require("mongoose");
const ManageProductStock = require("../Model/ManageProductStockModel");


// Register dummy Product and Branch models if not already registere
if (!mongoose.models.Product) {
  mongoose.model("Product", new mongoose.Schema({}, { strict: false }));
}
if (!mongoose.models.Branch) {
  mongoose.model("Branch", new mongoose.Schema({}, { strict: false }));
}
if (!mongoose.models.User) {
  mongoose.model("User", new mongoose.Schema({}, { strict: false }));
}

// Add new stock
exports.addStock = async (req, res) => {
  try {
    const { productID, branchID, stockManagerID, stockLevel, lastRestockedDate } = req.body;

    const stock = new ManageProductStock({
      productID,
      branchID,
      stockManagerID,
      stockLevel,
      lastRestockedDate
    });

    await stock.save();
    res.status(201).json({ message: "Stock added successfully", stock });
  } catch (err) {
    console.error(err);
    if (err.code === 11000) {
      return res.status(400).json({
        message: "Duplicate entry for product, branch, and manager combination"
      });
    }
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// View all stock
exports.getAllStock = async (req, res) => {
  try {
    const stocks = await ManageProductStock.find()
      .populate("productID", "name")        //  populate product name
      .populate("branchID", "name")         //  populate branch name
      .populate("stockManagerID", "username email role"); //  populate manager info

    res.status(200).json(stocks);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// Update stock by ID
exports.updateStock = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    const updatedStock = await ManageProductStock.findByIdAndUpdate(
      id,
      updateData,
      { new: true }
    );

    if (!updatedStock) return res.status(404).json({ message: "Stock not found" });

    res.status(200).json({ message: "Stock updated successfully", updatedStock });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// Delete stock by ID
exports.deleteStock = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedStock = await ManageProductStock.findByIdAndDelete(id);
    if (!deletedStock) return res.status(404).json({ message: "Stock not found" });

    res.status(200).json({ message: "Stock deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};
