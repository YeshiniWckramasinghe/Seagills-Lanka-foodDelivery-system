// backend/controller/AssignedTruckController.js (or a helper file)
const updateTruckStatuses = async () => {
  const Truck = require("../Model/TruckModel");
  const AssignedTruck = require("../Model/AssignedTruckModel");

  const trucks = await Truck.find();
  const today = new Date();
  const startOfDay = new Date(today.setHours(0, 0, 0, 0));
  const endOfDay = new Date(today.setHours(23, 59, 59, 999));

  for (const truck of trucks) {
    const assignmentToday = await AssignedTruck.findOne({
      truckID: truck._id,
      date: { $gte: startOfDay, $lte: endOfDay },
    });

    if (assignmentToday) {
      truck.status = "assigned";
    } else {
      truck.status = "idle"; // reset if no assignment today
    }

    await truck.save();
  }
};
