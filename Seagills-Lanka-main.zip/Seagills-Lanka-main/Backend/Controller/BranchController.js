const Branch = require("../Model/BranchModel");

// CREATE: Insert a new branch
const createBranch = async (req, res, next) => {
  try {
    const { branchName, branchAddress, location } = req.body;

    // Validate location object (optional)
    if (
      !location ||
      !location.coordinates ||
      location.coordinates.length !== 2
    ) {
      return res.status(400).json({
        message: "Invalid location format. Provide [longitude, latitude].",
      });
    }

    // Check duplicate name
    const existingBranch = await Branch.findOne({ branchName });
    if (existingBranch) {
      return res.status(400).json({
        message: "Branch with this name already exists",
      });
    }

    const branch = new Branch({ branchName, branchAddress, location });
    await branch.save();
    return res
      .status(201)
      .json({ message: "Branch created successfully", branch });
  } catch (err) {
    next(err);
  }
};

// READ: Get a single branch by ID
const getBranchById = async (req, res, next) => {
  try {
    const branch = await Branch.findById(req.params.id);
    if (!branch) return res.status(404).json({ message: "Branch not found" });
    return res.status(200).json(branch);
  } catch (err) {
    next(err);
  }
};

// READ: Get all branches
const getAllBranches = async (req, res, next) => {
  try {
    const branches = await Branch.find();
    return res.status(200).json(branches);
  } catch (err) {
    next(err);
  }
};

// UPDATE: Update branch by ID
const updateBranch = async (req, res, next) => {
  try {
    const { branchName, branchAddress, location } = req.body;

    // Check for duplicate name if branchName is being updated
    if (branchName) {
      const existingBranch = await Branch.findOne({
        branchName,
        _id: { $ne: req.params.id },
      });
      if (existingBranch) {
        return res.status(400).json({
          message: "Branch with this name already exists",
        });
      }
    }

    // Build update data object
    const updateData = {};
    if (branchName) updateData.branchName = branchName;
    if (branchAddress) updateData.branchAddress = branchAddress;
    if (location && location.coordinates && location.coordinates.length === 2) {
      updateData.location = location;
    }

    const branch = await Branch.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
      runValidators: true,
    });

    if (!branch) return res.status(404).json({ message: "Branch not found" });
    return res
      .status(200)
      .json({ message: "Branch updated successfully", branch });
  } catch (err) {
    next(err);
  }
};

// DELETE: Delete branch by ID
const deleteBranch = async (req, res, next) => {
  try {
    const branch = await Branch.findByIdAndDelete(req.params.id);
    if (!branch) return res.status(404).json({ message: "Branch not found" });
    return res
      .status(200)
      .json({ message: "Branch deleted successfully", branch });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  createBranch,
  getBranchById,
  getAllBranches,
  updateBranch,
  deleteBranch,
};
