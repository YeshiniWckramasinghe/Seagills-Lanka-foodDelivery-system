const AssignedTruck = require("../Model/AssignedTruckModel");

// Daily Truck Report - Fixed Date Comparison with Debugging
const getDailyTruckReport = async (req, res) => {
  try {
    const { date } = req.params; // 'YYYY-MM-DD' from frontend

    console.log("\n========== DAILY TRUCK REPORT ==========");
    console.log("📅 Frontend requested date:", date);

    // First, let's see what's ACTUALLY in the database
    const allRecords = await AssignedTruck.find().select("date");
    console.log("🔍 ALL dates in database:");
    allRecords.forEach((record, idx) => {
      const dateObj = new Date(record.date);
      const dateString = dateObj.toISOString().split('T')[0];
      console.log(`  Record ${idx + 1}: ${record.date} → ${dateString}`);
    });

    // Parse the frontend date (YYYY-MM-DD)
    const [year, month, day] = date.split('-');
    const requestedDate = new Date(`${year}-${month}-${day}`);
    
    console.log("📍 Requested date object:", requestedDate.toISOString());

    // ALTERNATIVE APPROACH: Convert to local date range
    // Create start and end of day in LOCAL timezone (not UTC)
    const localDate = new Date(date);
    const startOfDay = new Date(localDate.getFullYear(), localDate.getMonth(), localDate.getDate(), 0, 0, 0, 0);
    const endOfDay = new Date(localDate.getFullYear(), localDate.getMonth(), localDate.getDate(), 23, 59, 59, 999);

    console.log("⏱️  Query range (local):", startOfDay, "to", endOfDay);

    // Query assignments with local date comparison
    const assignments = await AssignedTruck.find({
      date: { $gte: startOfDay, $lte: endOfDay }
    })
      .populate("truckID")
      .populate("driverID", "firstName lastName email telephone licenseNumber assignedTruck")
      .populate("deliveryCoordinatorID")
      .sort({ createdAt: -1 });

    console.log(`✅ Found ${assignments.length} assignments for ${date}`);
    
    // Log what we found
    assignments.forEach((a, idx) => {
      console.log(`  Assignment ${idx + 1}: ${a.date} (truck: ${a.truckID?.truckNumber})`);
    });

    // Map to report format
    const report = assignments.map(a => ({
      _id: a._id,
      truckNumber: a.truckID?.truckNumber || "N/A",
      plateNo: a.truckID?.plateNo || "N/A",
      colour: a.truckID?.colour || "N/A",
      status: a.truckID?.status || "N/A",
      driverName: a.driverID 
        ? `${a.driverID.firstName} ${a.driverID.lastName}` 
        : "N/A",
      coordinatorName: a.deliveryCoordinatorID
        ? `${a.deliveryCoordinatorID.firstName} ${a.deliveryCoordinatorID.lastName}`
        : "N/A",
      branchName: a.branchID?.branchName || "N/A",
      category: a.category || "N/A",
      startTime: a.startTime || "-",
      endTime: a.endTime || null,
      tripStatus: a.tripStatus || "Pending",
      route: a.route || "N/A"
    }));

    console.log(`📊 Report prepared with ${report.length} records`);
    console.log("========== END REPORT ==========\n");

    res.status(200).json({
      success: true,
      date,
      totalTrucks: report.length,
      report,
    });
  } catch (error) {
    console.error("❌ Error generating daily truck report:", error);
    res.status(500).json({
      success: false,
      message: "Error generating daily truck report",
      error: error.message,
    });
  }
};

module.exports = { getDailyTruckReport };