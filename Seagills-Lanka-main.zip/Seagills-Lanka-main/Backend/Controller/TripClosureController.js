// Backend/Controller/TripClosureController.js
const TripSummary = require("../Model/TripSummaryModel");
const DailyLoading = require("../Model/DailyLoadingModel");
const { Preorder } = require("../Model/PreorderModel");
const EnrouteOrder = require("../Model/EnrouteOrderModel");
const Incident = require("../Model/IncidentModel");
const AssignedTruck = require("../Model/AssignedTruckModel");
const TruckRoute = require("../Model/TruckRouteModel");
const mongoose = require("mongoose");

// Close trip and generate summary
const closeTripAndGenerateSummary = async (req, res) => {
  try {
    const {
      truckID,
      coordinatorID,
      tripDate,
      tripStartTime,
      tripEndTime,
      coordinatorNotes,
    } = req.body;

    // Validation: Check required fields
    if (!truckID || !coordinatorID || !tripDate) {
      return res.status(400).json({
        success: false,
        message: "Truck ID, coordinator ID, and trip date are required",
      });
    }

    // Validation: Check if trip summary already exists
    const startOfDay = new Date(tripDate);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(tripDate);
    endOfDay.setHours(23, 59, 59, 999);

    const existingSummary = await TripSummary.findOne({
      truckID,
      tripDate: { $gte: startOfDay, $lte: endOfDay },
    });

    if (existingSummary) {
      return res.status(400).json({
        success: false,
        message: "Trip summary already exists for this truck and date",
      });
    }

    // 1. Get truck assignment details
    const assignment = await AssignedTruck.findOne({
      truckID,
      date: { $gte: startOfDay, $lte: endOfDay },
    }).populate("driverID", "driverName");

    if (!assignment) {
      return res.status(404).json({
        success: false,
        message: "No truck assignment found for this date",
      });
    }

    // 2. Get loading summary
    const dailyLoading = await DailyLoading.findOne({
      truckID,
      date: { $gte: startOfDay, $lte: endOfDay },
    });

    const loadingSummary = dailyLoading
      ? {
          category: dailyLoading.category,
          totalWeight: dailyLoading.totalWeight,
          loadingStartTime: dailyLoading.loadingStartTime,
          loadingEndTime: dailyLoading.loadingEndTime,
          loadedPreorderCount: dailyLoading.loadedPreorderProducts?.length || 0,
          loadedStockItemsCount: dailyLoading.loadedStockItems?.length || 0,
        }
      : null;

    // 3. Get pre-order statistics
    const preorders = await Preorder.find({
      orderDate: { $gte: startOfDay, $lte: endOfDay },
    });

    const deliveryStats = {
      totalPreorders: preorders.length,
      deliveredPreorders: preorders.filter((p) => p.orderStatus === "delivered")
        .length,
      failedPreorders: preorders.filter((p) => p.orderStatus === "failed")
        .length,
      pendingPreorders: preorders.filter(
        (p) =>
          p.orderStatus === "pending" || p.orderStatus === "out_for_delivery"
      ).length,
      totalEnrouteOrders: 0,
      deliveredEnrouteOrders: 0,
      pendingEnrouteOrders: 0,
    };

    // 4. Get en-route order statistics
    const enrouteOrders = await EnrouteOrder.find({
      deliveryCoordinatorID: coordinatorID,
      date: { $gte: startOfDay, $lte: endOfDay },
    });

    deliveryStats.deliveredEnrouteOrders = enrouteOrders.filter(
      (o) => o.status === "Completed"
    ).length;

    deliveryStats.pendingEnrouteOrders = enrouteOrders.filter(
      (o) => o.status === "Pending"
    ).length;

    // 5. Calculate payment summary
    const deliveredPreorders = preorders.filter(
      (p) => p.orderStatus === "delivered"
    );
    const deliveredEnroute = enrouteOrders.filter(
      (o) => o.status === "delivered"
    );

    const paymentSummary = {
      // Pre-orders
      totalPreorderAmount: preorders.reduce(
        (sum, p) => sum + (p.totalAmount || 0),
        0
      ),
      collectedPreorderAmount: deliveredPreorders.reduce(
        (sum, p) => sum + (p.totalAmount || 0),
        0
      ),
      pendingPreorderAmount: preorders
        .filter((p) => p.orderStatus !== "delivered")
        .reduce((sum, p) => sum + (p.totalAmount || 0), 0),

      // En-route orders
      totalEnrouteAmount: enrouteOrders.reduce(
        (sum, o) => sum + (o.totalAmount || 0),
        0
      ),
      collectedEnrouteAmount: deliveredEnroute.reduce(
        (sum, o) => sum + (o.totalAmount || 0),
        0
      ),

      // Payment methods
      cashCollected: 0,
      cardCollected: 0,
      totalCollected: 0,
    };

    // Calculate by payment method
    [...deliveredPreorders, ...deliveredEnroute].forEach((order) => {
      if (order.paymentMethod === "cash") {
        paymentSummary.cashCollected += order.totalAmount || 0;
      } else if (order.paymentMethod === "card") {
        paymentSummary.cardCollected += order.totalAmount || 0;
      }
    });

    paymentSummary.totalCollected =
      paymentSummary.cashCollected + paymentSummary.cardCollected;

    // 6. Get incidents for this trip
    const incidents = await Incident.find({
      truckID,
      tripDate: { $gte: startOfDay, $lte: endOfDay },
    });

    // 7. Calculate trip duration
    let tripDurationMinutes = null;
    if (tripStartTime && tripEndTime) {
      const start = new Date(tripStartTime);
      const end = new Date(tripEndTime);
      tripDurationMinutes = Math.round((end - start) / (1000 * 60));
    }

    // 8. Determine trip status
    let tripStatus = "completed";
    if (
      deliveryStats.failedPreorders > 0 ||
      deliveryStats.pendingPreorders > 0
    ) {
      tripStatus = "partial";
    }
    if (incidents.some((i) => i.severity === "critical")) {
      tripStatus = "failed";
    }

    // 9. Create trip summary
    const tripSummary = new TripSummary({
      truckID,
      coordinatorID,
      driverID: assignment.driverID._id,
      routeID: assignment.routeID || null,
      tripDate: new Date(tripDate),
      loadingSummary,
      deliveryStats,
      paymentSummary,
      incidentCount: incidents.length,
      incidentIds: incidents.map((i) => i._id),
      tripStartTime: tripStartTime ? new Date(tripStartTime) : null,
      tripEndTime: tripEndTime ? new Date(tripEndTime) : null,
      tripDurationMinutes,
      tripStatus,
      coordinatorNotes: coordinatorNotes || "",
      submittedAt: new Date(),
    });

    const savedSummary = await tripSummary.save();

    // NEW: Update the TruckRoute schedule with completion details
    const schedule = await TruckRoute.findOne({
      truckID,
      date: { $gte: startOfDay, $lte: endOfDay },
    });

    if (schedule) {
      schedule.tripStatus = "completed";
      schedule.tripCompletedAt = new Date(tripEndTime);
      schedule.endTime = new Date(tripEndTime).toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      await schedule.save();
    }

    // Populate for response
    await savedSummary.populate([
      { path: "truckID", select: "plateNo colour" },
      { path: "coordinatorID", select: "firstName lastName username" },
      { path: "driverID", select: "driverName" },
      { path: "routeID", select: "start end" },
    ]);

    res.status(201).json({
      success: true,
      message: "Trip closed and summary generated successfully",
      tripSummary: savedSummary,
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: "Trip summary already exists for this truck and date",
      });
    }
    res.status(500).json({
      success: false,
      message: "Error closing trip",
      error: error.message,
    });
  }
};

// Get trip summary by truck and date
const getTripSummaryByTruckAndDate = async (req, res) => {
  try {
    const { truckId } = req.params;
    const { date } = req.query;

    // Validation
    if (!mongoose.Types.ObjectId.isValid(truckId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid truck ID format",
      });
    }

    if (!date) {
      return res.status(400).json({
        success: false,
        message: "Date is required",
      });
    }

    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const summary = await TripSummary.findOne({
      truckID: truckId,
      tripDate: { $gte: startOfDay, $lte: endOfDay },
    })
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username email telephone")
      .populate("driverID", "firstName lastName")
      .populate("routeID", "start end")
      .populate({
        path: "incidentIds",
        select:
          "incidentType description location incidentTime severity status",
      });

    if (!summary) {
      return res.status(404).json({
        success: false,
        message: "Trip summary not found for this truck and date",
      });
    }

    res.status(200).json({
      success: true,
      message: "Trip summary retrieved successfully",
      tripSummary: summary,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving trip summary",
      error: error.message,
    });
  }
};

// Get all trip summaries by coordinator
const getTripSummariesByCoordinator = async (req, res) => {
  try {
    const { coordinatorId } = req.params;
    const { startDate, endDate, status } = req.query;

    // Validation
    if (!mongoose.Types.ObjectId.isValid(coordinatorId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid coordinator ID format",
      });
    }

    const filter = { coordinatorID: coordinatorId };

    // Add date range filter
    if (startDate && endDate) {
      filter.tripDate = {
        $gte: new Date(startDate),
        $lte: new Date(endDate),
      };
    }

    // Add status filter
    if (status) {
      filter.tripStatus = status;
    }

    const summaries = await TripSummary.find(filter)
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .populate("driverID", "firstName lastName")
      .sort({ tripDate: -1 });

    res.status(200).json({
      success: true,
      message: "Coordinator trip summaries retrieved successfully",
      coordinatorId,
      count: summaries.length,
      tripSummaries: summaries,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving coordinator trip summaries",
      error: error.message,
    });
  }
};

// Get all trip summaries with filters
const getAllTripSummaries = async (req, res) => {
  try {
    const { date, status, truckId, coordinatorId } = req.query;

    const filter = {};

    if (truckId) filter.truckID = truckId;
    if (coordinatorId) filter.coordinatorID = coordinatorId;
    if (status) filter.tripStatus = status;

    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      filter.tripDate = { $gte: startOfDay, $lte: endOfDay };
    }

    const summaries = await TripSummary.find(filter)
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .populate("driverID", "firstName lastName")
      .sort({ tripDate: -1 });

    // Calculate aggregate statistics
    const aggregateStats = {
      totalTrips: summaries.length,
      completedTrips: summaries.filter((s) => s.tripStatus === "completed")
        .length,
      partialTrips: summaries.filter((s) => s.tripStatus === "partial").length,
      failedTrips: summaries.filter((s) => s.tripStatus === "failed").length,
      totalRevenue: summaries.reduce(
        (sum, s) => sum + (s.paymentSummary?.totalCollected || 0),
        0
      ),
      totalIncidents: summaries.reduce(
        (sum, s) => sum + (s.incidentCount || 0),
        0
      ),
    };

    res.status(200).json({
      success: true,
      message: "All trip summaries retrieved successfully",
      count: summaries.length,
      aggregateStats,
      filters: { date, status, truckId, coordinatorId },
      tripSummaries: summaries,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving trip summaries",
      error: error.message,
    });
  }
};

// Generate detailed PDF-ready report for a specific trip
const generateDetailedTripReport = async (req, res) => {
  try {
    const { id } = req.params;

    // Validation
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid trip summary ID format",
      });
    }

    const summary = await TripSummary.findById(id)
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username email telephone")
      .populate("driverID", "firstName lastName licenseNo")
      .populate("routeID", "start end")
      .populate({
        path: "incidentIds",
        select:
          "incidentType description location incidentTime severity status cause resolutionAction",
      });

    if (!summary) {
      return res.status(404).json({
        success: false,
        message: "Trip summary not found",
      });
    }

    // Get detailed pre-orders for this trip
    const startOfDay = new Date(summary.tripDate);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(summary.tripDate);
    endOfDay.setHours(23, 59, 59, 999);

    const preorders = await Preorder.find({
      orderDate: { $gte: startOfDay, $lte: endOfDay },
    })
      .populate("registeredCustomerID", "firstName lastName telephone")
      .select("orderStatus totalAmount paymentMethod deliveredAt");

    // Get detailed en-route orders
    const enrouteOrders = await EnrouteOrder.find({
      deliveryCoordinatorID: summary.coordinatorID._id,
      date: { $gte: startOfDay, $lte: endOfDay },
    })
      .populate("deliveryCoordinatorID", "firstName lastName")
      .select(
        "customerLocation contactNum status totalAmount paymentMethod products"
      );

    // Build comprehensive report
    const detailedReport = {
      tripSummary: summary,
      preorderDetails: preorders,
      enrouteOrderDetails: enrouteOrders,
      performanceMetrics: {
        deliverySuccessRate:
          summary.deliveryStats.totalPreorders > 0
            ? (
                (summary.deliveryStats.deliveredPreorders /
                  summary.deliveryStats.totalPreorders) *
                100
              ).toFixed(2) + "%"
            : "N/A",
        paymentCollectionRate:
          summary.paymentSummary.totalPreorderAmount > 0
            ? (
                (summary.paymentSummary.collectedPreorderAmount /
                  summary.paymentSummary.totalPreorderAmount) *
                100
              ).toFixed(2) + "%"
            : "N/A",
        averageDeliveryTime:
          summary.tripDurationMinutes &&
          summary.deliveryStats.totalPreorders > 0
            ? (
                summary.tripDurationMinutes /
                summary.deliveryStats.totalPreorders
              ).toFixed(2) + " minutes per delivery"
            : "N/A",
        incidentRate:
          summary.incidentCount > 0
            ? "Yes (" + summary.incidentCount + ")"
            : "No incidents",
      },
    };

    res.status(200).json({
      success: true,
      message: "Detailed trip report generated successfully",
      report: detailedReport,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error generating detailed report",
      error: error.message,
    });
  }
};

// Approve trip summary (Admin function)
const approveTripSummary = async (req, res) => {
  try {
    const { id } = req.params;
    const { approvedBy } = req.body;

    // Validation
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid trip summary ID format",
      });
    }

    if (!approvedBy) {
      return res.status(400).json({
        success: false,
        message: "Approver ID is required",
      });
    }

    const summary = await TripSummary.findById(id);
    if (!summary) {
      return res.status(404).json({
        success: false,
        message: "Trip summary not found",
      });
    }

    if (summary.isApproved) {
      return res.status(400).json({
        success: false,
        message: "Trip summary is already approved",
      });
    }

    const updatedSummary = await TripSummary.findByIdAndUpdate(
      id,
      {
        isApproved: true,
        approvedBy,
        approvedAt: new Date(),
      },
      { new: true }
    )
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .populate("approvedBy", "firstName lastName username");

    res.status(200).json({
      success: true,
      message: "Trip summary approved successfully",
      tripSummary: updatedSummary,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error approving trip summary",
      error: error.message,
    });
  }
};

const getTripStatus = async (truckID, date) => {
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);

  const summary = await TripSummary.findOne({
    truckID,
    tripDate: { $gte: startOfDay, $lte: endOfDay },
  }).select("tripStatus _id");

  return summary; // Returns null if not found, or { _id, tripStatus }
};

module.exports = {
  closeTripAndGenerateSummary,
  getTripSummaryByTruckAndDate,
  getTripSummariesByCoordinator,
  getAllTripSummaries,
  generateDetailedTripReport,
  approveTripSummary,
  getTripStatus,
};
