// Backend/Controller/TripReportPDFController.js
const PDFDocument = require("pdfkit");
const TripSummary = require("../Model/TripSummaryModel");
const Incident = require("../Model/IncidentModel");
const { Preorder } = require("../Model/PreorderModel");
const EnrouteOrder = require("../Model/EnrouteOrderModel");
const mongoose = require("mongoose");

const generateTripReportPDF = async (req, res) => {
  try {
    const { tripSummaryId } = req.params;

    // Validation
    if (!mongoose.Types.ObjectId.isValid(tripSummaryId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid trip summary ID format",
      });
    }

    // Fetch trip summary with all details
    const tripSummary = await TripSummary.findById(tripSummaryId)
      .populate("truckID", "truckNumber plateNo colour")
      .populate("coordinatorID", "firstName lastName username email telephone")
      .populate("driverID", "firstName lastName licenseNumber")
      .populate("routeID", "start end")
      .populate({
        path: "incidentIds",
        select:
          "incidentType description location incidentTime severity status durationInMinutes cause resolutionAction",
      });

    if (!tripSummary) {
      return res.status(404).json({
        success: false,
        message: "Trip summary not found",
      });
    }

    // Fetch detailed preorders and enroute orders for the trip date
    const startOfDay = new Date(tripSummary.tripDate);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(tripSummary.tripDate);
    endOfDay.setHours(23, 59, 59, 999);

    const [preorders, enrouteOrders] = await Promise.all([
      Preorder.find({
        orderDate: { $gte: startOfDay, $lte: endOfDay },
      })
        .populate("registeredCustomerID", "firstName lastName telephone")
        .select("orderStatus totalAmount paymentMethod deliveredAt"),
      EnrouteOrder.find({
        deliveryCoordinatorID: tripSummary.coordinatorID._id,
        date: { $gte: startOfDay, $lte: endOfDay },
      }).select("status totalAmount paymentMethod customerLocation"),
    ]);

    // Create PDF document
    const doc = new PDFDocument({
      size: "A4",
      margin: 40,
    });

    // Set response headers
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="trip-report-${tripSummaryId}.pdf"`
    );

    // Pipe to response
    doc.pipe(res);

    // ===== HEADER =====
    doc.fontSize(20).font("Helvetica-Bold").text("TRIP REPORT", {
      align: "center",
    });
    doc
      .fontSize(10)
      .font("Helvetica")
      .text("Seagills Lanka - Delivery Management System", {
        align: "center",
      });
    doc
      .moveTo(40, doc.y + 5)
      .lineTo(555, doc.y + 5)
      .stroke();
    doc.moveDown(0.5);

    // ===== TRIP DETAILS SECTION =====
    doc.fontSize(12).font("Helvetica-Bold").text("Trip Details", {
      underline: true,
    });
    doc.fontSize(10).font("Helvetica");

    const tripDate = new Date(tripSummary.tripDate).toLocaleDateString(
      "en-US",
      {
        year: "numeric",
        month: "long",
        day: "numeric",
      }
    );

    const detailsData = [
      ["Date:", tripDate],
      ["Truck ID:", tripSummary.truckID.plateNo],
      ["Truck Number:", tripSummary.truckID.truckNumber],
      [
        "Coordinator:",
        `${tripSummary.coordinatorID.firstName} ${tripSummary.coordinatorID.lastName}`,
      ],
      [
        "Driver:",
        `${tripSummary.driverID.firstName} ${tripSummary.driverID.lastName}`,
      ],
      [
        "Route:",
        `${tripSummary.routeID?.start?.name || "N/A"} to ${
          tripSummary.routeID?.end?.name || "N/A"
        }`,
      ],
      [
        "Trip Start Time:",
        tripSummary.tripStartTime
          ? new Date(tripSummary.tripStartTime).toLocaleTimeString()
          : "N/A",
      ],
      [
        "Trip End Time:",
        tripSummary.tripEndTime
          ? new Date(tripSummary.tripEndTime).toLocaleTimeString()
          : "N/A",
      ],
      [
        "Duration:",
        tripSummary.tripDurationMinutes
          ? `${tripSummary.tripDurationMinutes} minutes`
          : "N/A",
      ],
      ["Trip Status:", tripSummary.tripStatus.toUpperCase()],
    ];

    detailsData.forEach(([label, value]) => {
      doc.text(`${label} ${value}`, { width: 500 });
    });

    doc.moveDown();

    // ===== PREORDERS SECTION =====
    doc.fontSize(12).font("Helvetica-Bold").text("Pre-Orders Summary", {
      underline: true,
    });
    doc.fontSize(10).font("Helvetica");

    const preorderStats = tripSummary.deliveryStats;
    doc.text(
      `Total Pre-Orders: ${preorderStats.totalPreorders} | Delivered: ${preorderStats.deliveredPreorders} | Failed: ${preorderStats.failedPreorders} | Pending: ${preorderStats.pendingPreorders}`
    );
    doc.text(
      `Total Amount: LKR ${
        preorderStats.totalPreorderAmount || 0
      } | Collected: LKR ${preorderStats.collectedPreorderAmount || 0}`
    );
    doc.moveDown();

    // Preorders table
    if (preorders.length > 0) {
      doc
        .fontSize(9)
        .text("Pre-Order Details:", { underline: true, width: 500 });
      let tableTop = doc.y + 10;

      // Table headers
      doc
        .fontSize(9)
        .font("Helvetica-Bold")
        .text("Order Status", 40, tableTop)
        .text("Amount (LKR)", 150, tableTop)
        .text("Payment Method", 250, tableTop)
        .text("Delivered At", 380, tableTop);

      tableTop += 20;

      // Table rows
      doc.font("Helvetica").fontSize(8);
      preorders.forEach((order) => {
        const deliveredAt = order.deliveredAt
          ? new Date(order.deliveredAt).toLocaleDateString()
          : "N/A";

        doc
          .text(order.orderStatus || "N/A", 40, tableTop)
          .text(order.totalAmount || 0, 150, tableTop)
          .text(order.paymentMethod || "N/A", 250, tableTop)
          .text(deliveredAt, 380, tableTop);

        tableTop += 15;
      });

      doc.moveDown();
    }

    // ===== EN-ROUTE ORDERS SECTION =====
    doc.fontSize(12).font("Helvetica-Bold").text("En-Route Orders Summary", {
      underline: true,
    });
    doc.fontSize(10).font("Helvetica");

    const enrouteStats = tripSummary.deliveryStats;
    doc.text(
      `Total En-Route Orders: ${enrouteStats.totalEnrouteOrders} | Delivered: ${enrouteStats.deliveredEnrouteOrders} | Pending: ${enrouteStats.pendingEnrouteOrders}`
    );
    doc.text(
      `Total Amount: LKR ${
        enrouteStats.totalEnrouteAmount || 0
      } | Collected: LKR ${enrouteStats.collectedEnrouteAmount || 0}`
    );
    doc.moveDown();

    // En-route orders table
    if (enrouteOrders.length > 0) {
      doc
        .fontSize(9)
        .text("En-Route Order Details:", { underline: true, width: 500 });
      let tableTop = doc.y + 10;

      // Table headers
      doc
        .fontSize(9)
        .font("Helvetica-Bold")
        .text("Status", 40, tableTop)
        .text("Amount (LKR)", 100, tableTop)
        .text("Payment", 180, tableTop)
        .text("Location", 260, tableTop);

      tableTop += 20;

      // Table rows
      doc.font("Helvetica").fontSize(8);
      enrouteOrders.forEach((order) => {
        doc
          .text(order.status || "N/A", 40, tableTop)
          .text(order.totalAmount || 0, 100, tableTop)
          .text(order.paymentMethod || "N/A", 180, tableTop)
          .text(order.customerLocation || "N/A", 260, tableTop, { width: 250 });

        tableTop += 15;
      });

      doc.moveDown();
    }

    // ===== PAYMENT SUMMARY SECTION =====
    doc.fontSize(12).font("Helvetica-Bold").text("Payment Summary", {
      underline: true,
    });
    doc.fontSize(10).font("Helvetica");

    const paymentSummary = tripSummary.paymentSummary;
    doc.text(`Cash Collected: LKR ${paymentSummary.cashCollected || 0}`);
    doc.text(`Card Collected: LKR ${paymentSummary.cardCollected || 0}`);
    doc.text(`Total Collected: LKR ${paymentSummary.totalCollected || 0}`, {
      underline: true,
    });
    doc.moveDown();

    // ===== INCIDENTS SECTION =====
    doc.fontSize(12).font("Helvetica-Bold").text("Incidents", {
      underline: true,
    });
    doc.fontSize(10).font("Helvetica");

    if (tripSummary.incidentIds && tripSummary.incidentIds.length > 0) {
      doc.text(`Total Incidents: ${tripSummary.incidentCount}`);
      doc.moveDown(0.5);

      tripSummary.incidentIds.forEach((incident, index) => {
        doc
          .fontSize(9)
          .font("Helvetica-Bold")
          .text(`Incident ${index + 1}:`, {
            underline: true,
          });
        doc.fontSize(9).font("Helvetica");
        doc.text(`Type: ${incident.incidentType}`);
        doc.text(`Severity: ${incident.severity.toUpperCase()}`);
        doc.text(
          `Time: ${new Date(incident.incidentTime).toLocaleTimeString()}`
        );
        doc.text(`Location: ${incident.location}`);
        doc.text(`Description: ${incident.description}`);
        doc.text(`Status: ${incident.status}`);
        if (incident.durationInMinutes) {
          doc.text(`Duration: ${incident.durationInMinutes} minutes`);
        }
        if (incident.cause) {
          doc.text(`Cause: ${incident.cause}`);
        }
        if (incident.resolutionAction) {
          doc.text(`Resolution: ${incident.resolutionAction}`);
        }
        doc.moveDown(0.5);
      });
    } else {
      doc.text("No incidents recorded.", { italics: true });
    }

    doc.moveDown();

    // ===== COORDINATOR NOTES SECTION =====
    if (tripSummary.coordinatorNotes) {
      doc.fontSize(12).font("Helvetica-Bold").text("Coordinator Notes", {
        underline: true,
      });
      doc.fontSize(10).font("Helvetica").text(tripSummary.coordinatorNotes, {
        width: 500,
      });
      doc.moveDown();
    }

    // ===== FOOTER =====
    doc.moveTo(40, doc.y).lineTo(555, doc.y).stroke();
    doc
      .fontSize(8)
      .font("Helvetica")
      .text(
        `Report generated on ${new Date().toLocaleString()} | Trip Summary ID: ${tripSummaryId}`,
        { align: "center" }
      );

    // Finalize PDF
    doc.end();
  } catch (error) {
    console.error("Error generating PDF:", error);
    res.status(500).json({
      success: false,
      message: "Error generating trip report PDF",
      error: error.message,
    });
  }
};

module.exports = {
  generateTripReportPDF,
};
