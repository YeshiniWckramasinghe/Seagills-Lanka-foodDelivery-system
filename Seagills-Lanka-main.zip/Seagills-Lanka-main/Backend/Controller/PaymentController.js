// Backend/Controller/PaymentController.js
const { Preorder } = require("../Model/PreorderModel");
const EnrouteOrder = require("../Model/EnrouteOrderModel");
const { DeliveryCoordinator } = require("../Model/UserModel");
const mongoose = require("mongoose");

// Update payment for a pre-order or en-route order
const updateOrderPayment = async (req, res) => {
  try {
    const { id } = req.params;
    const { paymentStatus, paymentMethod, transactionRef, coordinatorID } =
      req.body;

    // Validation: Check required fields
    if (!paymentStatus || !coordinatorID) {
      return res.status(400).json({
        success: false,
        message: "Payment status and coordinator ID are required",
      });
    }

    // Validation: Check if coordinator is valid and exists
    const coordinator = await DeliveryCoordinator.findById(coordinatorID);
    if (!coordinator) {
      return res.status(404).json({
        success: false,
        message: "Delivery Coordinator not found",
      });
    }

    // Validation: Check if order ID is valid
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid order ID format",
      });
    }

    // Validation: Check for valid payment status
    const validStatuses = ["Pending", "Completed", "Failed"];
    if (!validStatuses.includes(paymentStatus)) {
      return res.status(400).json({
        success: false,
        message: `Invalid payment status. Valid options: ${validStatuses.join(
          ", "
        )}`,
      });
    }

    // Find and update the order
    let order = await Preorder.findById(id);

    if (!order) {
      order = await EnrouteOrder.findById(id);
    }

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    // Validation: Check for valid payment method if provided
    const validMethods = ["cash", "card"];
    if (paymentMethod && !validMethods.includes(paymentMethod)) {
      return res.status(400).json({
        success: false,
        message: `Invalid payment method. Valid options: ${validMethods.join(
          ", "
        )}`,
      });
    }

    // Update the order fields
    order.paymentStatus = paymentStatus;
    order.lastUpdated = new Date();

    if (paymentStatus === "Completed") {
      // Handle both Preorder (has orderStatus) and EnrouteOrder (has status)
      if (order.orderStatus !== undefined) {
        order.orderStatus = "delivered";
      } else if (order.status !== undefined) {
        order.status = "Completed";
      }
    }

    if (paymentMethod) {
      order.paymentMethod = paymentMethod;
    }

    const updatedOrder = await order.save();

    res.status(200).json({
      success: true,
      message: `Order payment status updated to ${paymentStatus}`,
      order: updatedOrder,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error updating order payment",
      error: error.message,
    });
  }
};

module.exports = {
  updateOrderPayment,
};
