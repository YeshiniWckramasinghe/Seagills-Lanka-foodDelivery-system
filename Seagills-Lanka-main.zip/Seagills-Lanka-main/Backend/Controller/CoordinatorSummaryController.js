// Backend/Controller/CoordinatorSummaryController.js
const { Preorder } = require("../Model/PreorderModel");
const EnrouteOrder = require("../Model/EnrouteOrderModel");
const AssignedTruck = require("../Model/AssignedTruckModel");
const mongoose = require("mongoose");

// Get today's summary for a coordinator
const getCoordinatorDailySummary = async (req, res) => {
  try {
    const { coordinatorId } = req.params;
    const { date } = req.query;

    // Validation
    if (!mongoose.Types.ObjectId.isValid(coordinatorId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid coordinator ID format",
      });
    }

    // Use provided date or today's date
    const targetDate = date ? new Date(date) : new Date();
    const startOfDay = new Date(targetDate);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(targetDate);
    endOfDay.setHours(23, 59, 59, 999);

    // Find truck assignment for this coordinator on the target date
    const assignment = await AssignedTruck.findOne({
      deliveryCoordinatorID: coordinatorId,
      date: { $gte: startOfDay, $lte: endOfDay },
    });

    let preorderCompleted = 0;
    let preorderTotal = 0;
    let enrouteCompleted = 0;

    if (assignment) {
      // Get preorders assigned to this coordinator's truck for delivery today
      const preorders = await Preorder.find({
        deliveryDate: { $gte: startOfDay, $lte: endOfDay },
        "assignedTruck.truckID": assignment.truckID,
      });

      preorderTotal = preorders.length;

      // Count completed preorders (delivered status and payment completed)
      preorderCompleted = preorders.filter(
        (order) =>
          order.orderStatus === "delivered" &&
          order.paymentStatus === "Completed"
      ).length;
    }

    // Get en-route orders for this coordinator today
    const enrouteOrders = await EnrouteOrder.find({
      deliveryCoordinatorID: coordinatorId,
      date: { $gte: startOfDay, $lte: endOfDay },
    });

    // Count completed en-route orders (delivered status and payment completed)
    enrouteCompleted = enrouteOrders.filter(
      (order) =>
        order.status === "Completed" && order.paymentStatus === "Completed"
    ).length;

    res.status(200).json({
      success: true,
      message: "Daily summary retrieved successfully",
      summary: {
        preorder: {
          completed: preorderCompleted,
          total: preorderTotal,
          pending: preorderTotal - preorderCompleted,
        },
        enroute: {
          completed: enrouteCompleted,
        },
        date: targetDate.toISOString().split("T")[0],
      },
    });
  } catch (error) {
    console.error("Error getting coordinator daily summary:", error);
    res.status(500).json({
      success: false,
      message: "Error retrieving daily summary",
      error: error.message,
    });
  }
};

module.exports = {
  getCoordinatorDailySummary,
};
