const { Preorder, PreorderProduct } = require("../Model/PreorderModel");
const DailyLoading = require("../Model/DailyLoadingModel");
const { RegisteredCustomer } = require("../Model/UserModel");
const Product = require("../Model/ProductModel");
const Payment = require("../Model/PaymentModel");
const geocodeAddress = require("../Utils/geocode");
const findNearestBranch = require("../Utils/findNearestBranch");
const mongoose = require("mongoose");

// SHARED UTILITY FUNCTION
async function enrichPreorder(preorder) {
  const preorderProducts = await PreorderProduct.find({
    preorderID: preorder._id,
  }).populate("productID", "productName category price productDescription");
  const payment = await Payment.findOne({ preorderID: preorder._id });

  return {
    ...preorder.toObject(),
    products: preorderProducts,
    payment: payment || null,
    productCount: preorderProducts.length,
    totalItems: preorderProducts.reduce(
      (sum, item) => sum + (item.quantity || 0),
      0
    ),
  };
}

// ---------------- GET PREORDERS BY TRUCK ----------------
const getPreordersByTruck = async (req, res) => {
  try {
    const { truckId } = req.params;
    const { date } = req.query;

    if (!mongoose.Types.ObjectId.isValid(truckId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid truck ID format",
      });
    }

    if (!date) {
      return res.status(400).json({
        success: false,
        message:
          "Delivery date is required to find assigned pre-orders for a truck.",
      });
    }

    // 1. Define the date range for the delivery date
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    // 2. Find Preorders assigned to this truck for the specified delivery date
    const assignedPreorders = await Preorder.find({
      deliveryDate: { $gte: startOfDay, $lte: endOfDay },
      "assignedTruck.truckID": truckId,
      orderStatus: {
        $in: ["assigned", "out_for_delivery", "pending", "verified"],
      },
    })
      .populate("registeredCustomerID", "firstName lastName email telephone")
      .populate("branchID", "branchName location address")
      .sort({ orderDate: 1 });

    // 3. Enrich each preorder with its products
    const enrichedPreorders = await Promise.all(
      assignedPreorders.map(async (preorder) => {
        // Fetch all products for this preorder
        const preorderProducts = await PreorderProduct.find({
          preorderID: preorder._id,
        }).populate("productID", "productName price category");

        // Convert to plain object and add products
        const preorderObj = preorder.toObject();
        preorderObj.preorderProducts = preorderProducts.map((pp) => ({
          productID: pp.productID._id,
          productName: pp.productID.productName,
          quantity: pp.quantity,
          unit: pp.unit,
        }));

        return preorderObj;
      })
    );

    // 4. Return success response (even if empty)
    res.status(200).json({
      success: true,
      message:
        enrichedPreorders.length > 0
          ? "Assigned pre-orders retrieved successfully"
          : "No pre-orders assigned to this truck for the specified date",
      truckId,
      date: date || "all dates",
      count: preordersWithProducts.length,
      preorders: preordersWithProducts,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving pre-orders for truck manifest",
      error: error.message,
    });
  }
};

// ---------------- VERIFY PREORDER ----------------
const verifyPreorder = async (req, res) => {
  try {
    const { id } = req.params;
    const { verificationStatus, coordinatorNotes, verifiedBy } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid preorder ID format" });
    }

    if (!verificationStatus || !verifiedBy) {
      return res
        .status(400)
        .json({ message: "Verification status and verifiedBy are required" });
    }

    const preorder = await Preorder.findById(id);
    if (!preorder)
      return res.status(404).json({ message: "Pre-order not found" });

    const updatedPreorder = await Preorder.findByIdAndUpdate(
      id,
      {
        orderStatus: verificationStatus,
        coordinatorNotes,
        verifiedBy,
        verifiedAt: new Date(),
      },
      { new: true, runValidators: true }
    )
      .populate("registeredCustomerID", "firstName lastName")
      .populate("branchID", "branchName");

    res.status(200).json({
      success: true,
      message: "Pre-order verification updated successfully",
      preorder: updatedPreorder,
    });
  } catch (error) {
    res
      .status(500)
      .json({
        success: false,
        message: "Error verifying pre-order",
        error: error.message,
      });
  }
};

// ---------------- UPDATE DELIVERY STATUS ----------------
const updateDeliveryStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      deliveryStatus,
      deliveredAt,
      deliveryNotes,
      customerSignature,
      coordinatorID,
    } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid preorder ID format" });
    }

    if (!deliveryStatus || !coordinatorID) {
      return res
        .status(400)
        .json({ message: "Delivery status and coordinator ID are required" });
    }

    const validStatuses = [
      "pending",
      "out_for_delivery",
      "delivered",
      "failed",
      "returned",
    ];
    if (!validStatuses.includes(deliveryStatus)) {
      return res.status(400).json({
        message: `Invalid delivery status. Valid options: ${validStatuses.join(
          ", "
        )}`,
      });
    }

    const preorder = await Preorder.findById(id);
    if (!preorder)
      return res.status(404).json({ message: "Pre-order not found" });

    const updateData = {
      orderStatus: deliveryStatus,
      deliveryNotes,
      updatedBy: coordinatorID,
      lastUpdated: new Date(),
    };

    if (deliveryStatus === "delivered") {
      updateData.deliveredAt = deliveredAt || new Date();
      if (customerSignature) updateData.customerSignature = customerSignature;
    }

    const updatedPreorder = await Preorder.findByIdAndUpdate(id, updateData, {
      new: true,
      runValidators: true,
    })
      .populate("registeredCustomerID", "firstName lastName telephone")
      .populate("branchID", "branchName");

    res
      .status(200)
      .json({
        message: `Delivery status updated to ${deliveryStatus}`,
        preorder: updatedPreorder,
      });
  } catch (error) {
    res
      .status(500)
      .json({
        message: "Error updating delivery status",
        error: error.message,
      });
  }
};

// ---------------- GET SINGLE PREORDER ----------------
const getPreorderById = async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid preorder ID format" });
    }

    const preorder = await Preorder.findById(id)
      .populate("registeredCustomerID", "firstName lastName email telephone")
      .populate("branchID", "branchName location address");

    if (!preorder)
      return res.status(404).json({ message: "Pre-order not found" });

    const enriched = await enrichPreorder(preorder);
    res
      .status(200)
      .json({
        message: "Pre-order retrieved successfully",
        preorder: enriched,
      });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error retrieving pre-order", error: error.message });
  }
};

// ---------------- GET PREORDERS BY CUSTOMER ----------------
const getPreordersByCustomer = async (req, res) => {
  try {
    const { customerId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(customerId)) {
      return res.status(400).json({ message: "Invalid customer ID format" });
    }

    const preorders = await Preorder.find({ registeredCustomerID: customerId })
      .populate("branchID", "branchName location")
      .populate("registeredCustomerID", "firstName lastName email")
      .sort({ orderDate: -1 });

    const enrichedList = await Promise.all(
      preorders.map((preorder) => enrichPreorder(preorder))
    );
    res.status(200).json({ preorders: enrichedList });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error getting preorders", error: error.message });
  }
};

// ---------------- GET ALL PREORDERS ----------------
const getAllPreorders = async (req, res) => {
  try {
    const { status, date, branchId } = req.query;
    const filter = {};

    if (status) filter.orderStatus = status;
    if (branchId) filter.branchID = branchId;
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      filter.orderDate = { $gte: startOfDay, $lte: endOfDay };
    }

    const preorders = await Preorder.find(filter)
      .populate("registeredCustomerID", "firstName lastName email telephone")
      .populate("branchID", "branchName location")
      .sort({ orderDate: -1 });

    const enrichedList = await Promise.all(
      preorders.map((preorder) => enrichPreorder(preorder))
    );

    res.status(200).json({
      success: true,
      message: "Pre-orders retrieved successfully",
      count: enrichedList.length,
      filters: { status, date, branchId },
      preorders: enrichedList,
    });
  } catch (error) {
    res
      .status(500)
      .json({
        success: false,
        message: "Error retrieving pre-orders",
        error: error.message,
      });
  }
};

// ---------------- CREATE NEW PREORDER ----------------
const createPreorder = async (req, res) => {
  try {
    const { registeredCustomerID, address, products, orderDate, deliveryDate } =
      req.body;

    if (!registeredCustomerID || !products?.length) {
      return res
        .status(400)
        .json({ message: "Customer ID and products are required" });
    }
    if (!address || address.trim() === "") {
      return res.status(400).json({ message: "Delivery address is required" });
    }
    if (!deliveryDate) {
      return res.status(400).json({ message: "Delivery date is required" });
    }

    const customer = await RegisteredCustomer.findById(registeredCustomerID);
    if (!customer)
      return res.status(404).json({ message: "Registered customer not found" });

    // --- FIND NEAREST BRANCH ---
    let branchID;
    try {
      branchID = await findNearestBranch(address); // internally calls geocodeAddress
    } catch (err) {
      return res.status(400).json({ message: err.message });
    }

    let totalAmount = 0;
    const validatedProducts = [];

    for (const item of products) {
      const product = await Product.findById(item.productID);
      if (!product)
        return res
          .status(404)
          .json({ message: `Product not found: ${item.productID}` });
      if (item.quantity <= 0)
        return res
          .status(400)
          .json({ message: "Product quantities must be greater than 0" });

      totalAmount += product.price * item.quantity;
      validatedProducts.push({
        productID: item.productID,
        quantity: item.quantity,
        unit: product.unit,
        unitPrice: product.price,
      });
    }

    const newPreorder = new Preorder({
      registeredCustomerID,
      branchID, // assign nearest branch
      address,
      orderDate: orderDate || new Date(),
      deliveryDate: new Date(deliveryDate),
      orderStatus: "pending",
      totalAmount,
    });

    const savedPreorder = await newPreorder.save();

    const preorderProducts = validatedProducts.map((item) => ({
      preorderID: savedPreorder._id,
      productID: item.productID,
      quantity: item.quantity,
      unit: item.unit,
    }));

    await PreorderProduct.insertMany(preorderProducts);

    const populatedPreorder = await Preorder.findById(savedPreorder._id)
      .populate("registeredCustomerID", "firstName lastName email")
      .populate("branchID", "branchName");

    res.status(201).json({
      message: "Pre-order created successfully",
      preorder: populatedPreorder,
      productCount: preorderProducts.length,
      totalAmount,
    });
  } catch (error) {
    if (error.code === 11000)
      return res
        .status(400)
        .json({ success: false, message: "Duplicate product in preorder" });

    res
      .status(500)
      .json({
        success: false,
        message: "Error creating pre-order",
        error: error.message,
      });
  }
};

// ---------------- EDIT PREORDER (ONLY deliveryDate + products) ----------------
const editPreorder = async (req, res) => {
  try {
    const { id } = req.params;
    const { deliveryDate, products } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid preorder ID format" });
    }

    const updateData = {};
    if (deliveryDate) updateData.deliveryDate = new Date(deliveryDate);

    if (Object.keys(updateData).length > 0) {
      await Preorder.findByIdAndUpdate(id, updateData, { new: true });
    }

    if (products && products.length > 0) {
      for (const prod of products) {
        await PreorderProduct.findOneAndUpdate(
          { preorderID: id, productID: prod.productID },
          { quantity: prod.quantity },
          { new: true }
        );
      }
    }

    const updatedProducts = await PreorderProduct.find({
      preorderID: id,
    }).populate("productID", "price");
    let totalAmount = 0,
      totalItems = 0;
    updatedProducts.forEach((prod) => {
      const price = prod.productID.price || 0;
      totalAmount += price * prod.quantity;
      totalItems += prod.quantity;
    });

    await Preorder.findByIdAndUpdate(id, { totalAmount }, { new: true });

    res
      .status(200)
      .json({
        message: "Preorder updated successfully",
        totalAmount,
        totalItems,
      });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error updating preorder", error: error.message });
  }
};

// ---------------- DELETE PREORDER ----------------
const deletePreorder = async (req, res) => {
  try {
    const { id } = req.params;
    await Preorder.findByIdAndDelete(id);
    await PreorderProduct.deleteMany({ preorderID: id });
    res.status(200).json({ message: "Preorder deleted" });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error deleting preorder", error: error.message });
  }
};

// ---------------- EXPORT ----------------
module.exports = {
  getPreordersByTruck,
  verifyPreorder,
  updateDeliveryStatus,
  getAllPreorders,
  getPreorderById,
  createPreorder,
  getPreordersByCustomer,
  editPreorder,
  deletePreorder,
};
