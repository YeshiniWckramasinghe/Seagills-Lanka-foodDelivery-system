// Backend/Controller/IncidentController.js
const Incident = require("../Model/IncidentModel");
const { DeliveryCoordinator } = require("../Model/UserModel");
const Truck = require("../Model/TruckModel");
const mongoose = require("mongoose");

// Create/Record a new incident
const recordIncident = async (req, res) => {
  try {
    const {
      truckID,
      coordinatorID,
      incidentType,
      description,
      location,
      incidentTime,
      durationInMinutes,
      cause,
      severity,
      tripDate,
    } = req.body;

    // Validation: Check required fields
    if (
      !truckID ||
      !coordinatorID ||
      !incidentType ||
      !description ||
      !location ||
      !incidentTime ||
      !tripDate
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Truck ID, coordinator ID, incident type, description, location, incident time, and trip date are required",
      });
    }

    // Validation: Check if truck exists
    const truck = await Truck.findById(truckID);
    if (!truck) {
      return res.status(404).json({
        success: false,
        message: "Truck not found",
      });
    }

    // Validation: Check if coordinator exists
    const coordinator = await DeliveryCoordinator.findById(coordinatorID);
    if (!coordinator) {
      return res.status(404).json({
        success: false,
        message: "Delivery coordinator not found",
      });
    }

    // Validation: Check valid incident type
    const validIncidentTypes = ["breakdown", "delay", "accident", "other"];
    if (!validIncidentTypes.includes(incidentType)) {
      return res.status(400).json({
        success: false,
        message: `Invalid incident type. Valid options: ${validIncidentTypes.join(
          ", "
        )}`,
      });
    }

    // Create new incident
    const newIncident = new Incident({
      truckID,
      coordinatorID,
      incidentType,
      description: description.trim(),
      location: location.trim(),
      incidentTime: new Date(incidentTime),
      durationInMinutes: durationInMinutes || null,
      cause: cause ? cause.trim() : null,
      severity: severity || "medium",
      tripDate: new Date(tripDate),
      status: "reported",
    });

    const savedIncident = await newIncident.save();

    // Populate for response
    await savedIncident.populate([
      { path: "truckID", select: "plateNo colour" },
      { path: "coordinatorID", select: "firstName lastName username" },
    ]);

    res.status(201).json({
      success: true,
      message: "Incident recorded successfully",
      incident: savedIncident,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error recording incident",
      error: error.message,
    });
  }
};

// Get all incidents for a specific truck and date
const getIncidentsByTruckAndDate = async (req, res) => {
  try {
    const { truckId } = req.params;
    const { date } = req.query;

    // Validation: Check if truck ID is valid
    if (!mongoose.Types.ObjectId.isValid(truckId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid truck ID format",
      });
    }

    // Validation: Check if date is provided
    if (!date) {
      return res.status(400).json({
        success: false,
        message: "Date is required",
      });
    }

    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const incidents = await Incident.find({
      truckID: truckId,
      tripDate: { $gte: startOfDay, $lte: endOfDay },
    })
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .sort({ incidentTime: 1 });

    res.status(200).json({
      success: true,
      message: "Incidents retrieved successfully",
      truckId,
      date,
      count: incidents.length,
      incidents,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving incidents",
      error: error.message,
    });
  }
};

// Get incidents by coordinator
const getIncidentsByCoordinator = async (req, res) => {
  try {
    const { coordinatorId } = req.params;
    const { date, status } = req.query;

    // Validation: Check if coordinator ID is valid
    if (!mongoose.Types.ObjectId.isValid(coordinatorId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid coordinator ID format",
      });
    }

    const filter = { coordinatorID: coordinatorId };

    // Add date filter if provided
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      filter.tripDate = { $gte: startOfDay, $lte: endOfDay };
    }

    // Add status filter if provided
    if (status) {
      filter.status = status;
    }

    const incidents = await Incident.find(filter)
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .sort({ incidentTime: -1 });

    res.status(200).json({
      success: true,
      message: "Coordinator incidents retrieved successfully",
      coordinatorId,
      count: incidents.length,
      incidents,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving coordinator incidents",
      error: error.message,
    });
  }
};

// Update incident status or resolution
const updateIncident = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, resolutionAction, resolvedAt, adminNotes } = req.body;

    // Validation: Check if ID is valid
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid incident ID format",
      });
    }

    const incident = await Incident.findById(id);
    if (!incident) {
      return res.status(404).json({
        success: false,
        message: "Incident not found",
      });
    }

    // Update fields
    const updateData = {};

    if (status) {
      const validStatuses = ["reported", "in-progress", "resolved"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({
          success: false,
          message: `Invalid status. Valid options: ${validStatuses.join(", ")}`,
        });
      }
      updateData.status = status;
    }

    if (resolutionAction) updateData.resolutionAction = resolutionAction.trim();
    if (resolvedAt) updateData.resolvedAt = new Date(resolvedAt);
    if (adminNotes) updateData.adminNotes = adminNotes.trim();

    const updatedIncident = await Incident.findByIdAndUpdate(id, updateData, {
      new: true,
      runValidators: true,
    })
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username");

    res.status(200).json({
      success: true,
      message: "Incident updated successfully",
      incident: updatedIncident,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error updating incident",
      error: error.message,
    });
  }
};

// Get single incident by ID
const getIncidentById = async (req, res) => {
  try {
    const { id } = req.params;

    // Validation: Check if ID is valid
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid incident ID format",
      });
    }

    const incident = await Incident.findById(id)
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username email telephone");

    if (!incident) {
      return res.status(404).json({
        success: false,
        message: "Incident not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Incident retrieved successfully",
      incident,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving incident",
      error: error.message,
    });
  }
};

// Get all incidents with optional filters
const getAllIncidents = async (req, res) => {
  try {
    const { status, severity, incidentType, date } = req.query;

    const filter = {};
    if (status) filter.status = status;
    if (severity) filter.severity = severity;
    if (incidentType) filter.incidentType = incidentType;

    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      filter.tripDate = { $gte: startOfDay, $lte: endOfDay };
    }

    const incidents = await Incident.find(filter)
      .populate("truckID", "plateNo colour")
      .populate("coordinatorID", "firstName lastName username")
      .sort({ incidentTime: -1 });

    res.status(200).json({
      success: true,
      message: "All incidents retrieved successfully",
      count: incidents.length,
      filters: { status, severity, incidentType, date },
      incidents,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving incidents",
      error: error.message,
    });
  }
};

module.exports = {
  recordIncident,
  getIncidentsByTruckAndDate,
  getIncidentsByCoordinator,
  updateIncident,
  getIncidentById,
  getAllIncidents,
};
