const mongoose = require("mongoose");
const AssignedTruck = require("../Model/AssignedTruckModel");
const Truck = require("../Model/TruckModel");
const {
  User,
  TruckDriver,
  DeliveryCoordinator,
} = require("../Model/UserModel");

// ----------------------
// Assign a truck to a driver
// ----------------------
const assignTruck = async (req, res) => {
  try {
    const { truckID, driverID, deliveryCoordinatorID, date } = req.body;

    const truck = await Truck.findById(truckID);
    if (!truck) return res.status(404).json({ message: "Truck not found" });

    const driver = await User.findById(driverID);
    if (!driver) return res.status(404).json({ message: "Driver not found" });

    const assignment = new AssignedTruck({
      truckID,
      driverID,
      deliveryCoordinatorID,
      date,
    });
    await assignment.save();

    truck.status = "assigned";
    await truck.save();

    driver.assignedTruck = truckID;
    await driver.save();

    // Populate before returning
    const populatedAssignment = await AssignedTruck.findById(assignment._id)
      .populate("truckID")
      .populate(
        "driverID",
        "firstName lastName email telephone licenseNumber assignedTruck"
      )
      .populate("deliveryCoordinatorID");

    res.status(201).json({
      success: true,
      message: "Truck assigned successfully",
      assignment: populatedAssignment,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ----------------------
// Delete assignment
// ----------------------
const deleteAssignment = async (req, res) => {
  try {
    const { id } = req.params;

    const assignment = await AssignedTruck.findByIdAndDelete(id);
    if (!assignment)
      return res.status(404).json({ message: "Assignment not found" });

    const truck = await Truck.findById(assignment.truckID);
    if (truck) {
      truck.status = "idle";
      await truck.save();
    }

    const driver = await User.findById(assignment.driverID);
    if (driver) {
      driver.assignedTruck = null;
      await driver.save();
    }

    res.status(200).json({
      success: true,
      message: "Assignment deleted, truck and driver reset",
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getCoordinatorDailySchedule = async (req, res) => {
  try {
    const { coordinatorId, date } = req.params;

    const checkDate = new Date(date);
    const startOfDay = new Date(checkDate);
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date(checkDate);
    endOfDay.setHours(23, 59, 59, 999);

    const assignment = await AssignedTruck.findOne({
      deliveryCoordinatorID: coordinatorId,
      date: { $gte: startOfDay, $lte: endOfDay },
    })
      .select("truckID driverID")
      .populate("driverID", "firstName lastName email telephone licenseNumber");

    if (!assignment) {
      return res.status(200).json({
        success: true,
        message: "No assignment found for today.",
        schedule: null,
      });
    }

    const schedule =
      await require("./TruckRouteController").getScheduleByTruckAndDate({
        truckID: assignment.truckID,
        date: date,
      });

    if (!schedule) {
      return res.status(200).json({
        success: true,
        message: "Truck assigned but no schedule set for today.",
        schedule: {
          truckID: assignment.truckID,
          driverID: assignment.driverID,
        },
      });
    }

    // 4. Return the combined data INCLUDING tripStartedAt and tripStatus
    res.status(200).json({
      success: true,
      message: "Daily schedule retrieved successfully.",
      schedule: {
        truck: schedule.truckID.plateNo,
        driver: assignment.driverID
          ? `${assignment.driverID.firstName} ${assignment.driverID.lastName}`.trim()
          : "N/A",
        route: `${schedule.routeID.start.name} to ${schedule.routeID.end.name}`,
        startTime: schedule.startTime,
        endTime: schedule.endTime,
        truckId: assignment.truckID._id,
        tripStartedAt: schedule.tripStartedAt || null,
        tripStatus: schedule.tripStatus || "scheduled",
      },
    });
  } catch (error) {
    console.error("Error retrieving coordinator daily schedule:", error);
    res.status(500).json({
      success: false,
      message: "Error retrieving coordinator daily schedule.",
      error: error.message,
    });
  }
};

// ----------------------
// Get assigned truck for driver (today)
// ----------------------
const getDriverTruck = async (req, res) => {
  try {
    const driverID = req.params.driverID;

    const today = new Date();
    const startOfDay = new Date(today.setHours(0, 0, 0, 0));
    const endOfDay = new Date(today.setHours(23, 59, 59, 999));

    const assignment = await AssignedTruck.findOne({
      driverID,
      date: { $gte: startOfDay, $lte: endOfDay },
    })
      .populate("truckID")
      .populate(
        "driverID",
        "firstName lastName email telephone licenseNumber assignedTruck"
      )
      .populate("deliveryCoordinatorID");

    if (!assignment || !assignment.driverID) {
      return res
        .status(404)
        .json({ success: false, message: "No assigned truck today" });
    }

    res.status(200).json({
      success: true,
      truck: assignment.truckID,
      driver: assignment.driverID,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ----------------------
// Get all trucks
// ----------------------
const getAllTrucks = async (req, res) => {
  try {
    const trucks = await Truck.find();
    res.status(200).json({ success: true, trucks });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ----------------------
// Get all assignments
// ----------------------
const getAllAssignments = async (req, res) => {
  try {
    const assignments = await AssignedTruck.find()
      .populate("truckID")
      .populate(
        "driverID",
        "firstName lastName email telephone licenseNumber assignedTruck"
      )
      .populate("deliveryCoordinatorID");

    res.status(200).json({ success: true, assignments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ----------------------
// Get assignments by coordinator
// ----------------------
const getAssignmentsByCoordinator = async (req, res) => {
  try {
    const { coordinatorId } = req.params;
    const assignments = await AssignedTruck.find({
      deliveryCoordinatorID: coordinatorId,
    })
      .populate("truckID")
      .populate(
        "driverID",
        "firstName lastName email telephone licenseNumber assignedTruck"
      )
      .populate("deliveryCoordinatorID");

    res.status(200).json({ success: true, assignments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ----------------------
// Get assignments by date
// ----------------------
const getAssignmentsByDate = async (req, res) => {
  try {
    const { date } = req.params;
    const d = new Date(date);
    const start = new Date(d.setHours(0, 0, 0, 0));
    const end = new Date(d.setHours(23, 59, 59, 999));

    const assignments = await AssignedTruck.find({
      date: { $gte: start, $lte: end },
    })
      .populate("truckID")
      .populate(
        "driverID",
        "firstName lastName email telephone licenseNumber assignedTruck"
      )
      .populate("deliveryCoordinatorID");

    res.status(200).json({ success: true, assignments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ----------------------
// Update assignment
// ----------------------
const updateAssignment = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    if (updateData.driverID) {
      const driver = await User.findById(updateData.driverID);
      if (!driver) return res.status(404).json({ message: "Driver not found" });
      driver.assignedTruck = updateData.truckID || null;
      await driver.save();
    }

    const assignment = await AssignedTruck.findByIdAndUpdate(id, updateData, {
      new: true,
    })
      .populate("truckID")
      .populate(
        "driverID",
        "firstName lastName email telephone licenseNumber assignedTruck"
      )
      .populate("deliveryCoordinatorID");

    if (!assignment)
      return res
        .status(404)
        .json({ success: false, message: "Assignment not found" });

    res.status(200).json({ success: true, assignment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ----------------------
// Export all functions
// ----------------------
module.exports = {
  assignTruck,
  getDriverTruck,
  getAllTrucks,
  getAllAssignments,
  getAssignmentsByCoordinator,
  getAssignmentsByDate,
  updateAssignment,
  deleteAssignment,
  getCoordinatorDailySchedule,
};
