// Backend/Controller/CategoryDefaultStockController.js
const CategoryDefaultStock = require("../Model/CategoryDefaultStock");
const Product = require("../Model/ProductModel");
const mongoose = require("mongoose");

// Get default stock for a specific category
const getDefaultStockByCategory = async (req, res) => {
  try {
    let { category } = req.params;

    if (!category) {
      return res.status(400).json({
        success: false,
        message: "Category is required",
      });
    }

    // ✅ Decode URL-encoded values like "veg%26spices" → "veg&spices"
    category = decodeURIComponent(category);

    // ✅ Normalize category (remove extra spaces and make lowercase)
    const normalizedCategory = decodeURIComponent(category)
      .toLowerCase()
      .replace(/\s*&\s*/g, " & ")
      .replace(/\s+/g, " ")
      .trim();

    // ✅ Use your fixed valid categories
    const validCategories = ["fish", "meat", "veg & spices", "fruits"];

    const matchedCategory = validCategories.find(
      (cat) => cat.toLowerCase().trim() === normalizedCategory
    );

    if (!matchedCategory) {
      return res.status(400).json({
        success: false,
        message: `Invalid category. Must be one of: ${validCategories.join(
          ", "
        )}`,
      });
    }

    const defaultStock = await CategoryDefaultStock.findOne({
      category: matchedCategory,
    }).populate("products.productID", "productName price category");

    if (!defaultStock) {
      return res.status(404).json({
        success: false,
        message: `No default stock configuration found for category: ${matchedCategory}`,
      });
    }

    res.status(200).json({
      success: true,
      message: "Default stock retrieved successfully",
      data: defaultStock,
    });
  } catch (error) {
    console.error("Error retrieving default stock:", error);
    res.status(500).json({
      success: false,
      message: "Error retrieving default stock",
      error: error.message,
    });
  }
};

// Get all default stocks (all categories)
const getAllDefaultStocks = async (req, res) => {
  try {
    const allStocks = await CategoryDefaultStock.find()
      .populate("products.productID", "productName price category")
      .populate("lastUpdatedBy", "username email");

    res.status(200).json({
      success: true,
      message: "All default stocks retrieved successfully",
      count: allStocks.length,
      data: allStocks,
    });
  } catch (error) {
    console.error("Error retrieving all default stocks:", error);
    res.status(500).json({
      success: false,
      message: "Error retrieving all default stocks",
      error: error.message,
    });
  }
};

// Create or update default stock for a category (UPSERT)
const upsertDefaultStock = async (req, res) => {
  try {
    const { category, products, lastUpdatedBy } = req.body;
    const adminID = lastUpdatedBy || req.user?.id;

    // Validation
    if (!category) {
      return res.status(400).json({
        success: false,
        message: "Category is required",
      });
    }

    const validCategories = ["fish", "meat", "veg & spices", "fruits"];
    if (!validCategories.includes(category)) {
      return res.status(400).json({
        success: false,
        message: `Invalid category. Must be one of: ${validCategories.join(
          ", "
        )}`,
      });
    }

    if (!Array.isArray(products) || products.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Products array is required and cannot be empty",
      });
    }

    // Validate all products exist and belong to category
    const validatedProducts = [];
    for (const product of products) {
      if (!product.productID) {
        return res.status(400).json({
          success: false,
          message: "Each product must have a productID",
        });
      }

      if (!mongoose.Types.ObjectId.isValid(product.productID)) {
        return res.status(400).json({
          success: false,
          message: `Invalid product ID format: ${product.productID}`,
        });
      }

      if (product.quantity === undefined || product.quantity === null) {
        return res.status(400).json({
          success: false,
          message: "Each product must have a quantity",
        });
      }

      if (product.quantity < 0) {
        return res.status(400).json({
          success: false,
          message: "Quantity cannot be negative",
        });
      }

      const existingProduct = await Product.findById(product.productID);
      if (!existingProduct) {
        return res.status(404).json({
          success: false,
          message: `Product not found with ID: ${product.productID}`,
        });
      }

      // Verify product belongs to the selected category
      const productCategory = existingProduct.category
        .replace(/\s+/g, "")
        .toLowerCase();
      const selectedCategory = category.replace(/\s+/g, "").toLowerCase();

      if (productCategory !== selectedCategory) {
        return res.status(400).json({
          success: false,
          message: `Product '${existingProduct.productName}' does not belong to category '${category}'`,
        });
      }

      validatedProducts.push({
        productID: product.productID,
        productName: existingProduct.productName,
        quantity: product.quantity,
        unit: product.unit || "pcs",
      });
    }

    // Upsert operation
    const defaultStock = await CategoryDefaultStock.findOneAndUpdate(
      { category },
      {
        category,
        products: validatedProducts,
        lastUpdatedBy: adminID,
        lastUpdatedAt: new Date(),
      },
      {
        upsert: true,
        new: true,
        runValidators: true,
        setDefaultsOnInsert: true,
      }
    ).populate("products.productID", "productName price");

    res.status(200).json({
      success: true,
      message: `Default stock for category '${category}' saved successfully`,
      data: defaultStock,
    });
  } catch (error) {
    console.error("Error upserting default stock:", error);
    res.status(500).json({
      success: false,
      message: "Error saving default stock",
      error: error.message,
    });
  }
};

// Update a specific product quantity in category default stock
const updateProductInDefaultStock = async (req, res) => {
  try {
    const { category, productID, quantity, unit } = req.body;

    // Validation
    if (!category || !productID) {
      return res.status(400).json({
        success: false,
        message: "Category and productID are required",
      });
    }

    if (quantity === undefined || quantity === null) {
      return res.status(400).json({
        success: false,
        message: "Quantity is required",
      });
    }

    if (quantity < 0) {
      return res.status(400).json({
        success: false,
        message: "Quantity cannot be negative",
      });
    }

    if (!mongoose.Types.ObjectId.isValid(productID)) {
      return res.status(400).json({
        success: false,
        message: `Invalid product ID format: ${productID}`,
      });
    }

    const defaultStock = await CategoryDefaultStock.findOne({ category });

    if (!defaultStock) {
      return res.status(404).json({
        success: false,
        message: `No default stock found for category: ${category}`,
      });
    }

    // Find and update the product in the array
    const productIndex = defaultStock.products.findIndex(
      (p) => p.productID.toString() === productID
    );

    if (productIndex === -1) {
      return res.status(404).json({
        success: false,
        message: "Product not found in this category's default stock",
      });
    }

    defaultStock.products[productIndex].quantity = quantity;
    if (unit) defaultStock.products[productIndex].unit = unit;
    defaultStock.lastUpdatedAt = new Date();

    await defaultStock.save();

    res.status(200).json({
      success: true,
      message: "Product quantity updated successfully",
      data: defaultStock,
    });
  } catch (error) {
    console.error("Error updating product in default stock:", error);
    res.status(500).json({
      success: false,
      message: "Error updating product quantity",
      error: error.message,
    });
  }
};

// Delete a product from category default stock
const deleteProductFromDefaultStock = async (req, res) => {
  try {
    const { category, productID } = req.params;

    // Validation
    if (!category || !productID) {
      return res.status(400).json({
        success: false,
        message: "Category and productID are required",
      });
    }

    if (!mongoose.Types.ObjectId.isValid(productID)) {
      return res.status(400).json({
        success: false,
        message: `Invalid product ID format: ${productID}`,
      });
    }

    const defaultStock = await CategoryDefaultStock.findOne({ category });

    if (!defaultStock) {
      return res.status(404).json({
        success: false,
        message: `No default stock found for category: ${category}`,
      });
    }

    const initialLength = defaultStock.products.length;
    defaultStock.products = defaultStock.products.filter(
      (p) => p.productID.toString() !== productID
    );

    if (defaultStock.products.length === initialLength) {
      return res.status(404).json({
        success: false,
        message: "Product not found in this category's default stock",
      });
    }

    defaultStock.lastUpdatedAt = new Date();
    await defaultStock.save();

    res.status(200).json({
      success: true,
      message: "Product removed from default stock successfully",
      data: defaultStock,
    });
  } catch (error) {
    console.error("Error deleting product from default stock:", error);
    res.status(500).json({
      success: false,
      message: "Error removing product from default stock",
      error: error.message,
    });
  }
};

module.exports = {
  getDefaultStockByCategory,
  getAllDefaultStocks,
  upsertDefaultStock,
  updateProductInDefaultStock,
  deleteProductFromDefaultStock,
};
