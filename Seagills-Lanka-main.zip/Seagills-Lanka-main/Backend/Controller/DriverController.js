const Driver = require("../Model/DriverModel");

// Create new driver
const createDriver = async (req, res) => {
  try {
    const { driverName, driverTelephone } = req.body;

    if (!driverName || !driverTelephone) {
      return res.status(400).json({
        success: false,
        message: "Driver name and telephone are required",
      });
    }

    const existingDriver = await Driver.findOne({ driverTelephone });
    if (existingDriver) {
      return res.status(400).json({
        success: false,
        message: "Driver with this telephone already exists",
      });
    }

    const newDriver = new Driver({ driverName, driverTelephone });
    const savedDriver = await newDriver.save();

    res.status(201).json({
      success: true,
      message: "Driver created successfully",
      driver: savedDriver,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error creating driver",
      error: error.message,
    });
  }
};

// Get all drivers
const getAllDrivers = async (req, res) => {
  try {
    const drivers = await Driver.find().select("driverName driverTelephone");

    res.status(200).json({
      success: true,
      message: "Drivers retrieved successfully",
      count: drivers.length,
      drivers,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving drivers",
      error: error.message,
    });
  }
};

// Get driver by ID
const getDriverById = async (req, res) => {
  try {
    const { id } = req.params;
    const driver = await Driver.findById(id);

    if (!driver) {
      return res.status(404).json({
        success: false,
        message: "Driver not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Driver retrieved successfully",
      driver,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error retrieving driver",
      error: error.message,
    });
  }
};

// Update driver
const updateDriver = async (req, res) => {
  try {
    const { id } = req.params;
    const { driverName, driverTelephone } = req.body;

    // Check if driverTelephone already exists for another driver
    const existingDriver = await Driver.findOne({
      driverTelephone,
      _id: { $ne: id }, // exclude current driver
    });

    if (existingDriver) {
      return res.status(400).json({
        success: false,
        message:
          "This telephone number is already registered with another driver",
      });
    }

    const updatedDriver = await Driver.findByIdAndUpdate(
      id,
      { driverName, driverTelephone },
      { new: true, runValidators: true }
    );

    if (!updatedDriver) {
      return res.status(404).json({
        success: false,
        message: "Driver not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Driver updated successfully",
      driver: updatedDriver,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error updating driver",
      error: error.message,
    });
  }
};

// Delete driver
const deleteDriver = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedDriver = await Driver.findByIdAndDelete(id);

    if (!deletedDriver) {
      return res.status(404).json({
        success: false,
        message: "Driver not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Driver deleted successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error deleting driver",
      error: error.message,
    });
  }
};

module.exports = {
  createDriver,
  getAllDrivers,
  getDriverById,
  updateDriver,
  deleteDriver,
};
